(() => {
    var e,
        t,
        n,
        r,
        o = {
            263: function (e, t) {
                var n;
                /*!
                 * jQuery JavaScript Library v3.7.1
                 * https://jquery.com/
                 *
                 * Copyright OpenJS Foundation and other contributors
                 * Released under the MIT license
                 * https://jquery.org/license
                 *
                 * Date: 2023-08-28T13:37Z
                 */ !(function (t, n) {
                    "use strict";
                    "object" == typeof e.exports
                        ? (e.exports = t.document
                              ? n(t, !0)
                              : function (e) {
                                    if (!e.document)
                                        throw new Error(
                                            "jQuery requires a window with a document"
                                        );
                                    return n(e);
                                })
                        : n(t);
                })(
                    "undefined" != typeof window ? window : this,
                    function (r, o) {
                        "use strict";
                        var i = [],
                            a = Object.getPrototypeOf,
                            s = i.slice,
                            c = i.flat
                                ? function (e) {
                                      return i.flat.call(e);
                                  }
                                : function (e) {
                                      return i.concat.apply([], e);
                                  },
                            u = i.push,
                            l = i.indexOf,
                            d = {},
                            p = d.toString,
                            f = d.hasOwnProperty,
                            h = f.toString,
                            m = h.call(Object),
                            g = {},
                            v = function (e) {
                                return (
                                    "function" == typeof e &&
                                    "number" != typeof e.nodeType &&
                                    "function" != typeof e.item
                                );
                            },
                            y = function (e) {
                                return null != e && e === e.window;
                            },
                            b = r.document,
                            x = { type: !0, src: !0, nonce: !0, noModule: !0 };
                        function w(e, t, n) {
                            var r,
                                o,
                                i = (n = n || b).createElement("script");
                            if (((i.text = e), t))
                                for (r in x)
                                    (o =
                                        t[r] ||
                                        (t.getAttribute &&
                                            t.getAttribute(r))) &&
                                        i.setAttribute(r, o);
                            n.head.appendChild(i).parentNode.removeChild(i);
                        }
                        function j(e) {
                            return null == e
                                ? e + ""
                                : "object" == typeof e || "function" == typeof e
                                ? d[p.call(e)] || "object"
                                : typeof e;
                        }
                        var k = "3.7.1",
                            C = /HTML$/i,
                            T = function (e, t) {
                                return new T.fn.init(e, t);
                            };
                        function S(e) {
                            var t = !!e && "length" in e && e.length,
                                n = j(e);
                            return (
                                !v(e) &&
                                !y(e) &&
                                ("array" === n ||
                                    0 === t ||
                                    ("number" == typeof t &&
                                        t > 0 &&
                                        t - 1 in e))
                            );
                        }
                        function A(e, t) {
                            return (
                                e.nodeName &&
                                e.nodeName.toLowerCase() === t.toLowerCase()
                            );
                        }
                        (T.fn = T.prototype =
                            {
                                jquery: k,
                                constructor: T,
                                length: 0,
                                toArray: function () {
                                    return s.call(this);
                                },
                                get: function (e) {
                                    return null == e
                                        ? s.call(this)
                                        : e < 0
                                        ? this[e + this.length]
                                        : this[e];
                                },
                                pushStack: function (e) {
                                    var t = T.merge(this.constructor(), e);
                                    return (t.prevObject = this), t;
                                },
                                each: function (e) {
                                    return T.each(this, e);
                                },
                                map: function (e) {
                                    return this.pushStack(
                                        T.map(this, function (t, n) {
                                            return e.call(t, n, t);
                                        })
                                    );
                                },
                                slice: function () {
                                    return this.pushStack(
                                        s.apply(this, arguments)
                                    );
                                },
                                first: function () {
                                    return this.eq(0);
                                },
                                last: function () {
                                    return this.eq(-1);
                                },
                                even: function () {
                                    return this.pushStack(
                                        T.grep(this, function (e, t) {
                                            return (t + 1) % 2;
                                        })
                                    );
                                },
                                odd: function () {
                                    return this.pushStack(
                                        T.grep(this, function (e, t) {
                                            return t % 2;
                                        })
                                    );
                                },
                                eq: function (e) {
                                    var t = this.length,
                                        n = +e + (e < 0 ? t : 0);
                                    return this.pushStack(
                                        n >= 0 && n < t ? [this[n]] : []
                                    );
                                },
                                end: function () {
                                    return (
                                        this.prevObject || this.constructor()
                                    );
                                },
                                push: u,
                                sort: i.sort,
                                splice: i.splice,
                            }),
                            (T.extend = T.fn.extend =
                                function () {
                                    var e,
                                        t,
                                        n,
                                        r,
                                        o,
                                        i,
                                        a = arguments[0] || {},
                                        s = 1,
                                        c = arguments.length,
                                        u = !1;
                                    for (
                                        "boolean" == typeof a &&
                                            ((u = a),
                                            (a = arguments[s] || {}),
                                            s++),
                                            "object" == typeof a ||
                                                v(a) ||
                                                (a = {}),
                                            s === c && ((a = this), s--);
                                        s < c;
                                        s++
                                    )
                                        if (null != (e = arguments[s]))
                                            for (t in e)
                                                (r = e[t]),
                                                    "__proto__" !== t &&
                                                        a !== r &&
                                                        (u &&
                                                        r &&
                                                        (T.isPlainObject(r) ||
                                                            (o =
                                                                Array.isArray(
                                                                    r
                                                                )))
                                                            ? ((n = a[t]),
                                                              (i =
                                                                  o &&
                                                                  !Array.isArray(
                                                                      n
                                                                  )
                                                                      ? []
                                                                      : o ||
                                                                        T.isPlainObject(
                                                                            n
                                                                        )
                                                                      ? n
                                                                      : {}),
                                                              (o = !1),
                                                              (a[t] = T.extend(
                                                                  u,
                                                                  i,
                                                                  r
                                                              )))
                                                            : void 0 !== r &&
                                                              (a[t] = r));
                                    return a;
                                }),
                            T.extend({
                                expando:
                                    "jQuery" +
                                    (k + Math.random()).replace(/\D/g, ""),
                                isReady: !0,
                                error: function (e) {
                                    throw new Error(e);
                                },
                                noop: function () {},
                                isPlainObject: function (e) {
                                    var t, n;
                                    return (
                                        !(
                                            !e ||
                                            "[object Object]" !== p.call(e)
                                        ) &&
                                        (!(t = a(e)) ||
                                            ("function" ==
                                                typeof (n =
                                                    f.call(t, "constructor") &&
                                                    t.constructor) &&
                                                h.call(n) === m))
                                    );
                                },
                                isEmptyObject: function (e) {
                                    var t;
                                    for (t in e) return !1;
                                    return !0;
                                },
                                globalEval: function (e, t, n) {
                                    w(e, { nonce: t && t.nonce }, n);
                                },
                                each: function (e, t) {
                                    var n,
                                        r = 0;
                                    if (S(e))
                                        for (
                                            n = e.length;
                                            r < n &&
                                            !1 !== t.call(e[r], r, e[r]);
                                            r++
                                        );
                                    else
                                        for (r in e)
                                            if (!1 === t.call(e[r], r, e[r]))
                                                break;
                                    return e;
                                },
                                text: function (e) {
                                    var t,
                                        n = "",
                                        r = 0,
                                        o = e.nodeType;
                                    if (!o)
                                        for (; (t = e[r++]); ) n += T.text(t);
                                    return 1 === o || 11 === o
                                        ? e.textContent
                                        : 9 === o
                                        ? e.documentElement.textContent
                                        : 3 === o || 4 === o
                                        ? e.nodeValue
                                        : n;
                                },
                                makeArray: function (e, t) {
                                    var n = t || [];
                                    return (
                                        null != e &&
                                            (S(Object(e))
                                                ? T.merge(
                                                      n,
                                                      "string" == typeof e
                                                          ? [e]
                                                          : e
                                                  )
                                                : u.call(n, e)),
                                        n
                                    );
                                },
                                inArray: function (e, t, n) {
                                    return null == t ? -1 : l.call(t, e, n);
                                },
                                isXMLDoc: function (e) {
                                    var t = e && e.namespaceURI,
                                        n =
                                            e &&
                                            (e.ownerDocument || e)
                                                .documentElement;
                                    return !C.test(
                                        t || (n && n.nodeName) || "HTML"
                                    );
                                },
                                merge: function (e, t) {
                                    for (
                                        var n = +t.length, r = 0, o = e.length;
                                        r < n;
                                        r++
                                    )
                                        e[o++] = t[r];
                                    return (e.length = o), e;
                                },
                                grep: function (e, t, n) {
                                    for (
                                        var r = [], o = 0, i = e.length, a = !n;
                                        o < i;
                                        o++
                                    )
                                        !t(e[o], o) !== a && r.push(e[o]);
                                    return r;
                                },
                                map: function (e, t, n) {
                                    var r,
                                        o,
                                        i = 0,
                                        a = [];
                                    if (S(e))
                                        for (r = e.length; i < r; i++)
                                            null != (o = t(e[i], i, n)) &&
                                                a.push(o);
                                    else
                                        for (i in e)
                                            null != (o = t(e[i], i, n)) &&
                                                a.push(o);
                                    return c(a);
                                },
                                guid: 1,
                                support: g,
                            }),
                            "function" == typeof Symbol &&
                                (T.fn[Symbol.iterator] = i[Symbol.iterator]),
                            T.each(
                                "Boolean Number String Function Array Date RegExp Object Error Symbol".split(
                                    " "
                                ),
                                function (e, t) {
                                    d["[object " + t + "]"] = t.toLowerCase();
                                }
                            );
                        var E = i.pop,
                            D = i.sort,
                            P = i.splice,
                            q = "[\\x20\\t\\r\\n\\f]",
                            N = new RegExp(
                                "^" +
                                    q +
                                    "+|((?:^|[^\\\\])(?:\\\\.)*)" +
                                    q +
                                    "+$",
                                "g"
                            );
                        T.contains = function (e, t) {
                            var n = t && t.parentNode;
                            return (
                                e === n ||
                                !(
                                    !n ||
                                    1 !== n.nodeType ||
                                    !(e.contains
                                        ? e.contains(n)
                                        : e.compareDocumentPosition &&
                                          16 & e.compareDocumentPosition(n))
                                )
                            );
                        };
                        var O = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g;
                        function _(e, t) {
                            return t
                                ? "\0" === e
                                    ? "�"
                                    : e.slice(0, -1) +
                                      "\\" +
                                      e.charCodeAt(e.length - 1).toString(16) +
                                      " "
                                : "\\" + e;
                        }
                        T.escapeSelector = function (e) {
                            return (e + "").replace(O, _);
                        };
                        var $ = b,
                            H = u;
                        !(function () {
                            var e,
                                t,
                                n,
                                o,
                                a,
                                c,
                                u,
                                d,
                                p,
                                h,
                                m = H,
                                v = T.expando,
                                y = 0,
                                b = 0,
                                x = ee(),
                                w = ee(),
                                j = ee(),
                                k = ee(),
                                C = function (e, t) {
                                    return e === t && (a = !0), 0;
                                },
                                S =
                                    "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                                O =
                                    "(?:\\\\[\\da-fA-F]{1,6}" +
                                    q +
                                    "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
                                _ =
                                    "\\[" +
                                    q +
                                    "*(" +
                                    O +
                                    ")(?:" +
                                    q +
                                    "*([*^$|!~]?=)" +
                                    q +
                                    "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" +
                                    O +
                                    "))|)" +
                                    q +
                                    "*\\]",
                                L =
                                    ":(" +
                                    O +
                                    ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" +
                                    _ +
                                    ")*)|.*)\\)|)",
                                R = new RegExp(q + "+", "g"),
                                M = new RegExp("^" + q + "*," + q + "*"),
                                I = new RegExp(
                                    "^" + q + "*([>+~]|" + q + ")" + q + "*"
                                ),
                                W = new RegExp(q + "|>"),
                                F = new RegExp(L),
                                Q = new RegExp("^" + O + "$"),
                                B = {
                                    ID: new RegExp("^#(" + O + ")"),
                                    CLASS: new RegExp("^\\.(" + O + ")"),
                                    TAG: new RegExp("^(" + O + "|[*])"),
                                    ATTR: new RegExp("^" + _),
                                    PSEUDO: new RegExp("^" + L),
                                    CHILD: new RegExp(
                                        "^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" +
                                            q +
                                            "*(even|odd|(([+-]|)(\\d*)n|)" +
                                            q +
                                            "*(?:([+-]|)" +
                                            q +
                                            "*(\\d+)|))" +
                                            q +
                                            "*\\)|)",
                                        "i"
                                    ),
                                    bool: new RegExp("^(?:" + S + ")$", "i"),
                                    needsContext: new RegExp(
                                        "^" +
                                            q +
                                            "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
                                            q +
                                            "*((?:-\\d)?\\d*)" +
                                            q +
                                            "*\\)|)(?=[^-]|$)",
                                        "i"
                                    ),
                                },
                                z = /^(?:input|select|textarea|button)$/i,
                                U = /^h\d$/i,
                                X = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                                V = /[+~]/,
                                J = new RegExp(
                                    "\\\\[\\da-fA-F]{1,6}" +
                                        q +
                                        "?|\\\\([^\\r\\n\\f])",
                                    "g"
                                ),
                                G = function (e, t) {
                                    var n = "0x" + e.slice(1) - 65536;
                                    return (
                                        t ||
                                        (n < 0
                                            ? String.fromCharCode(n + 65536)
                                            : String.fromCharCode(
                                                  (n >> 10) | 55296,
                                                  (1023 & n) | 56320
                                              ))
                                    );
                                },
                                Y = function () {
                                    ce();
                                },
                                K = pe(
                                    function (e) {
                                        return (
                                            !0 === e.disabled &&
                                            A(e, "fieldset")
                                        );
                                    },
                                    { dir: "parentNode", next: "legend" }
                                );
                            try {
                                m.apply(
                                    (i = s.call($.childNodes)),
                                    $.childNodes
                                ),
                                    i[$.childNodes.length].nodeType;
                            } catch (e) {
                                m = {
                                    apply: function (e, t) {
                                        H.apply(e, s.call(t));
                                    },
                                    call: function (e) {
                                        H.apply(e, s.call(arguments, 1));
                                    },
                                };
                            }
                            function Z(e, t, n, r) {
                                var o,
                                    i,
                                    a,
                                    s,
                                    u,
                                    l,
                                    f,
                                    h = t && t.ownerDocument,
                                    y = t ? t.nodeType : 9;
                                if (
                                    ((n = n || []),
                                    "string" != typeof e ||
                                        !e ||
                                        (1 !== y && 9 !== y && 11 !== y))
                                )
                                    return n;
                                if (!r && (ce(t), (t = t || c), d)) {
                                    if (11 !== y && (u = X.exec(e)))
                                        if ((o = u[1])) {
                                            if (9 === y) {
                                                if (!(a = t.getElementById(o)))
                                                    return n;
                                                if (a.id === o)
                                                    return m.call(n, a), n;
                                            } else if (
                                                h &&
                                                (a = h.getElementById(o)) &&
                                                Z.contains(t, a) &&
                                                a.id === o
                                            )
                                                return m.call(n, a), n;
                                        } else {
                                            if (u[2])
                                                return (
                                                    m.apply(
                                                        n,
                                                        t.getElementsByTagName(
                                                            e
                                                        )
                                                    ),
                                                    n
                                                );
                                            if (
                                                (o = u[3]) &&
                                                t.getElementsByClassName
                                            )
                                                return (
                                                    m.apply(
                                                        n,
                                                        t.getElementsByClassName(
                                                            o
                                                        )
                                                    ),
                                                    n
                                                );
                                        }
                                    if (!(k[e + " "] || (p && p.test(e)))) {
                                        if (
                                            ((f = e),
                                            (h = t),
                                            1 === y && (W.test(e) || I.test(e)))
                                        ) {
                                            for (
                                                ((h =
                                                    (V.test(e) &&
                                                        se(t.parentNode)) ||
                                                    t) == t &&
                                                    g.scope) ||
                                                    ((s = t.getAttribute("id"))
                                                        ? (s =
                                                              T.escapeSelector(
                                                                  s
                                                              ))
                                                        : t.setAttribute(
                                                              "id",
                                                              (s = v)
                                                          )),
                                                    i = (l = le(e)).length;
                                                i--;

                                            )
                                                l[i] =
                                                    (s ? "#" + s : ":scope") +
                                                    " " +
                                                    de(l[i]);
                                            f = l.join(",");
                                        }
                                        try {
                                            return (
                                                m.apply(
                                                    n,
                                                    h.querySelectorAll(f)
                                                ),
                                                n
                                            );
                                        } catch (t) {
                                            k(e, !0);
                                        } finally {
                                            s === v && t.removeAttribute("id");
                                        }
                                    }
                                }
                                return ye(e.replace(N, "$1"), t, n, r);
                            }
                            function ee() {
                                var e = [];
                                return function n(r, o) {
                                    return (
                                        e.push(r + " ") > t.cacheLength &&
                                            delete n[e.shift()],
                                        (n[r + " "] = o)
                                    );
                                };
                            }
                            function te(e) {
                                return (e[v] = !0), e;
                            }
                            function ne(e) {
                                var t = c.createElement("fieldset");
                                try {
                                    return !!e(t);
                                } catch (e) {
                                    return !1;
                                } finally {
                                    t.parentNode && t.parentNode.removeChild(t),
                                        (t = null);
                                }
                            }
                            function re(e) {
                                return function (t) {
                                    return A(t, "input") && t.type === e;
                                };
                            }
                            function oe(e) {
                                return function (t) {
                                    return (
                                        (A(t, "input") || A(t, "button")) &&
                                        t.type === e
                                    );
                                };
                            }
                            function ie(e) {
                                return function (t) {
                                    return "form" in t
                                        ? t.parentNode && !1 === t.disabled
                                            ? "label" in t
                                                ? "label" in t.parentNode
                                                    ? t.parentNode.disabled ===
                                                      e
                                                    : t.disabled === e
                                                : t.isDisabled === e ||
                                                  (t.isDisabled !== !e &&
                                                      K(t) === e)
                                            : t.disabled === e
                                        : "label" in t && t.disabled === e;
                                };
                            }
                            function ae(e) {
                                return te(function (t) {
                                    return (
                                        (t = +t),
                                        te(function (n, r) {
                                            for (
                                                var o,
                                                    i = e([], n.length, t),
                                                    a = i.length;
                                                a--;

                                            )
                                                n[(o = i[a])] &&
                                                    (n[o] = !(r[o] = n[o]));
                                        })
                                    );
                                });
                            }
                            function se(e) {
                                return (
                                    e && void 0 !== e.getElementsByTagName && e
                                );
                            }
                            function ce(e) {
                                var n,
                                    r = e ? e.ownerDocument || e : $;
                                return r != c &&
                                    9 === r.nodeType &&
                                    r.documentElement
                                    ? ((u = (c = r).documentElement),
                                      (d = !T.isXMLDoc(c)),
                                      (h =
                                          u.matches ||
                                          u.webkitMatchesSelector ||
                                          u.msMatchesSelector),
                                      u.msMatchesSelector &&
                                          $ != c &&
                                          (n = c.defaultView) &&
                                          n.top !== n &&
                                          n.addEventListener("unload", Y),
                                      (g.getById = ne(function (e) {
                                          return (
                                              (u.appendChild(e).id = T.expando),
                                              !c.getElementsByName ||
                                                  !c.getElementsByName(
                                                      T.expando
                                                  ).length
                                          );
                                      })),
                                      (g.disconnectedMatch = ne(function (e) {
                                          return h.call(e, "*");
                                      })),
                                      (g.scope = ne(function () {
                                          return c.querySelectorAll(":scope");
                                      })),
                                      (g.cssHas = ne(function () {
                                          try {
                                              return (
                                                  c.querySelector(
                                                      ":has(*,:jqfake)"
                                                  ),
                                                  !1
                                              );
                                          } catch (e) {
                                              return !0;
                                          }
                                      })),
                                      g.getById
                                          ? ((t.filter.ID = function (e) {
                                                var t = e.replace(J, G);
                                                return function (e) {
                                                    return (
                                                        e.getAttribute("id") ===
                                                        t
                                                    );
                                                };
                                            }),
                                            (t.find.ID = function (e, t) {
                                                if (
                                                    void 0 !==
                                                        t.getElementById &&
                                                    d
                                                ) {
                                                    var n = t.getElementById(e);
                                                    return n ? [n] : [];
                                                }
                                            }))
                                          : ((t.filter.ID = function (e) {
                                                var t = e.replace(J, G);
                                                return function (e) {
                                                    var n =
                                                        void 0 !==
                                                            e.getAttributeNode &&
                                                        e.getAttributeNode(
                                                            "id"
                                                        );
                                                    return n && n.value === t;
                                                };
                                            }),
                                            (t.find.ID = function (e, t) {
                                                if (
                                                    void 0 !==
                                                        t.getElementById &&
                                                    d
                                                ) {
                                                    var n,
                                                        r,
                                                        o,
                                                        i = t.getElementById(e);
                                                    if (i) {
                                                        if (
                                                            (n =
                                                                i.getAttributeNode(
                                                                    "id"
                                                                )) &&
                                                            n.value === e
                                                        )
                                                            return [i];
                                                        for (
                                                            o =
                                                                t.getElementsByName(
                                                                    e
                                                                ),
                                                                r = 0;
                                                            (i = o[r++]);

                                                        )
                                                            if (
                                                                (n =
                                                                    i.getAttributeNode(
                                                                        "id"
                                                                    )) &&
                                                                n.value === e
                                                            )
                                                                return [i];
                                                    }
                                                    return [];
                                                }
                                            })),
                                      (t.find.TAG = function (e, t) {
                                          return void 0 !==
                                              t.getElementsByTagName
                                              ? t.getElementsByTagName(e)
                                              : t.querySelectorAll(e);
                                      }),
                                      (t.find.CLASS = function (e, t) {
                                          if (
                                              void 0 !==
                                                  t.getElementsByClassName &&
                                              d
                                          )
                                              return t.getElementsByClassName(
                                                  e
                                              );
                                      }),
                                      (p = []),
                                      ne(function (e) {
                                          var t;
                                          (u.appendChild(e).innerHTML =
                                              "<a id='" +
                                              v +
                                              "' href='' disabled='disabled'></a><select id='" +
                                              v +
                                              "-\r\\' disabled='disabled'><option selected=''></option></select>"),
                                              e.querySelectorAll("[selected]")
                                                  .length ||
                                                  p.push(
                                                      "\\[" +
                                                          q +
                                                          "*(?:value|" +
                                                          S +
                                                          ")"
                                                  ),
                                              e.querySelectorAll(
                                                  "[id~=" + v + "-]"
                                              ).length || p.push("~="),
                                              e.querySelectorAll(
                                                  "a#" + v + "+*"
                                              ).length || p.push(".#.+[+~]"),
                                              e.querySelectorAll(":checked")
                                                  .length || p.push(":checked"),
                                              (t =
                                                  c.createElement(
                                                      "input"
                                                  )).setAttribute(
                                                  "type",
                                                  "hidden"
                                              ),
                                              e
                                                  .appendChild(t)
                                                  .setAttribute("name", "D"),
                                              (u.appendChild(e).disabled = !0),
                                              2 !==
                                                  e.querySelectorAll(
                                                      ":disabled"
                                                  ).length &&
                                                  p.push(
                                                      ":enabled",
                                                      ":disabled"
                                                  ),
                                              (t =
                                                  c.createElement(
                                                      "input"
                                                  )).setAttribute("name", ""),
                                              e.appendChild(t),
                                              e.querySelectorAll("[name='']")
                                                  .length ||
                                                  p.push(
                                                      "\\[" +
                                                          q +
                                                          "*name" +
                                                          q +
                                                          "*=" +
                                                          q +
                                                          "*(?:''|\"\")"
                                                  );
                                      }),
                                      g.cssHas || p.push(":has"),
                                      (p = p.length && new RegExp(p.join("|"))),
                                      (C = function (e, t) {
                                          if (e === t) return (a = !0), 0;
                                          var n =
                                              !e.compareDocumentPosition -
                                              !t.compareDocumentPosition;
                                          return (
                                              n ||
                                              (1 &
                                                  (n =
                                                      (e.ownerDocument || e) ==
                                                      (t.ownerDocument || t)
                                                          ? e.compareDocumentPosition(
                                                                t
                                                            )
                                                          : 1) ||
                                              (!g.sortDetached &&
                                                  t.compareDocumentPosition(
                                                      e
                                                  ) === n)
                                                  ? e === c ||
                                                    (e.ownerDocument == $ &&
                                                        Z.contains($, e))
                                                      ? -1
                                                      : t === c ||
                                                        (t.ownerDocument == $ &&
                                                            Z.contains($, t))
                                                      ? 1
                                                      : o
                                                      ? l.call(o, e) -
                                                        l.call(o, t)
                                                      : 0
                                                  : 4 & n
                                                  ? -1
                                                  : 1)
                                          );
                                      }),
                                      c)
                                    : c;
                            }
                            for (e in ((Z.matches = function (e, t) {
                                return Z(e, null, null, t);
                            }),
                            (Z.matchesSelector = function (e, t) {
                                if (
                                    (ce(e),
                                    d && !k[t + " "] && (!p || !p.test(t)))
                                )
                                    try {
                                        var n = h.call(e, t);
                                        if (
                                            n ||
                                            g.disconnectedMatch ||
                                            (e.document &&
                                                11 !== e.document.nodeType)
                                        )
                                            return n;
                                    } catch (e) {
                                        k(t, !0);
                                    }
                                return Z(t, c, null, [e]).length > 0;
                            }),
                            (Z.contains = function (e, t) {
                                return (
                                    (e.ownerDocument || e) != c && ce(e),
                                    T.contains(e, t)
                                );
                            }),
                            (Z.attr = function (e, n) {
                                (e.ownerDocument || e) != c && ce(e);
                                var r = t.attrHandle[n.toLowerCase()],
                                    o =
                                        r &&
                                        f.call(t.attrHandle, n.toLowerCase())
                                            ? r(e, n, !d)
                                            : void 0;
                                return void 0 !== o ? o : e.getAttribute(n);
                            }),
                            (Z.error = function (e) {
                                throw new Error(
                                    "Syntax error, unrecognized expression: " +
                                        e
                                );
                            }),
                            (T.uniqueSort = function (e) {
                                var t,
                                    n = [],
                                    r = 0,
                                    i = 0;
                                if (
                                    ((a = !g.sortStable),
                                    (o = !g.sortStable && s.call(e, 0)),
                                    D.call(e, C),
                                    a)
                                ) {
                                    for (; (t = e[i++]); )
                                        t === e[i] && (r = n.push(i));
                                    for (; r--; ) P.call(e, n[r], 1);
                                }
                                return (o = null), e;
                            }),
                            (T.fn.uniqueSort = function () {
                                return this.pushStack(
                                    T.uniqueSort(s.apply(this))
                                );
                            }),
                            ((t = T.expr =
                                {
                                    cacheLength: 50,
                                    createPseudo: te,
                                    match: B,
                                    attrHandle: {},
                                    find: {},
                                    relative: {
                                        ">": { dir: "parentNode", first: !0 },
                                        " ": { dir: "parentNode" },
                                        "+": {
                                            dir: "previousSibling",
                                            first: !0,
                                        },
                                        "~": { dir: "previousSibling" },
                                    },
                                    preFilter: {
                                        ATTR: function (e) {
                                            return (
                                                (e[1] = e[1].replace(J, G)),
                                                (e[3] = (
                                                    e[3] ||
                                                    e[4] ||
                                                    e[5] ||
                                                    ""
                                                ).replace(J, G)),
                                                "~=" === e[2] &&
                                                    (e[3] = " " + e[3] + " "),
                                                e.slice(0, 4)
                                            );
                                        },
                                        CHILD: function (e) {
                                            return (
                                                (e[1] = e[1].toLowerCase()),
                                                "nth" === e[1].slice(0, 3)
                                                    ? (e[3] || Z.error(e[0]),
                                                      (e[4] = +(e[4]
                                                          ? e[5] + (e[6] || 1)
                                                          : 2 *
                                                            ("even" === e[3] ||
                                                                "odd" ===
                                                                    e[3]))),
                                                      (e[5] = +(
                                                          e[7] + e[8] ||
                                                          "odd" === e[3]
                                                      )))
                                                    : e[3] && Z.error(e[0]),
                                                e
                                            );
                                        },
                                        PSEUDO: function (e) {
                                            var t,
                                                n = !e[6] && e[2];
                                            return B.CHILD.test(e[0])
                                                ? null
                                                : (e[3]
                                                      ? (e[2] =
                                                            e[4] || e[5] || "")
                                                      : n &&
                                                        F.test(n) &&
                                                        (t = le(n, !0)) &&
                                                        (t =
                                                            n.indexOf(
                                                                ")",
                                                                n.length - t
                                                            ) - n.length) &&
                                                        ((e[0] = e[0].slice(
                                                            0,
                                                            t
                                                        )),
                                                        (e[2] = n.slice(0, t))),
                                                  e.slice(0, 3));
                                        },
                                    },
                                    filter: {
                                        TAG: function (e) {
                                            var t = e
                                                .replace(J, G)
                                                .toLowerCase();
                                            return "*" === e
                                                ? function () {
                                                      return !0;
                                                  }
                                                : function (e) {
                                                      return A(e, t);
                                                  };
                                        },
                                        CLASS: function (e) {
                                            var t = x[e + " "];
                                            return (
                                                t ||
                                                ((t = new RegExp(
                                                    "(^|" +
                                                        q +
                                                        ")" +
                                                        e +
                                                        "(" +
                                                        q +
                                                        "|$)"
                                                )) &&
                                                    x(e, function (e) {
                                                        return t.test(
                                                            ("string" ==
                                                                typeof e.className &&
                                                                e.className) ||
                                                                (void 0 !==
                                                                    e.getAttribute &&
                                                                    e.getAttribute(
                                                                        "class"
                                                                    )) ||
                                                                ""
                                                        );
                                                    }))
                                            );
                                        },
                                        ATTR: function (e, t, n) {
                                            return function (r) {
                                                var o = Z.attr(r, e);
                                                return null == o
                                                    ? "!=" === t
                                                    : !t ||
                                                          ((o += ""),
                                                          "=" === t
                                                              ? o === n
                                                              : "!=" === t
                                                              ? o !== n
                                                              : "^=" === t
                                                              ? n &&
                                                                0 ===
                                                                    o.indexOf(n)
                                                              : "*=" === t
                                                              ? n &&
                                                                o.indexOf(n) >
                                                                    -1
                                                              : "$=" === t
                                                              ? n &&
                                                                o.slice(
                                                                    -n.length
                                                                ) === n
                                                              : "~=" === t
                                                              ? (
                                                                    " " +
                                                                    o.replace(
                                                                        R,
                                                                        " "
                                                                    ) +
                                                                    " "
                                                                ).indexOf(n) >
                                                                -1
                                                              : "|=" === t &&
                                                                (o === n ||
                                                                    o.slice(
                                                                        0,
                                                                        n.length +
                                                                            1
                                                                    ) ===
                                                                        n +
                                                                            "-"));
                                            };
                                        },
                                        CHILD: function (e, t, n, r, o) {
                                            var i = "nth" !== e.slice(0, 3),
                                                a = "last" !== e.slice(-4),
                                                s = "of-type" === t;
                                            return 1 === r && 0 === o
                                                ? function (e) {
                                                      return !!e.parentNode;
                                                  }
                                                : function (t, n, c) {
                                                      var u,
                                                          l,
                                                          d,
                                                          p,
                                                          f,
                                                          h =
                                                              i !== a
                                                                  ? "nextSibling"
                                                                  : "previousSibling",
                                                          m = t.parentNode,
                                                          g =
                                                              s &&
                                                              t.nodeName.toLowerCase(),
                                                          b = !c && !s,
                                                          x = !1;
                                                      if (m) {
                                                          if (i) {
                                                              for (; h; ) {
                                                                  for (
                                                                      d = t;
                                                                      (d =
                                                                          d[h]);

                                                                  )
                                                                      if (
                                                                          s
                                                                              ? A(
                                                                                    d,
                                                                                    g
                                                                                )
                                                                              : 1 ===
                                                                                d.nodeType
                                                                      )
                                                                          return !1;
                                                                  f = h =
                                                                      "only" ===
                                                                          e &&
                                                                      !f &&
                                                                      "nextSibling";
                                                              }
                                                              return !0;
                                                          }
                                                          if (
                                                              ((f = [
                                                                  a
                                                                      ? m.firstChild
                                                                      : m.lastChild,
                                                              ]),
                                                              a && b)
                                                          ) {
                                                              for (
                                                                  x =
                                                                      (p =
                                                                          (u =
                                                                              (l =
                                                                                  m[
                                                                                      v
                                                                                  ] ||
                                                                                  (m[
                                                                                      v
                                                                                  ] =
                                                                                      {}))[
                                                                                  e
                                                                              ] ||
                                                                              [])[0] ===
                                                                              y &&
                                                                          u[1]) &&
                                                                      u[2],
                                                                      d =
                                                                          p &&
                                                                          m
                                                                              .childNodes[
                                                                              p
                                                                          ];
                                                                  (d =
                                                                      (++p &&
                                                                          d &&
                                                                          d[
                                                                              h
                                                                          ]) ||
                                                                      (x = p =
                                                                          0) ||
                                                                      f.pop());

                                                              )
                                                                  if (
                                                                      1 ===
                                                                          d.nodeType &&
                                                                      ++x &&
                                                                      d === t
                                                                  ) {
                                                                      l[e] = [
                                                                          y,
                                                                          p,
                                                                          x,
                                                                      ];
                                                                      break;
                                                                  }
                                                          } else if (
                                                              (b &&
                                                                  (x = p =
                                                                      (u =
                                                                          (l =
                                                                              t[
                                                                                  v
                                                                              ] ||
                                                                              (t[
                                                                                  v
                                                                              ] =
                                                                                  {}))[
                                                                              e
                                                                          ] ||
                                                                          [])[0] ===
                                                                          y &&
                                                                      u[1]),
                                                              !1 === x)
                                                          )
                                                              for (
                                                                  ;
                                                                  (d =
                                                                      (++p &&
                                                                          d &&
                                                                          d[
                                                                              h
                                                                          ]) ||
                                                                      (x = p =
                                                                          0) ||
                                                                      f.pop()) &&
                                                                  (!(s
                                                                      ? A(d, g)
                                                                      : 1 ===
                                                                        d.nodeType) ||
                                                                      !++x ||
                                                                      (b &&
                                                                          ((l =
                                                                              d[
                                                                                  v
                                                                              ] ||
                                                                              (d[
                                                                                  v
                                                                              ] =
                                                                                  {}))[
                                                                              e
                                                                          ] = [
                                                                              y,
                                                                              x,
                                                                          ]),
                                                                      d !== t));

                                                              );
                                                          return (
                                                              (x -= o) === r ||
                                                              (x % r == 0 &&
                                                                  x / r >= 0)
                                                          );
                                                      }
                                                  };
                                        },
                                        PSEUDO: function (e, n) {
                                            var r,
                                                o =
                                                    t.pseudos[e] ||
                                                    t.setFilters[
                                                        e.toLowerCase()
                                                    ] ||
                                                    Z.error(
                                                        "unsupported pseudo: " +
                                                            e
                                                    );
                                            return o[v]
                                                ? o(n)
                                                : o.length > 1
                                                ? ((r = [e, e, "", n]),
                                                  t.setFilters.hasOwnProperty(
                                                      e.toLowerCase()
                                                  )
                                                      ? te(function (e, t) {
                                                            for (
                                                                var r,
                                                                    i = o(e, n),
                                                                    a =
                                                                        i.length;
                                                                a--;

                                                            )
                                                                e[
                                                                    (r = l.call(
                                                                        e,
                                                                        i[a]
                                                                    ))
                                                                ] = !(t[r] =
                                                                    i[a]);
                                                        })
                                                      : function (e) {
                                                            return o(e, 0, r);
                                                        })
                                                : o;
                                        },
                                    },
                                    pseudos: {
                                        not: te(function (e) {
                                            var t = [],
                                                n = [],
                                                r = ve(e.replace(N, "$1"));
                                            return r[v]
                                                ? te(function (e, t, n, o) {
                                                      for (
                                                          var i,
                                                              a = r(
                                                                  e,
                                                                  null,
                                                                  o,
                                                                  []
                                                              ),
                                                              s = e.length;
                                                          s--;

                                                      )
                                                          (i = a[s]) &&
                                                              (e[s] = !(t[s] =
                                                                  i));
                                                  })
                                                : function (e, o, i) {
                                                      return (
                                                          (t[0] = e),
                                                          r(t, null, i, n),
                                                          (t[0] = null),
                                                          !n.pop()
                                                      );
                                                  };
                                        }),
                                        has: te(function (e) {
                                            return function (t) {
                                                return Z(e, t).length > 0;
                                            };
                                        }),
                                        contains: te(function (e) {
                                            return (
                                                (e = e.replace(J, G)),
                                                function (t) {
                                                    return (
                                                        (
                                                            t.textContent ||
                                                            T.text(t)
                                                        ).indexOf(e) > -1
                                                    );
                                                }
                                            );
                                        }),
                                        lang: te(function (e) {
                                            return (
                                                Q.test(e || "") ||
                                                    Z.error(
                                                        "unsupported lang: " + e
                                                    ),
                                                (e = e
                                                    .replace(J, G)
                                                    .toLowerCase()),
                                                function (t) {
                                                    var n;
                                                    do {
                                                        if (
                                                            (n = d
                                                                ? t.lang
                                                                : t.getAttribute(
                                                                      "xml:lang"
                                                                  ) ||
                                                                  t.getAttribute(
                                                                      "lang"
                                                                  ))
                                                        )
                                                            return (
                                                                (n =
                                                                    n.toLowerCase()) ===
                                                                    e ||
                                                                0 ===
                                                                    n.indexOf(
                                                                        e + "-"
                                                                    )
                                                            );
                                                    } while (
                                                        (t = t.parentNode) &&
                                                        1 === t.nodeType
                                                    );
                                                    return !1;
                                                }
                                            );
                                        }),
                                        target: function (e) {
                                            var t =
                                                r.location && r.location.hash;
                                            return t && t.slice(1) === e.id;
                                        },
                                        root: function (e) {
                                            return e === u;
                                        },
                                        focus: function (e) {
                                            return (
                                                e ===
                                                    (function () {
                                                        try {
                                                            return c.activeElement;
                                                        } catch (e) {}
                                                    })() &&
                                                c.hasFocus() &&
                                                !!(
                                                    e.type ||
                                                    e.href ||
                                                    ~e.tabIndex
                                                )
                                            );
                                        },
                                        enabled: ie(!1),
                                        disabled: ie(!0),
                                        checked: function (e) {
                                            return (
                                                (A(e, "input") &&
                                                    !!e.checked) ||
                                                (A(e, "option") && !!e.selected)
                                            );
                                        },
                                        selected: function (e) {
                                            return (
                                                e.parentNode &&
                                                    e.parentNode.selectedIndex,
                                                !0 === e.selected
                                            );
                                        },
                                        empty: function (e) {
                                            for (
                                                e = e.firstChild;
                                                e;
                                                e = e.nextSibling
                                            )
                                                if (e.nodeType < 6) return !1;
                                            return !0;
                                        },
                                        parent: function (e) {
                                            return !t.pseudos.empty(e);
                                        },
                                        header: function (e) {
                                            return U.test(e.nodeName);
                                        },
                                        input: function (e) {
                                            return z.test(e.nodeName);
                                        },
                                        button: function (e) {
                                            return (
                                                (A(e, "input") &&
                                                    "button" === e.type) ||
                                                A(e, "button")
                                            );
                                        },
                                        text: function (e) {
                                            var t;
                                            return (
                                                A(e, "input") &&
                                                "text" === e.type &&
                                                (null ==
                                                    (t =
                                                        e.getAttribute(
                                                            "type"
                                                        )) ||
                                                    "text" === t.toLowerCase())
                                            );
                                        },
                                        first: ae(function () {
                                            return [0];
                                        }),
                                        last: ae(function (e, t) {
                                            return [t - 1];
                                        }),
                                        eq: ae(function (e, t, n) {
                                            return [n < 0 ? n + t : n];
                                        }),
                                        even: ae(function (e, t) {
                                            for (var n = 0; n < t; n += 2)
                                                e.push(n);
                                            return e;
                                        }),
                                        odd: ae(function (e, t) {
                                            for (var n = 1; n < t; n += 2)
                                                e.push(n);
                                            return e;
                                        }),
                                        lt: ae(function (e, t, n) {
                                            var r;
                                            for (
                                                r =
                                                    n < 0
                                                        ? n + t
                                                        : n > t
                                                        ? t
                                                        : n;
                                                --r >= 0;

                                            )
                                                e.push(r);
                                            return e;
                                        }),
                                        gt: ae(function (e, t, n) {
                                            for (
                                                var r = n < 0 ? n + t : n;
                                                ++r < t;

                                            )
                                                e.push(r);
                                            return e;
                                        }),
                                    },
                                }).pseudos.nth = t.pseudos.eq),
                            {
                                radio: !0,
                                checkbox: !0,
                                file: !0,
                                password: !0,
                                image: !0,
                            }))
                                t.pseudos[e] = re(e);
                            for (e in { submit: !0, reset: !0 })
                                t.pseudos[e] = oe(e);
                            function ue() {}
                            function le(e, n) {
                                var r,
                                    o,
                                    i,
                                    a,
                                    s,
                                    c,
                                    u,
                                    l = w[e + " "];
                                if (l) return n ? 0 : l.slice(0);
                                for (s = e, c = [], u = t.preFilter; s; ) {
                                    for (a in ((r && !(o = M.exec(s))) ||
                                        (o && (s = s.slice(o[0].length) || s),
                                        c.push((i = []))),
                                    (r = !1),
                                    (o = I.exec(s)) &&
                                        ((r = o.shift()),
                                        i.push({
                                            value: r,
                                            type: o[0].replace(N, " "),
                                        }),
                                        (s = s.slice(r.length))),
                                    t.filter))
                                        !(o = B[a].exec(s)) ||
                                            (u[a] && !(o = u[a](o))) ||
                                            ((r = o.shift()),
                                            i.push({
                                                value: r,
                                                type: a,
                                                matches: o,
                                            }),
                                            (s = s.slice(r.length)));
                                    if (!r) break;
                                }
                                return n
                                    ? s.length
                                    : s
                                    ? Z.error(e)
                                    : w(e, c).slice(0);
                            }
                            function de(e) {
                                for (
                                    var t = 0, n = e.length, r = "";
                                    t < n;
                                    t++
                                )
                                    r += e[t].value;
                                return r;
                            }
                            function pe(e, t, n) {
                                var r = t.dir,
                                    o = t.next,
                                    i = o || r,
                                    a = n && "parentNode" === i,
                                    s = b++;
                                return t.first
                                    ? function (t, n, o) {
                                          for (; (t = t[r]); )
                                              if (1 === t.nodeType || a)
                                                  return e(t, n, o);
                                          return !1;
                                      }
                                    : function (t, n, c) {
                                          var u,
                                              l,
                                              d = [y, s];
                                          if (c) {
                                              for (; (t = t[r]); )
                                                  if (
                                                      (1 === t.nodeType || a) &&
                                                      e(t, n, c)
                                                  )
                                                      return !0;
                                          } else
                                              for (; (t = t[r]); )
                                                  if (1 === t.nodeType || a)
                                                      if (
                                                          ((l =
                                                              t[v] ||
                                                              (t[v] = {})),
                                                          o && A(t, o))
                                                      )
                                                          t = t[r] || t;
                                                      else {
                                                          if (
                                                              (u = l[i]) &&
                                                              u[0] === y &&
                                                              u[1] === s
                                                          )
                                                              return (d[2] =
                                                                  u[2]);
                                                          if (
                                                              ((l[i] = d),
                                                              (d[2] = e(
                                                                  t,
                                                                  n,
                                                                  c
                                                              )))
                                                          )
                                                              return !0;
                                                      }
                                          return !1;
                                      };
                            }
                            function fe(e) {
                                return e.length > 1
                                    ? function (t, n, r) {
                                          for (var o = e.length; o--; )
                                              if (!e[o](t, n, r)) return !1;
                                          return !0;
                                      }
                                    : e[0];
                            }
                            function he(e, t, n, r, o) {
                                for (
                                    var i,
                                        a = [],
                                        s = 0,
                                        c = e.length,
                                        u = null != t;
                                    s < c;
                                    s++
                                )
                                    (i = e[s]) &&
                                        ((n && !n(i, r, o)) ||
                                            (a.push(i), u && t.push(s)));
                                return a;
                            }
                            function me(e, t, n, r, o, i) {
                                return (
                                    r && !r[v] && (r = me(r)),
                                    o && !o[v] && (o = me(o, i)),
                                    te(function (i, a, s, c) {
                                        var u,
                                            d,
                                            p,
                                            f,
                                            h = [],
                                            g = [],
                                            v = a.length,
                                            y =
                                                i ||
                                                (function (e, t, n) {
                                                    for (
                                                        var r = 0, o = t.length;
                                                        r < o;
                                                        r++
                                                    )
                                                        Z(e, t[r], n);
                                                    return n;
                                                })(
                                                    t || "*",
                                                    s.nodeType ? [s] : s,
                                                    []
                                                ),
                                            b =
                                                !e || (!i && t)
                                                    ? y
                                                    : he(y, h, e, s, c);
                                        if (
                                            (n
                                                ? n(
                                                      b,
                                                      (f =
                                                          o || (i ? e : v || r)
                                                              ? []
                                                              : a),
                                                      s,
                                                      c
                                                  )
                                                : (f = b),
                                            r)
                                        )
                                            for (
                                                u = he(f, g),
                                                    r(u, [], s, c),
                                                    d = u.length;
                                                d--;

                                            )
                                                (p = u[d]) &&
                                                    (f[g[d]] = !(b[g[d]] = p));
                                        if (i) {
                                            if (o || e) {
                                                if (o) {
                                                    for (
                                                        u = [], d = f.length;
                                                        d--;

                                                    )
                                                        (p = f[d]) &&
                                                            u.push((b[d] = p));
                                                    o(null, (f = []), u, c);
                                                }
                                                for (d = f.length; d--; )
                                                    (p = f[d]) &&
                                                        (u = o
                                                            ? l.call(i, p)
                                                            : h[d]) > -1 &&
                                                        (i[u] = !(a[u] = p));
                                            }
                                        } else (f = he(f === a ? f.splice(v, f.length) : f)), o ? o(null, a, f, c) : m.apply(a, f);
                                    })
                                );
                            }
                            function ge(e) {
                                for (
                                    var r,
                                        o,
                                        i,
                                        a = e.length,
                                        s = t.relative[e[0].type],
                                        c = s || t.relative[" "],
                                        u = s ? 1 : 0,
                                        d = pe(
                                            function (e) {
                                                return e === r;
                                            },
                                            c,
                                            !0
                                        ),
                                        p = pe(
                                            function (e) {
                                                return l.call(r, e) > -1;
                                            },
                                            c,
                                            !0
                                        ),
                                        f = [
                                            function (e, t, o) {
                                                var i =
                                                    (!s && (o || t != n)) ||
                                                    ((r = t).nodeType
                                                        ? d(e, t, o)
                                                        : p(e, t, o));
                                                return (r = null), i;
                                            },
                                        ];
                                    u < a;
                                    u++
                                )
                                    if ((o = t.relative[e[u].type]))
                                        f = [pe(fe(f), o)];
                                    else {
                                        if (
                                            (o = t.filter[e[u].type].apply(
                                                null,
                                                e[u].matches
                                            ))[v]
                                        ) {
                                            for (
                                                i = ++u;
                                                i < a && !t.relative[e[i].type];
                                                i++
                                            );
                                            return me(
                                                u > 1 && fe(f),
                                                u > 1 &&
                                                    de(
                                                        e
                                                            .slice(0, u - 1)
                                                            .concat({
                                                                value:
                                                                    " " ===
                                                                    e[u - 2]
                                                                        .type
                                                                        ? "*"
                                                                        : "",
                                                            })
                                                    ).replace(N, "$1"),
                                                o,
                                                u < i && ge(e.slice(u, i)),
                                                i < a && ge((e = e.slice(i))),
                                                i < a && de(e)
                                            );
                                        }
                                        f.push(o);
                                    }
                                return fe(f);
                            }
                            function ve(e, r) {
                                var o,
                                    i = [],
                                    a = [],
                                    s = j[e + " "];
                                if (!s) {
                                    for (r || (r = le(e)), o = r.length; o--; )
                                        (s = ge(r[o]))[v]
                                            ? i.push(s)
                                            : a.push(s);
                                    (s = j(
                                        e,
                                        (function (e, r) {
                                            var o = r.length > 0,
                                                i = e.length > 0,
                                                a = function (a, s, u, l, p) {
                                                    var f,
                                                        h,
                                                        g,
                                                        v = 0,
                                                        b = "0",
                                                        x = a && [],
                                                        w = [],
                                                        j = n,
                                                        k =
                                                            a ||
                                                            (i &&
                                                                t.find.TAG(
                                                                    "*",
                                                                    p
                                                                )),
                                                        C = (y +=
                                                            null == j
                                                                ? 1
                                                                : Math.random() ||
                                                                  0.1),
                                                        S = k.length;
                                                    for (
                                                        p &&
                                                        (n = s == c || s || p);
                                                        b !== S &&
                                                        null != (f = k[b]);
                                                        b++
                                                    ) {
                                                        if (i && f) {
                                                            for (
                                                                h = 0,
                                                                    s ||
                                                                        f.ownerDocument ==
                                                                            c ||
                                                                        (ce(f),
                                                                        (u =
                                                                            !d));
                                                                (g = e[h++]);

                                                            )
                                                                if (
                                                                    g(
                                                                        f,
                                                                        s || c,
                                                                        u
                                                                    )
                                                                ) {
                                                                    m.call(
                                                                        l,
                                                                        f
                                                                    );
                                                                    break;
                                                                }
                                                            p && (y = C);
                                                        }
                                                        o &&
                                                            ((f = !g && f) &&
                                                                v--,
                                                            a && x.push(f));
                                                    }
                                                    if (
                                                        ((v += b), o && b !== v)
                                                    ) {
                                                        for (
                                                            h = 0;
                                                            (g = r[h++]);

                                                        )
                                                            g(x, w, s, u);
                                                        if (a) {
                                                            if (v > 0)
                                                                for (; b--; )
                                                                    x[b] ||
                                                                        w[b] ||
                                                                        (w[b] =
                                                                            E.call(
                                                                                l
                                                                            ));
                                                            w = he(w);
                                                        }
                                                        m.apply(l, w),
                                                            p &&
                                                                !a &&
                                                                w.length > 0 &&
                                                                v + r.length >
                                                                    1 &&
                                                                T.uniqueSort(l);
                                                    }
                                                    return (
                                                        p && ((y = C), (n = j)),
                                                        x
                                                    );
                                                };
                                            return o ? te(a) : a;
                                        })(a, i)
                                    )),
                                        (s.selector = e);
                                }
                                return s;
                            }
                            function ye(e, n, r, o) {
                                var i,
                                    a,
                                    s,
                                    c,
                                    u,
                                    l = "function" == typeof e && e,
                                    p = !o && le((e = l.selector || e));
                                if (((r = r || []), 1 === p.length)) {
                                    if (
                                        (a = p[0] = p[0].slice(0)).length > 2 &&
                                        "ID" === (s = a[0]).type &&
                                        9 === n.nodeType &&
                                        d &&
                                        t.relative[a[1].type]
                                    ) {
                                        if (
                                            !(n = (t.find.ID(
                                                s.matches[0].replace(J, G),
                                                n
                                            ) || [])[0])
                                        )
                                            return r;
                                        l && (n = n.parentNode),
                                            (e = e.slice(
                                                a.shift().value.length
                                            ));
                                    }
                                    for (
                                        i = B.needsContext.test(e)
                                            ? 0
                                            : a.length;
                                        i-- &&
                                        ((s = a[i]), !t.relative[(c = s.type)]);

                                    )
                                        if (
                                            (u = t.find[c]) &&
                                            (o = u(
                                                s.matches[0].replace(J, G),
                                                (V.test(a[0].type) &&
                                                    se(n.parentNode)) ||
                                                    n
                                            ))
                                        ) {
                                            if (
                                                (a.splice(i, 1),
                                                !(e = o.length && de(a)))
                                            )
                                                return m.apply(r, o), r;
                                            break;
                                        }
                                }
                                return (
                                    (l || ve(e, p))(
                                        o,
                                        n,
                                        !d,
                                        r,
                                        !n ||
                                            (V.test(e) && se(n.parentNode)) ||
                                            n
                                    ),
                                    r
                                );
                            }
                            (ue.prototype = t.filters = t.pseudos),
                                (t.setFilters = new ue()),
                                (g.sortStable =
                                    v.split("").sort(C).join("") === v),
                                ce(),
                                (g.sortDetached = ne(function (e) {
                                    return (
                                        1 &
                                        e.compareDocumentPosition(
                                            c.createElement("fieldset")
                                        )
                                    );
                                })),
                                (T.find = Z),
                                (T.expr[":"] = T.expr.pseudos),
                                (T.unique = T.uniqueSort),
                                (Z.compile = ve),
                                (Z.select = ye),
                                (Z.setDocument = ce),
                                (Z.tokenize = le),
                                (Z.escape = T.escapeSelector),
                                (Z.getText = T.text),
                                (Z.isXML = T.isXMLDoc),
                                (Z.selectors = T.expr),
                                (Z.support = T.support),
                                (Z.uniqueSort = T.uniqueSort);
                        })();
                        var L = function (e, t, n) {
                                for (
                                    var r = [], o = void 0 !== n;
                                    (e = e[t]) && 9 !== e.nodeType;

                                )
                                    if (1 === e.nodeType) {
                                        if (o && T(e).is(n)) break;
                                        r.push(e);
                                    }
                                return r;
                            },
                            R = function (e, t) {
                                for (var n = []; e; e = e.nextSibling)
                                    1 === e.nodeType && e !== t && n.push(e);
                                return n;
                            },
                            M = T.expr.match.needsContext,
                            I =
                                /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
                        function W(e, t, n) {
                            return v(t)
                                ? T.grep(e, function (e, r) {
                                      return !!t.call(e, r, e) !== n;
                                  })
                                : t.nodeType
                                ? T.grep(e, function (e) {
                                      return (e === t) !== n;
                                  })
                                : "string" != typeof t
                                ? T.grep(e, function (e) {
                                      return l.call(t, e) > -1 !== n;
                                  })
                                : T.filter(t, e, n);
                        }
                        (T.filter = function (e, t, n) {
                            var r = t[0];
                            return (
                                n && (e = ":not(" + e + ")"),
                                1 === t.length && 1 === r.nodeType
                                    ? T.find.matchesSelector(r, e)
                                        ? [r]
                                        : []
                                    : T.find.matches(
                                          e,
                                          T.grep(t, function (e) {
                                              return 1 === e.nodeType;
                                          })
                                      )
                            );
                        }),
                            T.fn.extend({
                                find: function (e) {
                                    var t,
                                        n,
                                        r = this.length,
                                        o = this;
                                    if ("string" != typeof e)
                                        return this.pushStack(
                                            T(e).filter(function () {
                                                for (t = 0; t < r; t++)
                                                    if (T.contains(o[t], this))
                                                        return !0;
                                            })
                                        );
                                    for (
                                        n = this.pushStack([]), t = 0;
                                        t < r;
                                        t++
                                    )
                                        T.find(e, o[t], n);
                                    return r > 1 ? T.uniqueSort(n) : n;
                                },
                                filter: function (e) {
                                    return this.pushStack(W(this, e || [], !1));
                                },
                                not: function (e) {
                                    return this.pushStack(W(this, e || [], !0));
                                },
                                is: function (e) {
                                    return !!W(
                                        this,
                                        "string" == typeof e && M.test(e)
                                            ? T(e)
                                            : e || [],
                                        !1
                                    ).length;
                                },
                            });
                        var F,
                            Q = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
                        ((T.fn.init = function (e, t, n) {
                            var r, o;
                            if (!e) return this;
                            if (((n = n || F), "string" == typeof e)) {
                                if (
                                    !(r =
                                        "<" === e[0] &&
                                        ">" === e[e.length - 1] &&
                                        e.length >= 3
                                            ? [null, e, null]
                                            : Q.exec(e)) ||
                                    (!r[1] && t)
                                )
                                    return !t || t.jquery
                                        ? (t || n).find(e)
                                        : this.constructor(t).find(e);
                                if (r[1]) {
                                    if (
                                        ((t = t instanceof T ? t[0] : t),
                                        T.merge(
                                            this,
                                            T.parseHTML(
                                                r[1],
                                                t && t.nodeType
                                                    ? t.ownerDocument || t
                                                    : b,
                                                !0
                                            )
                                        ),
                                        I.test(r[1]) && T.isPlainObject(t))
                                    )
                                        for (r in t)
                                            v(this[r])
                                                ? this[r](t[r])
                                                : this.attr(r, t[r]);
                                    return this;
                                }
                                return (
                                    (o = b.getElementById(r[2])) &&
                                        ((this[0] = o), (this.length = 1)),
                                    this
                                );
                            }
                            return e.nodeType
                                ? ((this[0] = e), (this.length = 1), this)
                                : v(e)
                                ? void 0 !== n.ready
                                    ? n.ready(e)
                                    : e(T)
                                : T.makeArray(e, this);
                        }).prototype = T.fn),
                            (F = T(b));
                        var B = /^(?:parents|prev(?:Until|All))/,
                            z = {
                                children: !0,
                                contents: !0,
                                next: !0,
                                prev: !0,
                            };
                        function U(e, t) {
                            for (; (e = e[t]) && 1 !== e.nodeType; );
                            return e;
                        }
                        T.fn.extend({
                            has: function (e) {
                                var t = T(e, this),
                                    n = t.length;
                                return this.filter(function () {
                                    for (var e = 0; e < n; e++)
                                        if (T.contains(this, t[e])) return !0;
                                });
                            },
                            closest: function (e, t) {
                                var n,
                                    r = 0,
                                    o = this.length,
                                    i = [],
                                    a = "string" != typeof e && T(e);
                                if (!M.test(e))
                                    for (; r < o; r++)
                                        for (
                                            n = this[r];
                                            n && n !== t;
                                            n = n.parentNode
                                        )
                                            if (
                                                n.nodeType < 11 &&
                                                (a
                                                    ? a.index(n) > -1
                                                    : 1 === n.nodeType &&
                                                      T.find.matchesSelector(
                                                          n,
                                                          e
                                                      ))
                                            ) {
                                                i.push(n);
                                                break;
                                            }
                                return this.pushStack(
                                    i.length > 1 ? T.uniqueSort(i) : i
                                );
                            },
                            index: function (e) {
                                return e
                                    ? "string" == typeof e
                                        ? l.call(T(e), this[0])
                                        : l.call(this, e.jquery ? e[0] : e)
                                    : this[0] && this[0].parentNode
                                    ? this.first().prevAll().length
                                    : -1;
                            },
                            add: function (e, t) {
                                return this.pushStack(
                                    T.uniqueSort(T.merge(this.get(), T(e, t)))
                                );
                            },
                            addBack: function (e) {
                                return this.add(
                                    null == e
                                        ? this.prevObject
                                        : this.prevObject.filter(e)
                                );
                            },
                        }),
                            T.each(
                                {
                                    parent: function (e) {
                                        var t = e.parentNode;
                                        return t && 11 !== t.nodeType
                                            ? t
                                            : null;
                                    },
                                    parents: function (e) {
                                        return L(e, "parentNode");
                                    },
                                    parentsUntil: function (e, t, n) {
                                        return L(e, "parentNode", n);
                                    },
                                    next: function (e) {
                                        return U(e, "nextSibling");
                                    },
                                    prev: function (e) {
                                        return U(e, "previousSibling");
                                    },
                                    nextAll: function (e) {
                                        return L(e, "nextSibling");
                                    },
                                    prevAll: function (e) {
                                        return L(e, "previousSibling");
                                    },
                                    nextUntil: function (e, t, n) {
                                        return L(e, "nextSibling", n);
                                    },
                                    prevUntil: function (e, t, n) {
                                        return L(e, "previousSibling", n);
                                    },
                                    siblings: function (e) {
                                        return R(
                                            (e.parentNode || {}).firstChild,
                                            e
                                        );
                                    },
                                    children: function (e) {
                                        return R(e.firstChild);
                                    },
                                    contents: function (e) {
                                        return null != e.contentDocument &&
                                            a(e.contentDocument)
                                            ? e.contentDocument
                                            : (A(e, "template") &&
                                                  (e = e.content || e),
                                              T.merge([], e.childNodes));
                                    },
                                },
                                function (e, t) {
                                    T.fn[e] = function (n, r) {
                                        var o = T.map(this, t, n);
                                        return (
                                            "Until" !== e.slice(-5) && (r = n),
                                            r &&
                                                "string" == typeof r &&
                                                (o = T.filter(r, o)),
                                            this.length > 1 &&
                                                (z[e] || T.uniqueSort(o),
                                                B.test(e) && o.reverse()),
                                            this.pushStack(o)
                                        );
                                    };
                                }
                            );
                        var X = /[^\x20\t\r\n\f]+/g;
                        function V(e) {
                            return e;
                        }
                        function J(e) {
                            throw e;
                        }
                        function G(e, t, n, r) {
                            var o;
                            try {
                                e && v((o = e.promise))
                                    ? o.call(e).done(t).fail(n)
                                    : e && v((o = e.then))
                                    ? o.call(e, t, n)
                                    : t.apply(void 0, [e].slice(r));
                            } catch (e) {
                                n.apply(void 0, [e]);
                            }
                        }
                        (T.Callbacks = function (e) {
                            e =
                                "string" == typeof e
                                    ? (function (e) {
                                          var t = {};
                                          return (
                                              T.each(
                                                  e.match(X) || [],
                                                  function (e, n) {
                                                      t[n] = !0;
                                                  }
                                              ),
                                              t
                                          );
                                      })(e)
                                    : T.extend({}, e);
                            var t,
                                n,
                                r,
                                o,
                                i = [],
                                a = [],
                                s = -1,
                                c = function () {
                                    for (
                                        o = o || e.once, r = t = !0;
                                        a.length;
                                        s = -1
                                    )
                                        for (n = a.shift(); ++s < i.length; )
                                            !1 === i[s].apply(n[0], n[1]) &&
                                                e.stopOnFalse &&
                                                ((s = i.length), (n = !1));
                                    e.memory || (n = !1),
                                        (t = !1),
                                        o && (i = n ? [] : "");
                                },
                                u = {
                                    add: function () {
                                        return (
                                            i &&
                                                (n &&
                                                    !t &&
                                                    ((s = i.length - 1),
                                                    a.push(n)),
                                                (function t(n) {
                                                    T.each(n, function (n, r) {
                                                        v(r)
                                                            ? (e.unique &&
                                                                  u.has(r)) ||
                                                              i.push(r)
                                                            : r &&
                                                              r.length &&
                                                              "string" !==
                                                                  j(r) &&
                                                              t(r);
                                                    });
                                                })(arguments),
                                                n && !t && c()),
                                            this
                                        );
                                    },
                                    remove: function () {
                                        return (
                                            T.each(arguments, function (e, t) {
                                                for (
                                                    var n;
                                                    (n = T.inArray(t, i, n)) >
                                                    -1;

                                                )
                                                    i.splice(n, 1),
                                                        n <= s && s--;
                                            }),
                                            this
                                        );
                                    },
                                    has: function (e) {
                                        return e
                                            ? T.inArray(e, i) > -1
                                            : i.length > 0;
                                    },
                                    empty: function () {
                                        return i && (i = []), this;
                                    },
                                    disable: function () {
                                        return (o = a = []), (i = n = ""), this;
                                    },
                                    disabled: function () {
                                        return !i;
                                    },
                                    lock: function () {
                                        return (
                                            (o = a = []),
                                            n || t || (i = n = ""),
                                            this
                                        );
                                    },
                                    locked: function () {
                                        return !!o;
                                    },
                                    fireWith: function (e, n) {
                                        return (
                                            o ||
                                                ((n = [
                                                    e,
                                                    (n = n || []).slice
                                                        ? n.slice()
                                                        : n,
                                                ]),
                                                a.push(n),
                                                t || c()),
                                            this
                                        );
                                    },
                                    fire: function () {
                                        return (
                                            u.fireWith(this, arguments), this
                                        );
                                    },
                                    fired: function () {
                                        return !!r;
                                    },
                                };
                            return u;
                        }),
                            T.extend({
                                Deferred: function (e) {
                                    var t = [
                                            [
                                                "notify",
                                                "progress",
                                                T.Callbacks("memory"),
                                                T.Callbacks("memory"),
                                                2,
                                            ],
                                            [
                                                "resolve",
                                                "done",
                                                T.Callbacks("once memory"),
                                                T.Callbacks("once memory"),
                                                0,
                                                "resolved",
                                            ],
                                            [
                                                "reject",
                                                "fail",
                                                T.Callbacks("once memory"),
                                                T.Callbacks("once memory"),
                                                1,
                                                "rejected",
                                            ],
                                        ],
                                        n = "pending",
                                        o = {
                                            state: function () {
                                                return n;
                                            },
                                            always: function () {
                                                return (
                                                    i
                                                        .done(arguments)
                                                        .fail(arguments),
                                                    this
                                                );
                                            },
                                            catch: function (e) {
                                                return o.then(null, e);
                                            },
                                            pipe: function () {
                                                var e = arguments;
                                                return T.Deferred(function (n) {
                                                    T.each(t, function (t, r) {
                                                        var o =
                                                            v(e[r[4]]) &&
                                                            e[r[4]];
                                                        i[r[1]](function () {
                                                            var e =
                                                                o &&
                                                                o.apply(
                                                                    this,
                                                                    arguments
                                                                );
                                                            e && v(e.promise)
                                                                ? e
                                                                      .promise()
                                                                      .progress(
                                                                          n.notify
                                                                      )
                                                                      .done(
                                                                          n.resolve
                                                                      )
                                                                      .fail(
                                                                          n.reject
                                                                      )
                                                                : n[
                                                                      r[0] +
                                                                          "With"
                                                                  ](
                                                                      this,
                                                                      o
                                                                          ? [e]
                                                                          : arguments
                                                                  );
                                                        });
                                                    }),
                                                        (e = null);
                                                }).promise();
                                            },
                                            then: function (e, n, o) {
                                                var i = 0;
                                                function a(e, t, n, o) {
                                                    return function () {
                                                        var s = this,
                                                            c = arguments,
                                                            u = function () {
                                                                var r, u;
                                                                if (!(e < i)) {
                                                                    if (
                                                                        (r =
                                                                            n.apply(
                                                                                s,
                                                                                c
                                                                            )) ===
                                                                        t.promise()
                                                                    )
                                                                        throw new TypeError(
                                                                            "Thenable self-resolution"
                                                                        );
                                                                    (u =
                                                                        r &&
                                                                        ("object" ==
                                                                            typeof r ||
                                                                            "function" ==
                                                                                typeof r) &&
                                                                        r.then),
                                                                        v(u)
                                                                            ? o
                                                                                ? u.call(
                                                                                      r,
                                                                                      a(
                                                                                          i,
                                                                                          t,
                                                                                          V,
                                                                                          o
                                                                                      ),
                                                                                      a(
                                                                                          i,
                                                                                          t,
                                                                                          J,
                                                                                          o
                                                                                      )
                                                                                  )
                                                                                : (i++,
                                                                                  u.call(
                                                                                      r,
                                                                                      a(
                                                                                          i,
                                                                                          t,
                                                                                          V,
                                                                                          o
                                                                                      ),
                                                                                      a(
                                                                                          i,
                                                                                          t,
                                                                                          J,
                                                                                          o
                                                                                      ),
                                                                                      a(
                                                                                          i,
                                                                                          t,
                                                                                          V,
                                                                                          t.notifyWith
                                                                                      )
                                                                                  ))
                                                                            : (n !==
                                                                                  V &&
                                                                                  ((s =
                                                                                      void 0),
                                                                                  (c =
                                                                                      [
                                                                                          r,
                                                                                      ])),
                                                                              (
                                                                                  o ||
                                                                                  t.resolveWith
                                                                              )(
                                                                                  s,
                                                                                  c
                                                                              ));
                                                                }
                                                            },
                                                            l = o
                                                                ? u
                                                                : function () {
                                                                      try {
                                                                          u();
                                                                      } catch (r) {
                                                                          T
                                                                              .Deferred
                                                                              .exceptionHook &&
                                                                              T.Deferred.exceptionHook(
                                                                                  r,
                                                                                  l.error
                                                                              ),
                                                                              e +
                                                                                  1 >=
                                                                                  i &&
                                                                                  (n !==
                                                                                      J &&
                                                                                      ((s =
                                                                                          void 0),
                                                                                      (c =
                                                                                          [
                                                                                              r,
                                                                                          ])),
                                                                                  t.rejectWith(
                                                                                      s,
                                                                                      c
                                                                                  ));
                                                                      }
                                                                  };
                                                        e
                                                            ? l()
                                                            : (T.Deferred
                                                                  .getErrorHook
                                                                  ? (l.error =
                                                                        T.Deferred.getErrorHook())
                                                                  : T.Deferred
                                                                        .getStackHook &&
                                                                    (l.error =
                                                                        T.Deferred.getStackHook()),
                                                              r.setTimeout(l));
                                                    };
                                                }
                                                return T.Deferred(function (r) {
                                                    t[0][3].add(
                                                        a(
                                                            0,
                                                            r,
                                                            v(o) ? o : V,
                                                            r.notifyWith
                                                        )
                                                    ),
                                                        t[1][3].add(
                                                            a(
                                                                0,
                                                                r,
                                                                v(e) ? e : V
                                                            )
                                                        ),
                                                        t[2][3].add(
                                                            a(
                                                                0,
                                                                r,
                                                                v(n) ? n : J
                                                            )
                                                        );
                                                }).promise();
                                            },
                                            promise: function (e) {
                                                return null != e
                                                    ? T.extend(e, o)
                                                    : o;
                                            },
                                        },
                                        i = {};
                                    return (
                                        T.each(t, function (e, r) {
                                            var a = r[2],
                                                s = r[5];
                                            (o[r[1]] = a.add),
                                                s &&
                                                    a.add(
                                                        function () {
                                                            n = s;
                                                        },
                                                        t[3 - e][2].disable,
                                                        t[3 - e][3].disable,
                                                        t[0][2].lock,
                                                        t[0][3].lock
                                                    ),
                                                a.add(r[3].fire),
                                                (i[r[0]] = function () {
                                                    return (
                                                        i[r[0] + "With"](
                                                            this === i
                                                                ? void 0
                                                                : this,
                                                            arguments
                                                        ),
                                                        this
                                                    );
                                                }),
                                                (i[r[0] + "With"] = a.fireWith);
                                        }),
                                        o.promise(i),
                                        e && e.call(i, i),
                                        i
                                    );
                                },
                                when: function (e) {
                                    var t = arguments.length,
                                        n = t,
                                        r = Array(n),
                                        o = s.call(arguments),
                                        i = T.Deferred(),
                                        a = function (e) {
                                            return function (n) {
                                                (r[e] = this),
                                                    (o[e] =
                                                        arguments.length > 1
                                                            ? s.call(arguments)
                                                            : n),
                                                    --t || i.resolveWith(r, o);
                                            };
                                        };
                                    if (
                                        t <= 1 &&
                                        (G(
                                            e,
                                            i.done(a(n)).resolve,
                                            i.reject,
                                            !t
                                        ),
                                        "pending" === i.state() ||
                                            v(o[n] && o[n].then))
                                    )
                                        return i.then();
                                    for (; n--; ) G(o[n], a(n), i.reject);
                                    return i.promise();
                                },
                            });
                        var Y =
                            /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
                        (T.Deferred.exceptionHook = function (e, t) {
                            r.console &&
                                r.console.warn &&
                                e &&
                                Y.test(e.name) &&
                                r.console.warn(
                                    "jQuery.Deferred exception: " + e.message,
                                    e.stack,
                                    t
                                );
                        }),
                            (T.readyException = function (e) {
                                r.setTimeout(function () {
                                    throw e;
                                });
                            });
                        var K = T.Deferred();
                        function Z() {
                            b.removeEventListener("DOMContentLoaded", Z),
                                r.removeEventListener("load", Z),
                                T.ready();
                        }
                        (T.fn.ready = function (e) {
                            return (
                                K.then(e).catch(function (e) {
                                    T.readyException(e);
                                }),
                                this
                            );
                        }),
                            T.extend({
                                isReady: !1,
                                readyWait: 1,
                                ready: function (e) {
                                    (!0 === e ? --T.readyWait : T.isReady) ||
                                        ((T.isReady = !0),
                                        (!0 !== e && --T.readyWait > 0) ||
                                            K.resolveWith(b, [T]));
                                },
                            }),
                            (T.ready.then = K.then),
                            "complete" === b.readyState ||
                            ("loading" !== b.readyState &&
                                !b.documentElement.doScroll)
                                ? r.setTimeout(T.ready)
                                : (b.addEventListener("DOMContentLoaded", Z),
                                  r.addEventListener("load", Z));
                        var ee = function (e, t, n, r, o, i, a) {
                                var s = 0,
                                    c = e.length,
                                    u = null == n;
                                if ("object" === j(n))
                                    for (s in ((o = !0), n))
                                        ee(e, t, s, n[s], !0, i, a);
                                else if (
                                    void 0 !== r &&
                                    ((o = !0),
                                    v(r) || (a = !0),
                                    u &&
                                        (a
                                            ? (t.call(e, r), (t = null))
                                            : ((u = t),
                                              (t = function (e, t, n) {
                                                  return u.call(T(e), n);
                                              }))),
                                    t)
                                )
                                    for (; s < c; s++)
                                        t(
                                            e[s],
                                            n,
                                            a ? r : r.call(e[s], s, t(e[s], n))
                                        );
                                return o
                                    ? e
                                    : u
                                    ? t.call(e)
                                    : c
                                    ? t(e[0], n)
                                    : i;
                            },
                            te = /^-ms-/,
                            ne = /-([a-z])/g;
                        function re(e, t) {
                            return t.toUpperCase();
                        }
                        function oe(e) {
                            return e.replace(te, "ms-").replace(ne, re);
                        }
                        var ie = function (e) {
                            return (
                                1 === e.nodeType ||
                                9 === e.nodeType ||
                                !+e.nodeType
                            );
                        };
                        function ae() {
                            this.expando = T.expando + ae.uid++;
                        }
                        (ae.uid = 1),
                            (ae.prototype = {
                                cache: function (e) {
                                    var t = e[this.expando];
                                    return (
                                        t ||
                                            ((t = {}),
                                            ie(e) &&
                                                (e.nodeType
                                                    ? (e[this.expando] = t)
                                                    : Object.defineProperty(
                                                          e,
                                                          this.expando,
                                                          {
                                                              value: t,
                                                              configurable: !0,
                                                          }
                                                      ))),
                                        t
                                    );
                                },
                                set: function (e, t, n) {
                                    var r,
                                        o = this.cache(e);
                                    if ("string" == typeof t) o[oe(t)] = n;
                                    else for (r in t) o[oe(r)] = t[r];
                                    return o;
                                },
                                get: function (e, t) {
                                    return void 0 === t
                                        ? this.cache(e)
                                        : e[this.expando] &&
                                              e[this.expando][oe(t)];
                                },
                                access: function (e, t, n) {
                                    return void 0 === t ||
                                        (t &&
                                            "string" == typeof t &&
                                            void 0 === n)
                                        ? this.get(e, t)
                                        : (this.set(e, t, n),
                                          void 0 !== n ? n : t);
                                },
                                remove: function (e, t) {
                                    var n,
                                        r = e[this.expando];
                                    if (void 0 !== r) {
                                        if (void 0 !== t) {
                                            n = (t = Array.isArray(t)
                                                ? t.map(oe)
                                                : (t = oe(t)) in r
                                                ? [t]
                                                : t.match(X) || []).length;
                                            for (; n--; ) delete r[t[n]];
                                        }
                                        (void 0 === t || T.isEmptyObject(r)) &&
                                            (e.nodeType
                                                ? (e[this.expando] = void 0)
                                                : delete e[this.expando]);
                                    }
                                },
                                hasData: function (e) {
                                    var t = e[this.expando];
                                    return void 0 !== t && !T.isEmptyObject(t);
                                },
                            });
                        var se = new ae(),
                            ce = new ae(),
                            ue = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
                            le = /[A-Z]/g;
                        function de(e, t, n) {
                            var r;
                            if (void 0 === n && 1 === e.nodeType)
                                if (
                                    ((r =
                                        "data-" +
                                        t.replace(le, "-$&").toLowerCase()),
                                    "string" == typeof (n = e.getAttribute(r)))
                                ) {
                                    try {
                                        n = (function (e) {
                                            return (
                                                "true" === e ||
                                                ("false" !== e &&
                                                    ("null" === e
                                                        ? null
                                                        : e === +e + ""
                                                        ? +e
                                                        : ue.test(e)
                                                        ? JSON.parse(e)
                                                        : e))
                                            );
                                        })(n);
                                    } catch (e) {}
                                    ce.set(e, t, n);
                                } else n = void 0;
                            return n;
                        }
                        T.extend({
                            hasData: function (e) {
                                return ce.hasData(e) || se.hasData(e);
                            },
                            data: function (e, t, n) {
                                return ce.access(e, t, n);
                            },
                            removeData: function (e, t) {
                                ce.remove(e, t);
                            },
                            _data: function (e, t, n) {
                                return se.access(e, t, n);
                            },
                            _removeData: function (e, t) {
                                se.remove(e, t);
                            },
                        }),
                            T.fn.extend({
                                data: function (e, t) {
                                    var n,
                                        r,
                                        o,
                                        i = this[0],
                                        a = i && i.attributes;
                                    if (void 0 === e) {
                                        if (
                                            this.length &&
                                            ((o = ce.get(i)),
                                            1 === i.nodeType &&
                                                !se.get(i, "hasDataAttrs"))
                                        ) {
                                            for (n = a.length; n--; )
                                                a[n] &&
                                                    0 ===
                                                        (r = a[n].name).indexOf(
                                                            "data-"
                                                        ) &&
                                                    ((r = oe(r.slice(5))),
                                                    de(i, r, o[r]));
                                            se.set(i, "hasDataAttrs", !0);
                                        }
                                        return o;
                                    }
                                    return "object" == typeof e
                                        ? this.each(function () {
                                              ce.set(this, e);
                                          })
                                        : ee(
                                              this,
                                              function (t) {
                                                  var n;
                                                  if (i && void 0 === t)
                                                      return void 0 !==
                                                          (n = ce.get(i, e)) ||
                                                          void 0 !==
                                                              (n = de(i, e))
                                                          ? n
                                                          : void 0;
                                                  this.each(function () {
                                                      ce.set(this, e, t);
                                                  });
                                              },
                                              null,
                                              t,
                                              arguments.length > 1,
                                              null,
                                              !0
                                          );
                                },
                                removeData: function (e) {
                                    return this.each(function () {
                                        ce.remove(this, e);
                                    });
                                },
                            }),
                            T.extend({
                                queue: function (e, t, n) {
                                    var r;
                                    if (e)
                                        return (
                                            (t = (t || "fx") + "queue"),
                                            (r = se.get(e, t)),
                                            n &&
                                                (!r || Array.isArray(n)
                                                    ? (r = se.access(
                                                          e,
                                                          t,
                                                          T.makeArray(n)
                                                      ))
                                                    : r.push(n)),
                                            r || []
                                        );
                                },
                                dequeue: function (e, t) {
                                    t = t || "fx";
                                    var n = T.queue(e, t),
                                        r = n.length,
                                        o = n.shift(),
                                        i = T._queueHooks(e, t);
                                    "inprogress" === o &&
                                        ((o = n.shift()), r--),
                                        o &&
                                            ("fx" === t &&
                                                n.unshift("inprogress"),
                                            delete i.stop,
                                            o.call(
                                                e,
                                                function () {
                                                    T.dequeue(e, t);
                                                },
                                                i
                                            )),
                                        !r && i && i.empty.fire();
                                },
                                _queueHooks: function (e, t) {
                                    var n = t + "queueHooks";
                                    return (
                                        se.get(e, n) ||
                                        se.access(e, n, {
                                            empty: T.Callbacks(
                                                "once memory"
                                            ).add(function () {
                                                se.remove(e, [t + "queue", n]);
                                            }),
                                        })
                                    );
                                },
                            }),
                            T.fn.extend({
                                queue: function (e, t) {
                                    var n = 2;
                                    return (
                                        "string" != typeof e &&
                                            ((t = e), (e = "fx"), n--),
                                        arguments.length < n
                                            ? T.queue(this[0], e)
                                            : void 0 === t
                                            ? this
                                            : this.each(function () {
                                                  var n = T.queue(this, e, t);
                                                  T._queueHooks(this, e),
                                                      "fx" === e &&
                                                          "inprogress" !==
                                                              n[0] &&
                                                          T.dequeue(this, e);
                                              })
                                    );
                                },
                                dequeue: function (e) {
                                    return this.each(function () {
                                        T.dequeue(this, e);
                                    });
                                },
                                clearQueue: function (e) {
                                    return this.queue(e || "fx", []);
                                },
                                promise: function (e, t) {
                                    var n,
                                        r = 1,
                                        o = T.Deferred(),
                                        i = this,
                                        a = this.length,
                                        s = function () {
                                            --r || o.resolveWith(i, [i]);
                                        };
                                    for (
                                        "string" != typeof e &&
                                            ((t = e), (e = void 0)),
                                            e = e || "fx";
                                        a--;

                                    )
                                        (n = se.get(i[a], e + "queueHooks")) &&
                                            n.empty &&
                                            (r++, n.empty.add(s));
                                    return s(), o.promise(t);
                                },
                            });
                        var pe = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
                            fe = new RegExp(
                                "^(?:([+-])=|)(" + pe + ")([a-z%]*)$",
                                "i"
                            ),
                            he = ["Top", "Right", "Bottom", "Left"],
                            me = b.documentElement,
                            ge = function (e) {
                                return T.contains(e.ownerDocument, e);
                            },
                            ve = { composed: !0 };
                        me.getRootNode &&
                            (ge = function (e) {
                                return (
                                    T.contains(e.ownerDocument, e) ||
                                    e.getRootNode(ve) === e.ownerDocument
                                );
                            });
                        var ye = function (e, t) {
                            return (
                                "none" === (e = t || e).style.display ||
                                ("" === e.style.display &&
                                    ge(e) &&
                                    "none" === T.css(e, "display"))
                            );
                        };
                        function be(e, t, n, r) {
                            var o,
                                i,
                                a = 20,
                                s = r
                                    ? function () {
                                          return r.cur();
                                      }
                                    : function () {
                                          return T.css(e, t, "");
                                      },
                                c = s(),
                                u = (n && n[3]) || (T.cssNumber[t] ? "" : "px"),
                                l =
                                    e.nodeType &&
                                    (T.cssNumber[t] || ("px" !== u && +c)) &&
                                    fe.exec(T.css(e, t));
                            if (l && l[3] !== u) {
                                for (c /= 2, u = u || l[3], l = +c || 1; a--; )
                                    T.style(e, t, l + u),
                                        (1 - i) * (1 - (i = s() / c || 0.5)) <=
                                            0 && (a = 0),
                                        (l /= i);
                                (l *= 2), T.style(e, t, l + u), (n = n || []);
                            }
                            return (
                                n &&
                                    ((l = +l || +c || 0),
                                    (o = n[1] ? l + (n[1] + 1) * n[2] : +n[2]),
                                    r &&
                                        ((r.unit = u),
                                        (r.start = l),
                                        (r.end = o))),
                                o
                            );
                        }
                        var xe = {};
                        function we(e) {
                            var t,
                                n = e.ownerDocument,
                                r = e.nodeName,
                                o = xe[r];
                            return (
                                o ||
                                ((t = n.body.appendChild(n.createElement(r))),
                                (o = T.css(t, "display")),
                                t.parentNode.removeChild(t),
                                "none" === o && (o = "block"),
                                (xe[r] = o),
                                o)
                            );
                        }
                        function je(e, t) {
                            for (
                                var n, r, o = [], i = 0, a = e.length;
                                i < a;
                                i++
                            )
                                (r = e[i]).style &&
                                    ((n = r.style.display),
                                    t
                                        ? ("none" === n &&
                                              ((o[i] =
                                                  se.get(r, "display") || null),
                                              o[i] || (r.style.display = "")),
                                          "" === r.style.display &&
                                              ye(r) &&
                                              (o[i] = we(r)))
                                        : "none" !== n &&
                                          ((o[i] = "none"),
                                          se.set(r, "display", n)));
                            for (i = 0; i < a; i++)
                                null != o[i] && (e[i].style.display = o[i]);
                            return e;
                        }
                        T.fn.extend({
                            show: function () {
                                return je(this, !0);
                            },
                            hide: function () {
                                return je(this);
                            },
                            toggle: function (e) {
                                return "boolean" == typeof e
                                    ? e
                                        ? this.show()
                                        : this.hide()
                                    : this.each(function () {
                                          ye(this)
                                              ? T(this).show()
                                              : T(this).hide();
                                      });
                            },
                        });
                        var ke,
                            Ce,
                            Te = /^(?:checkbox|radio)$/i,
                            Se = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
                            Ae = /^$|^module$|\/(?:java|ecma)script/i;
                        (ke = b
                            .createDocumentFragment()
                            .appendChild(b.createElement("div"))),
                            (Ce = b.createElement("input")).setAttribute(
                                "type",
                                "radio"
                            ),
                            Ce.setAttribute("checked", "checked"),
                            Ce.setAttribute("name", "t"),
                            ke.appendChild(Ce),
                            (g.checkClone = ke
                                .cloneNode(!0)
                                .cloneNode(!0).lastChild.checked),
                            (ke.innerHTML = "<textarea>x</textarea>"),
                            (g.noCloneChecked = !!ke.cloneNode(!0).lastChild
                                .defaultValue),
                            (ke.innerHTML = "<option></option>"),
                            (g.option = !!ke.lastChild);
                        var Ee = {
                            thead: [1, "<table>", "</table>"],
                            col: [
                                2,
                                "<table><colgroup>",
                                "</colgroup></table>",
                            ],
                            tr: [2, "<table><tbody>", "</tbody></table>"],
                            td: [
                                3,
                                "<table><tbody><tr>",
                                "</tr></tbody></table>",
                            ],
                            _default: [0, "", ""],
                        };
                        function De(e, t) {
                            var n;
                            return (
                                (n =
                                    void 0 !== e.getElementsByTagName
                                        ? e.getElementsByTagName(t || "*")
                                        : void 0 !== e.querySelectorAll
                                        ? e.querySelectorAll(t || "*")
                                        : []),
                                void 0 === t || (t && A(e, t))
                                    ? T.merge([e], n)
                                    : n
                            );
                        }
                        function Pe(e, t) {
                            for (var n = 0, r = e.length; n < r; n++)
                                se.set(
                                    e[n],
                                    "globalEval",
                                    !t || se.get(t[n], "globalEval")
                                );
                        }
                        (Ee.tbody =
                            Ee.tfoot =
                            Ee.colgroup =
                            Ee.caption =
                                Ee.thead),
                            (Ee.th = Ee.td),
                            g.option ||
                                (Ee.optgroup = Ee.option =
                                    [
                                        1,
                                        "<select multiple='multiple'>",
                                        "</select>",
                                    ]);
                        var qe = /<|&#?\w+;/;
                        function Ne(e, t, n, r, o) {
                            for (
                                var i,
                                    a,
                                    s,
                                    c,
                                    u,
                                    l,
                                    d = t.createDocumentFragment(),
                                    p = [],
                                    f = 0,
                                    h = e.length;
                                f < h;
                                f++
                            )
                                if ((i = e[f]) || 0 === i)
                                    if ("object" === j(i))
                                        T.merge(p, i.nodeType ? [i] : i);
                                    else if (qe.test(i)) {
                                        for (
                                            a =
                                                a ||
                                                d.appendChild(
                                                    t.createElement("div")
                                                ),
                                                s = (Se.exec(i) || [
                                                    "",
                                                    "",
                                                ])[1].toLowerCase(),
                                                c = Ee[s] || Ee._default,
                                                a.innerHTML =
                                                    c[1] +
                                                    T.htmlPrefilter(i) +
                                                    c[2],
                                                l = c[0];
                                            l--;

                                        )
                                            a = a.lastChild;
                                        T.merge(p, a.childNodes),
                                            ((a = d.firstChild).textContent =
                                                "");
                                    } else p.push(t.createTextNode(i));
                            for (d.textContent = "", f = 0; (i = p[f++]); )
                                if (r && T.inArray(i, r) > -1) o && o.push(i);
                                else if (
                                    ((u = ge(i)),
                                    (a = De(d.appendChild(i), "script")),
                                    u && Pe(a),
                                    n)
                                )
                                    for (l = 0; (i = a[l++]); )
                                        Ae.test(i.type || "") && n.push(i);
                            return d;
                        }
                        var Oe = /^([^.]*)(?:\.(.+)|)/;
                        function _e() {
                            return !0;
                        }
                        function $e() {
                            return !1;
                        }
                        function He(e, t, n, r, o, i) {
                            var a, s;
                            if ("object" == typeof t) {
                                for (s in ("string" != typeof n &&
                                    ((r = r || n), (n = void 0)),
                                t))
                                    He(e, s, n, r, t[s], i);
                                return e;
                            }
                            if (
                                (null == r && null == o
                                    ? ((o = n), (r = n = void 0))
                                    : null == o &&
                                      ("string" == typeof n
                                          ? ((o = r), (r = void 0))
                                          : ((o = r), (r = n), (n = void 0))),
                                !1 === o)
                            )
                                o = $e;
                            else if (!o) return e;
                            return (
                                1 === i &&
                                    ((a = o),
                                    (o = function (e) {
                                        return (
                                            T().off(e), a.apply(this, arguments)
                                        );
                                    }),
                                    (o.guid = a.guid || (a.guid = T.guid++))),
                                e.each(function () {
                                    T.event.add(this, t, o, r, n);
                                })
                            );
                        }
                        function Le(e, t, n) {
                            n
                                ? (se.set(e, t, !1),
                                  T.event.add(e, t, {
                                      namespace: !1,
                                      handler: function (e) {
                                          var n,
                                              r = se.get(this, t);
                                          if (1 & e.isTrigger && this[t]) {
                                              if (r)
                                                  (T.event.special[t] || {})
                                                      .delegateType &&
                                                      e.stopPropagation();
                                              else if (
                                                  ((r = s.call(arguments)),
                                                  se.set(this, t, r),
                                                  this[t](),
                                                  (n = se.get(this, t)),
                                                  se.set(this, t, !1),
                                                  r !== n)
                                              )
                                                  return (
                                                      e.stopImmediatePropagation(),
                                                      e.preventDefault(),
                                                      n
                                                  );
                                          } else
                                              r &&
                                                  (se.set(
                                                      this,
                                                      t,
                                                      T.event.trigger(
                                                          r[0],
                                                          r.slice(1),
                                                          this
                                                      )
                                                  ),
                                                  e.stopPropagation(),
                                                  (e.isImmediatePropagationStopped =
                                                      _e));
                                      },
                                  }))
                                : void 0 === se.get(e, t) &&
                                  T.event.add(e, t, _e);
                        }
                        (T.event = {
                            global: {},
                            add: function (e, t, n, r, o) {
                                var i,
                                    a,
                                    s,
                                    c,
                                    u,
                                    l,
                                    d,
                                    p,
                                    f,
                                    h,
                                    m,
                                    g = se.get(e);
                                if (ie(e))
                                    for (
                                        n.handler &&
                                            ((n = (i = n).handler),
                                            (o = i.selector)),
                                            o && T.find.matchesSelector(me, o),
                                            n.guid || (n.guid = T.guid++),
                                            (c = g.events) ||
                                                (c = g.events =
                                                    Object.create(null)),
                                            (a = g.handle) ||
                                                (a = g.handle =
                                                    function (t) {
                                                        return void 0 !== T &&
                                                            T.event
                                                                .triggered !==
                                                                t.type
                                                            ? T.event.dispatch.apply(
                                                                  e,
                                                                  arguments
                                                              )
                                                            : void 0;
                                                    }),
                                            u = (t = (t || "").match(X) || [""])
                                                .length;
                                        u--;

                                    )
                                        (f = m = (s = Oe.exec(t[u]) || [])[1]),
                                            (h = (s[2] || "")
                                                .split(".")
                                                .sort()),
                                            f &&
                                                ((d = T.event.special[f] || {}),
                                                (f =
                                                    (o
                                                        ? d.delegateType
                                                        : d.bindType) || f),
                                                (d = T.event.special[f] || {}),
                                                (l = T.extend(
                                                    {
                                                        type: f,
                                                        origType: m,
                                                        data: r,
                                                        handler: n,
                                                        guid: n.guid,
                                                        selector: o,
                                                        needsContext:
                                                            o &&
                                                            T.expr.match.needsContext.test(
                                                                o
                                                            ),
                                                        namespace: h.join("."),
                                                    },
                                                    i
                                                )),
                                                (p = c[f]) ||
                                                    (((p = c[f] =
                                                        []).delegateCount = 0),
                                                    (d.setup &&
                                                        !1 !==
                                                            d.setup.call(
                                                                e,
                                                                r,
                                                                h,
                                                                a
                                                            )) ||
                                                        (e.addEventListener &&
                                                            e.addEventListener(
                                                                f,
                                                                a
                                                            ))),
                                                d.add &&
                                                    (d.add.call(e, l),
                                                    l.handler.guid ||
                                                        (l.handler.guid =
                                                            n.guid)),
                                                o
                                                    ? p.splice(
                                                          p.delegateCount++,
                                                          0,
                                                          l
                                                      )
                                                    : p.push(l),
                                                (T.event.global[f] = !0));
                            },
                            remove: function (e, t, n, r, o) {
                                var i,
                                    a,
                                    s,
                                    c,
                                    u,
                                    l,
                                    d,
                                    p,
                                    f,
                                    h,
                                    m,
                                    g = se.hasData(e) && se.get(e);
                                if (g && (c = g.events)) {
                                    for (
                                        u = (t = (t || "").match(X) || [""])
                                            .length;
                                        u--;

                                    )
                                        if (
                                            ((f = m =
                                                (s = Oe.exec(t[u]) || [])[1]),
                                            (h = (s[2] || "")
                                                .split(".")
                                                .sort()),
                                            f)
                                        ) {
                                            for (
                                                d = T.event.special[f] || {},
                                                    p =
                                                        c[
                                                            (f =
                                                                (r
                                                                    ? d.delegateType
                                                                    : d.bindType) ||
                                                                f)
                                                        ] || [],
                                                    s =
                                                        s[2] &&
                                                        new RegExp(
                                                            "(^|\\.)" +
                                                                h.join(
                                                                    "\\.(?:.*\\.|)"
                                                                ) +
                                                                "(\\.|$)"
                                                        ),
                                                    a = i = p.length;
                                                i--;

                                            )
                                                (l = p[i]),
                                                    (!o && m !== l.origType) ||
                                                        (n &&
                                                            n.guid !==
                                                                l.guid) ||
                                                        (s &&
                                                            !s.test(
                                                                l.namespace
                                                            )) ||
                                                        (r &&
                                                            r !== l.selector &&
                                                            ("**" !== r ||
                                                                !l.selector)) ||
                                                        (p.splice(i, 1),
                                                        l.selector &&
                                                            p.delegateCount--,
                                                        d.remove &&
                                                            d.remove.call(
                                                                e,
                                                                l
                                                            ));
                                            a &&
                                                !p.length &&
                                                ((d.teardown &&
                                                    !1 !==
                                                        d.teardown.call(
                                                            e,
                                                            h,
                                                            g.handle
                                                        )) ||
                                                    T.removeEvent(
                                                        e,
                                                        f,
                                                        g.handle
                                                    ),
                                                delete c[f]);
                                        } else
                                            for (f in c)
                                                T.event.remove(
                                                    e,
                                                    f + t[u],
                                                    n,
                                                    r,
                                                    !0
                                                );
                                    T.isEmptyObject(c) &&
                                        se.remove(e, "handle events");
                                }
                            },
                            dispatch: function (e) {
                                var t,
                                    n,
                                    r,
                                    o,
                                    i,
                                    a,
                                    s = new Array(arguments.length),
                                    c = T.event.fix(e),
                                    u =
                                        (se.get(this, "events") ||
                                            Object.create(null))[c.type] || [],
                                    l = T.event.special[c.type] || {};
                                for (s[0] = c, t = 1; t < arguments.length; t++)
                                    s[t] = arguments[t];
                                if (
                                    ((c.delegateTarget = this),
                                    !l.preDispatch ||
                                        !1 !== l.preDispatch.call(this, c))
                                ) {
                                    for (
                                        a = T.event.handlers.call(this, c, u),
                                            t = 0;
                                        (o = a[t++]) &&
                                        !c.isPropagationStopped();

                                    )
                                        for (
                                            c.currentTarget = o.elem, n = 0;
                                            (i = o.handlers[n++]) &&
                                            !c.isImmediatePropagationStopped();

                                        )
                                            (c.rnamespace &&
                                                !1 !== i.namespace &&
                                                !c.rnamespace.test(
                                                    i.namespace
                                                )) ||
                                                ((c.handleObj = i),
                                                (c.data = i.data),
                                                void 0 !==
                                                    (r = (
                                                        (
                                                            T.event.special[
                                                                i.origType
                                                            ] || {}
                                                        ).handle || i.handler
                                                    ).apply(o.elem, s)) &&
                                                    !1 === (c.result = r) &&
                                                    (c.preventDefault(),
                                                    c.stopPropagation()));
                                    return (
                                        l.postDispatch &&
                                            l.postDispatch.call(this, c),
                                        c.result
                                    );
                                }
                            },
                            handlers: function (e, t) {
                                var n,
                                    r,
                                    o,
                                    i,
                                    a,
                                    s = [],
                                    c = t.delegateCount,
                                    u = e.target;
                                if (
                                    c &&
                                    u.nodeType &&
                                    !("click" === e.type && e.button >= 1)
                                )
                                    for (; u !== this; u = u.parentNode || this)
                                        if (
                                            1 === u.nodeType &&
                                            ("click" !== e.type ||
                                                !0 !== u.disabled)
                                        ) {
                                            for (
                                                i = [], a = {}, n = 0;
                                                n < c;
                                                n++
                                            )
                                                void 0 ===
                                                    a[
                                                        (o =
                                                            (r = t[n])
                                                                .selector + " ")
                                                    ] &&
                                                    (a[o] = r.needsContext
                                                        ? T(o, this).index(u) >
                                                          -1
                                                        : T.find(
                                                              o,
                                                              this,
                                                              null,
                                                              [u]
                                                          ).length),
                                                    a[o] && i.push(r);
                                            i.length &&
                                                s.push({
                                                    elem: u,
                                                    handlers: i,
                                                });
                                        }
                                return (
                                    (u = this),
                                    c < t.length &&
                                        s.push({
                                            elem: u,
                                            handlers: t.slice(c),
                                        }),
                                    s
                                );
                            },
                            addProp: function (e, t) {
                                Object.defineProperty(T.Event.prototype, e, {
                                    enumerable: !0,
                                    configurable: !0,
                                    get: v(t)
                                        ? function () {
                                              if (this.originalEvent)
                                                  return t(this.originalEvent);
                                          }
                                        : function () {
                                              if (this.originalEvent)
                                                  return this.originalEvent[e];
                                          },
                                    set: function (t) {
                                        Object.defineProperty(this, e, {
                                            enumerable: !0,
                                            configurable: !0,
                                            writable: !0,
                                            value: t,
                                        });
                                    },
                                });
                            },
                            fix: function (e) {
                                return e[T.expando] ? e : new T.Event(e);
                            },
                            special: {
                                load: { noBubble: !0 },
                                click: {
                                    setup: function (e) {
                                        var t = this || e;
                                        return (
                                            Te.test(t.type) &&
                                                t.click &&
                                                A(t, "input") &&
                                                Le(t, "click", !0),
                                            !1
                                        );
                                    },
                                    trigger: function (e) {
                                        var t = this || e;
                                        return (
                                            Te.test(t.type) &&
                                                t.click &&
                                                A(t, "input") &&
                                                Le(t, "click"),
                                            !0
                                        );
                                    },
                                    _default: function (e) {
                                        var t = e.target;
                                        return (
                                            (Te.test(t.type) &&
                                                t.click &&
                                                A(t, "input") &&
                                                se.get(t, "click")) ||
                                            A(t, "a")
                                        );
                                    },
                                },
                                beforeunload: {
                                    postDispatch: function (e) {
                                        void 0 !== e.result &&
                                            e.originalEvent &&
                                            (e.originalEvent.returnValue =
                                                e.result);
                                    },
                                },
                            },
                        }),
                            (T.removeEvent = function (e, t, n) {
                                e.removeEventListener &&
                                    e.removeEventListener(t, n);
                            }),
                            (T.Event = function (e, t) {
                                if (!(this instanceof T.Event))
                                    return new T.Event(e, t);
                                e && e.type
                                    ? ((this.originalEvent = e),
                                      (this.type = e.type),
                                      (this.isDefaultPrevented =
                                          e.defaultPrevented ||
                                          (void 0 === e.defaultPrevented &&
                                              !1 === e.returnValue)
                                              ? _e
                                              : $e),
                                      (this.target =
                                          e.target && 3 === e.target.nodeType
                                              ? e.target.parentNode
                                              : e.target),
                                      (this.currentTarget = e.currentTarget),
                                      (this.relatedTarget = e.relatedTarget))
                                    : (this.type = e),
                                    t && T.extend(this, t),
                                    (this.timeStamp =
                                        (e && e.timeStamp) || Date.now()),
                                    (this[T.expando] = !0);
                            }),
                            (T.Event.prototype = {
                                constructor: T.Event,
                                isDefaultPrevented: $e,
                                isPropagationStopped: $e,
                                isImmediatePropagationStopped: $e,
                                isSimulated: !1,
                                preventDefault: function () {
                                    var e = this.originalEvent;
                                    (this.isDefaultPrevented = _e),
                                        e &&
                                            !this.isSimulated &&
                                            e.preventDefault();
                                },
                                stopPropagation: function () {
                                    var e = this.originalEvent;
                                    (this.isPropagationStopped = _e),
                                        e &&
                                            !this.isSimulated &&
                                            e.stopPropagation();
                                },
                                stopImmediatePropagation: function () {
                                    var e = this.originalEvent;
                                    (this.isImmediatePropagationStopped = _e),
                                        e &&
                                            !this.isSimulated &&
                                            e.stopImmediatePropagation(),
                                        this.stopPropagation();
                                },
                            }),
                            T.each(
                                {
                                    altKey: !0,
                                    bubbles: !0,
                                    cancelable: !0,
                                    changedTouches: !0,
                                    ctrlKey: !0,
                                    detail: !0,
                                    eventPhase: !0,
                                    metaKey: !0,
                                    pageX: !0,
                                    pageY: !0,
                                    shiftKey: !0,
                                    view: !0,
                                    char: !0,
                                    code: !0,
                                    charCode: !0,
                                    key: !0,
                                    keyCode: !0,
                                    button: !0,
                                    buttons: !0,
                                    clientX: !0,
                                    clientY: !0,
                                    offsetX: !0,
                                    offsetY: !0,
                                    pointerId: !0,
                                    pointerType: !0,
                                    screenX: !0,
                                    screenY: !0,
                                    targetTouches: !0,
                                    toElement: !0,
                                    touches: !0,
                                    which: !0,
                                },
                                T.event.addProp
                            ),
                            T.each(
                                { focus: "focusin", blur: "focusout" },
                                function (e, t) {
                                    function n(e) {
                                        if (b.documentMode) {
                                            var n = se.get(this, "handle"),
                                                r = T.event.fix(e);
                                            (r.type =
                                                "focusin" === e.type
                                                    ? "focus"
                                                    : "blur"),
                                                (r.isSimulated = !0),
                                                n(e),
                                                r.target === r.currentTarget &&
                                                    n(r);
                                        } else
                                            T.event.simulate(
                                                t,
                                                e.target,
                                                T.event.fix(e)
                                            );
                                    }
                                    (T.event.special[e] = {
                                        setup: function () {
                                            var r;
                                            if (
                                                (Le(this, e, !0),
                                                !b.documentMode)
                                            )
                                                return !1;
                                            (r = se.get(this, t)) ||
                                                this.addEventListener(t, n),
                                                se.set(this, t, (r || 0) + 1);
                                        },
                                        trigger: function () {
                                            return Le(this, e), !0;
                                        },
                                        teardown: function () {
                                            var e;
                                            if (!b.documentMode) return !1;
                                            (e = se.get(this, t) - 1)
                                                ? se.set(this, t, e)
                                                : (this.removeEventListener(
                                                      t,
                                                      n
                                                  ),
                                                  se.remove(this, t));
                                        },
                                        _default: function (t) {
                                            return se.get(t.target, e);
                                        },
                                        delegateType: t,
                                    }),
                                        (T.event.special[t] = {
                                            setup: function () {
                                                var r =
                                                        this.ownerDocument ||
                                                        this.document ||
                                                        this,
                                                    o = b.documentMode
                                                        ? this
                                                        : r,
                                                    i = se.get(o, t);
                                                i ||
                                                    (b.documentMode
                                                        ? this.addEventListener(
                                                              t,
                                                              n
                                                          )
                                                        : r.addEventListener(
                                                              e,
                                                              n,
                                                              !0
                                                          )),
                                                    se.set(o, t, (i || 0) + 1);
                                            },
                                            teardown: function () {
                                                var r =
                                                        this.ownerDocument ||
                                                        this.document ||
                                                        this,
                                                    o = b.documentMode
                                                        ? this
                                                        : r,
                                                    i = se.get(o, t) - 1;
                                                i
                                                    ? se.set(o, t, i)
                                                    : (b.documentMode
                                                          ? this.removeEventListener(
                                                                t,
                                                                n
                                                            )
                                                          : r.removeEventListener(
                                                                e,
                                                                n,
                                                                !0
                                                            ),
                                                      se.remove(o, t));
                                            },
                                        });
                                }
                            ),
                            T.each(
                                {
                                    mouseenter: "mouseover",
                                    mouseleave: "mouseout",
                                    pointerenter: "pointerover",
                                    pointerleave: "pointerout",
                                },
                                function (e, t) {
                                    T.event.special[e] = {
                                        delegateType: t,
                                        bindType: t,
                                        handle: function (e) {
                                            var n,
                                                r = e.relatedTarget,
                                                o = e.handleObj;
                                            return (
                                                (r &&
                                                    (r === this ||
                                                        T.contains(this, r))) ||
                                                    ((e.type = o.origType),
                                                    (n = o.handler.apply(
                                                        this,
                                                        arguments
                                                    )),
                                                    (e.type = t)),
                                                n
                                            );
                                        },
                                    };
                                }
                            ),
                            T.fn.extend({
                                on: function (e, t, n, r) {
                                    return He(this, e, t, n, r);
                                },
                                one: function (e, t, n, r) {
                                    return He(this, e, t, n, r, 1);
                                },
                                off: function (e, t, n) {
                                    var r, o;
                                    if (e && e.preventDefault && e.handleObj)
                                        return (
                                            (r = e.handleObj),
                                            T(e.delegateTarget).off(
                                                r.namespace
                                                    ? r.origType +
                                                          "." +
                                                          r.namespace
                                                    : r.origType,
                                                r.selector,
                                                r.handler
                                            ),
                                            this
                                        );
                                    if ("object" == typeof e) {
                                        for (o in e) this.off(o, t, e[o]);
                                        return this;
                                    }
                                    return (
                                        (!1 !== t && "function" != typeof t) ||
                                            ((n = t), (t = void 0)),
                                        !1 === n && (n = $e),
                                        this.each(function () {
                                            T.event.remove(this, e, n, t);
                                        })
                                    );
                                },
                            });
                        var Re = /<script|<style|<link/i,
                            Me = /checked\s*(?:[^=]|=\s*.checked.)/i,
                            Ie = /^\s*<!\[CDATA\[|\]\]>\s*$/g;
                        function We(e, t) {
                            return (
                                (A(e, "table") &&
                                    A(
                                        11 !== t.nodeType ? t : t.firstChild,
                                        "tr"
                                    ) &&
                                    T(e).children("tbody")[0]) ||
                                e
                            );
                        }
                        function Fe(e) {
                            return (
                                (e.type =
                                    (null !== e.getAttribute("type")) +
                                    "/" +
                                    e.type),
                                e
                            );
                        }
                        function Qe(e) {
                            return (
                                "true/" === (e.type || "").slice(0, 5)
                                    ? (e.type = e.type.slice(5))
                                    : e.removeAttribute("type"),
                                e
                            );
                        }
                        function Be(e, t) {
                            var n, r, o, i, a, s;
                            if (1 === t.nodeType) {
                                if (se.hasData(e) && (s = se.get(e).events))
                                    for (o in (se.remove(t, "handle events"),
                                    s))
                                        for (n = 0, r = s[o].length; n < r; n++)
                                            T.event.add(t, o, s[o][n]);
                                ce.hasData(e) &&
                                    ((i = ce.access(e)),
                                    (a = T.extend({}, i)),
                                    ce.set(t, a));
                            }
                        }
                        function ze(e, t, n, r) {
                            t = c(t);
                            var o,
                                i,
                                a,
                                s,
                                u,
                                l,
                                d = 0,
                                p = e.length,
                                f = p - 1,
                                h = t[0],
                                m = v(h);
                            if (
                                m ||
                                (p > 1 &&
                                    "string" == typeof h &&
                                    !g.checkClone &&
                                    Me.test(h))
                            )
                                return e.each(function (o) {
                                    var i = e.eq(o);
                                    m && (t[0] = h.call(this, o, i.html())),
                                        ze(i, t, n, r);
                                });
                            if (
                                p &&
                                ((i = (o = Ne(t, e[0].ownerDocument, !1, e, r))
                                    .firstChild),
                                1 === o.childNodes.length && (o = i),
                                i || r)
                            ) {
                                for (
                                    s = (a = T.map(De(o, "script"), Fe)).length;
                                    d < p;
                                    d++
                                )
                                    (u = o),
                                        d !== f &&
                                            ((u = T.clone(u, !0, !0)),
                                            s && T.merge(a, De(u, "script"))),
                                        n.call(e[d], u, d);
                                if (s)
                                    for (
                                        l = a[a.length - 1].ownerDocument,
                                            T.map(a, Qe),
                                            d = 0;
                                        d < s;
                                        d++
                                    )
                                        (u = a[d]),
                                            Ae.test(u.type || "") &&
                                                !se.access(u, "globalEval") &&
                                                T.contains(l, u) &&
                                                (u.src &&
                                                "module" !==
                                                    (u.type || "").toLowerCase()
                                                    ? T._evalUrl &&
                                                      !u.noModule &&
                                                      T._evalUrl(
                                                          u.src,
                                                          {
                                                              nonce:
                                                                  u.nonce ||
                                                                  u.getAttribute(
                                                                      "nonce"
                                                                  ),
                                                          },
                                                          l
                                                      )
                                                    : w(
                                                          u.textContent.replace(
                                                              Ie,
                                                              ""
                                                          ),
                                                          u,
                                                          l
                                                      ));
                            }
                            return e;
                        }
                        function Ue(e, t, n) {
                            for (
                                var r, o = t ? T.filter(t, e) : e, i = 0;
                                null != (r = o[i]);
                                i++
                            )
                                n || 1 !== r.nodeType || T.cleanData(De(r)),
                                    r.parentNode &&
                                        (n && ge(r) && Pe(De(r, "script")),
                                        r.parentNode.removeChild(r));
                            return e;
                        }
                        T.extend({
                            htmlPrefilter: function (e) {
                                return e;
                            },
                            clone: function (e, t, n) {
                                var r,
                                    o,
                                    i,
                                    a,
                                    s,
                                    c,
                                    u,
                                    l = e.cloneNode(!0),
                                    d = ge(e);
                                if (
                                    !(
                                        g.noCloneChecked ||
                                        (1 !== e.nodeType &&
                                            11 !== e.nodeType) ||
                                        T.isXMLDoc(e)
                                    )
                                )
                                    for (
                                        a = De(l),
                                            r = 0,
                                            o = (i = De(e)).length;
                                        r < o;
                                        r++
                                    )
                                        (s = i[r]),
                                            (c = a[r]),
                                            (u = void 0),
                                            "input" ===
                                                (u =
                                                    c.nodeName.toLowerCase()) &&
                                            Te.test(s.type)
                                                ? (c.checked = s.checked)
                                                : ("input" !== u &&
                                                      "textarea" !== u) ||
                                                  (c.defaultValue =
                                                      s.defaultValue);
                                if (t)
                                    if (n)
                                        for (
                                            i = i || De(e),
                                                a = a || De(l),
                                                r = 0,
                                                o = i.length;
                                            r < o;
                                            r++
                                        )
                                            Be(i[r], a[r]);
                                    else Be(e, l);
                                return (
                                    (a = De(l, "script")).length > 0 &&
                                        Pe(a, !d && De(e, "script")),
                                    l
                                );
                            },
                            cleanData: function (e) {
                                for (
                                    var t, n, r, o = T.event.special, i = 0;
                                    void 0 !== (n = e[i]);
                                    i++
                                )
                                    if (ie(n)) {
                                        if ((t = n[se.expando])) {
                                            if (t.events)
                                                for (r in t.events)
                                                    o[r]
                                                        ? T.event.remove(n, r)
                                                        : T.removeEvent(
                                                              n,
                                                              r,
                                                              t.handle
                                                          );
                                            n[se.expando] = void 0;
                                        }
                                        n[ce.expando] &&
                                            (n[ce.expando] = void 0);
                                    }
                            },
                        }),
                            T.fn.extend({
                                detach: function (e) {
                                    return Ue(this, e, !0);
                                },
                                remove: function (e) {
                                    return Ue(this, e);
                                },
                                text: function (e) {
                                    return ee(
                                        this,
                                        function (e) {
                                            return void 0 === e
                                                ? T.text(this)
                                                : this.empty().each(
                                                      function () {
                                                          (1 !==
                                                              this.nodeType &&
                                                              11 !==
                                                                  this
                                                                      .nodeType &&
                                                              9 !==
                                                                  this
                                                                      .nodeType) ||
                                                              (this.textContent =
                                                                  e);
                                                      }
                                                  );
                                        },
                                        null,
                                        e,
                                        arguments.length
                                    );
                                },
                                append: function () {
                                    return ze(this, arguments, function (e) {
                                        (1 !== this.nodeType &&
                                            11 !== this.nodeType &&
                                            9 !== this.nodeType) ||
                                            We(this, e).appendChild(e);
                                    });
                                },
                                prepend: function () {
                                    return ze(this, arguments, function (e) {
                                        if (
                                            1 === this.nodeType ||
                                            11 === this.nodeType ||
                                            9 === this.nodeType
                                        ) {
                                            var t = We(this, e);
                                            t.insertBefore(e, t.firstChild);
                                        }
                                    });
                                },
                                before: function () {
                                    return ze(this, arguments, function (e) {
                                        this.parentNode &&
                                            this.parentNode.insertBefore(
                                                e,
                                                this
                                            );
                                    });
                                },
                                after: function () {
                                    return ze(this, arguments, function (e) {
                                        this.parentNode &&
                                            this.parentNode.insertBefore(
                                                e,
                                                this.nextSibling
                                            );
                                    });
                                },
                                empty: function () {
                                    for (
                                        var e, t = 0;
                                        null != (e = this[t]);
                                        t++
                                    )
                                        1 === e.nodeType &&
                                            (T.cleanData(De(e, !1)),
                                            (e.textContent = ""));
                                    return this;
                                },
                                clone: function (e, t) {
                                    return (
                                        (e = null != e && e),
                                        (t = null == t ? e : t),
                                        this.map(function () {
                                            return T.clone(this, e, t);
                                        })
                                    );
                                },
                                html: function (e) {
                                    return ee(
                                        this,
                                        function (e) {
                                            var t = this[0] || {},
                                                n = 0,
                                                r = this.length;
                                            if (
                                                void 0 === e &&
                                                1 === t.nodeType
                                            )
                                                return t.innerHTML;
                                            if (
                                                "string" == typeof e &&
                                                !Re.test(e) &&
                                                !Ee[
                                                    (Se.exec(e) || [
                                                        "",
                                                        "",
                                                    ])[1].toLowerCase()
                                                ]
                                            ) {
                                                e = T.htmlPrefilter(e);
                                                try {
                                                    for (; n < r; n++)
                                                        1 ===
                                                            (t = this[n] || {})
                                                                .nodeType &&
                                                            (T.cleanData(
                                                                De(t, !1)
                                                            ),
                                                            (t.innerHTML = e));
                                                    t = 0;
                                                } catch (e) {}
                                            }
                                            t && this.empty().append(e);
                                        },
                                        null,
                                        e,
                                        arguments.length
                                    );
                                },
                                replaceWith: function () {
                                    var e = [];
                                    return ze(
                                        this,
                                        arguments,
                                        function (t) {
                                            var n = this.parentNode;
                                            T.inArray(this, e) < 0 &&
                                                (T.cleanData(De(this)),
                                                n && n.replaceChild(t, this));
                                        },
                                        e
                                    );
                                },
                            }),
                            T.each(
                                {
                                    appendTo: "append",
                                    prependTo: "prepend",
                                    insertBefore: "before",
                                    insertAfter: "after",
                                    replaceAll: "replaceWith",
                                },
                                function (e, t) {
                                    T.fn[e] = function (e) {
                                        for (
                                            var n,
                                                r = [],
                                                o = T(e),
                                                i = o.length - 1,
                                                a = 0;
                                            a <= i;
                                            a++
                                        )
                                            (n =
                                                a === i
                                                    ? this
                                                    : this.clone(!0)),
                                                T(o[a])[t](n),
                                                u.apply(r, n.get());
                                        return this.pushStack(r);
                                    };
                                }
                            );
                        var Xe = new RegExp("^(" + pe + ")(?!px)[a-z%]+$", "i"),
                            Ve = /^--/,
                            Je = function (e) {
                                var t = e.ownerDocument.defaultView;
                                return (
                                    (t && t.opener) || (t = r),
                                    t.getComputedStyle(e)
                                );
                            },
                            Ge = function (e, t, n) {
                                var r,
                                    o,
                                    i = {};
                                for (o in t)
                                    (i[o] = e.style[o]), (e.style[o] = t[o]);
                                for (o in ((r = n.call(e)), t))
                                    e.style[o] = i[o];
                                return r;
                            },
                            Ye = new RegExp(he.join("|"), "i");
                        function Ke(e, t, n) {
                            var r,
                                o,
                                i,
                                a,
                                s = Ve.test(t),
                                c = e.style;
                            return (
                                (n = n || Je(e)) &&
                                    ((a = n.getPropertyValue(t) || n[t]),
                                    s &&
                                        a &&
                                        (a = a.replace(N, "$1") || void 0),
                                    "" !== a || ge(e) || (a = T.style(e, t)),
                                    !g.pixelBoxStyles() &&
                                        Xe.test(a) &&
                                        Ye.test(t) &&
                                        ((r = c.width),
                                        (o = c.minWidth),
                                        (i = c.maxWidth),
                                        (c.minWidth = c.maxWidth = c.width = a),
                                        (a = n.width),
                                        (c.width = r),
                                        (c.minWidth = o),
                                        (c.maxWidth = i))),
                                void 0 !== a ? a + "" : a
                            );
                        }
                        function Ze(e, t) {
                            return {
                                get: function () {
                                    if (!e())
                                        return (this.get = t).apply(
                                            this,
                                            arguments
                                        );
                                    delete this.get;
                                },
                            };
                        }
                        !(function () {
                            function e() {
                                if (l) {
                                    (u.style.cssText =
                                        "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0"),
                                        (l.style.cssText =
                                            "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%"),
                                        me.appendChild(u).appendChild(l);
                                    var e = r.getComputedStyle(l);
                                    (n = "1%" !== e.top),
                                        (c = 12 === t(e.marginLeft)),
                                        (l.style.right = "60%"),
                                        (a = 36 === t(e.right)),
                                        (o = 36 === t(e.width)),
                                        (l.style.position = "absolute"),
                                        (i = 12 === t(l.offsetWidth / 3)),
                                        me.removeChild(u),
                                        (l = null);
                                }
                            }
                            function t(e) {
                                return Math.round(parseFloat(e));
                            }
                            var n,
                                o,
                                i,
                                a,
                                s,
                                c,
                                u = b.createElement("div"),
                                l = b.createElement("div");
                            l.style &&
                                ((l.style.backgroundClip = "content-box"),
                                (l.cloneNode(!0).style.backgroundClip = ""),
                                (g.clearCloneStyle =
                                    "content-box" === l.style.backgroundClip),
                                T.extend(g, {
                                    boxSizingReliable: function () {
                                        return e(), o;
                                    },
                                    pixelBoxStyles: function () {
                                        return e(), a;
                                    },
                                    pixelPosition: function () {
                                        return e(), n;
                                    },
                                    reliableMarginLeft: function () {
                                        return e(), c;
                                    },
                                    scrollboxSize: function () {
                                        return e(), i;
                                    },
                                    reliableTrDimensions: function () {
                                        var e, t, n, o;
                                        return (
                                            null == s &&
                                                ((e = b.createElement("table")),
                                                (t = b.createElement("tr")),
                                                (n = b.createElement("div")),
                                                (e.style.cssText =
                                                    "position:absolute;left:-11111px;border-collapse:separate"),
                                                (t.style.cssText =
                                                    "box-sizing:content-box;border:1px solid"),
                                                (t.style.height = "1px"),
                                                (n.style.height = "9px"),
                                                (n.style.display = "block"),
                                                me
                                                    .appendChild(e)
                                                    .appendChild(t)
                                                    .appendChild(n),
                                                (o = r.getComputedStyle(t)),
                                                (s =
                                                    parseInt(o.height, 10) +
                                                        parseInt(
                                                            o.borderTopWidth,
                                                            10
                                                        ) +
                                                        parseInt(
                                                            o.borderBottomWidth,
                                                            10
                                                        ) ===
                                                    t.offsetHeight),
                                                me.removeChild(e)),
                                            s
                                        );
                                    },
                                }));
                        })();
                        var et = ["Webkit", "Moz", "ms"],
                            tt = b.createElement("div").style,
                            nt = {};
                        function rt(e) {
                            var t = T.cssProps[e] || nt[e];
                            return (
                                t ||
                                (e in tt
                                    ? e
                                    : (nt[e] =
                                          (function (e) {
                                              for (
                                                  var t =
                                                          e[0].toUpperCase() +
                                                          e.slice(1),
                                                      n = et.length;
                                                  n--;

                                              )
                                                  if ((e = et[n] + t) in tt)
                                                      return e;
                                          })(e) || e))
                            );
                        }
                        var ot = /^(none|table(?!-c[ea]).+)/,
                            it = {
                                position: "absolute",
                                visibility: "hidden",
                                display: "block",
                            },
                            at = { letterSpacing: "0", fontWeight: "400" };
                        function st(e, t, n) {
                            var r = fe.exec(t);
                            return r
                                ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px")
                                : t;
                        }
                        function ct(e, t, n, r, o, i) {
                            var a = "width" === t ? 1 : 0,
                                s = 0,
                                c = 0,
                                u = 0;
                            if (n === (r ? "border" : "content")) return 0;
                            for (; a < 4; a += 2)
                                "margin" === n &&
                                    (u += T.css(e, n + he[a], !0, o)),
                                    r
                                        ? ("content" === n &&
                                              (c -= T.css(
                                                  e,
                                                  "padding" + he[a],
                                                  !0,
                                                  o
                                              )),
                                          "margin" !== n &&
                                              (c -= T.css(
                                                  e,
                                                  "border" + he[a] + "Width",
                                                  !0,
                                                  o
                                              )))
                                        : ((c += T.css(
                                              e,
                                              "padding" + he[a],
                                              !0,
                                              o
                                          )),
                                          "padding" !== n
                                              ? (c += T.css(
                                                    e,
                                                    "border" + he[a] + "Width",
                                                    !0,
                                                    o
                                                ))
                                              : (s += T.css(
                                                    e,
                                                    "border" + he[a] + "Width",
                                                    !0,
                                                    o
                                                )));
                            return (
                                !r &&
                                    i >= 0 &&
                                    (c +=
                                        Math.max(
                                            0,
                                            Math.ceil(
                                                e[
                                                    "offset" +
                                                        t[0].toUpperCase() +
                                                        t.slice(1)
                                                ] -
                                                    i -
                                                    c -
                                                    s -
                                                    0.5
                                            )
                                        ) || 0),
                                c + u
                            );
                        }
                        function ut(e, t, n) {
                            var r = Je(e),
                                o =
                                    (!g.boxSizingReliable() || n) &&
                                    "border-box" ===
                                        T.css(e, "boxSizing", !1, r),
                                i = o,
                                a = Ke(e, t, r),
                                s = "offset" + t[0].toUpperCase() + t.slice(1);
                            if (Xe.test(a)) {
                                if (!n) return a;
                                a = "auto";
                            }
                            return (
                                ((!g.boxSizingReliable() && o) ||
                                    (!g.reliableTrDimensions() && A(e, "tr")) ||
                                    "auto" === a ||
                                    (!parseFloat(a) &&
                                        "inline" ===
                                            T.css(e, "display", !1, r))) &&
                                    e.getClientRects().length &&
                                    ((o =
                                        "border-box" ===
                                        T.css(e, "boxSizing", !1, r)),
                                    (i = s in e) && (a = e[s])),
                                (a = parseFloat(a) || 0) +
                                    ct(
                                        e,
                                        t,
                                        n || (o ? "border" : "content"),
                                        i,
                                        r,
                                        a
                                    ) +
                                    "px"
                            );
                        }
                        function lt(e, t, n, r, o) {
                            return new lt.prototype.init(e, t, n, r, o);
                        }
                        T.extend({
                            cssHooks: {
                                opacity: {
                                    get: function (e, t) {
                                        if (t) {
                                            var n = Ke(e, "opacity");
                                            return "" === n ? "1" : n;
                                        }
                                    },
                                },
                            },
                            cssNumber: {
                                animationIterationCount: !0,
                                aspectRatio: !0,
                                borderImageSlice: !0,
                                columnCount: !0,
                                flexGrow: !0,
                                flexShrink: !0,
                                fontWeight: !0,
                                gridArea: !0,
                                gridColumn: !0,
                                gridColumnEnd: !0,
                                gridColumnStart: !0,
                                gridRow: !0,
                                gridRowEnd: !0,
                                gridRowStart: !0,
                                lineHeight: !0,
                                opacity: !0,
                                order: !0,
                                orphans: !0,
                                scale: !0,
                                widows: !0,
                                zIndex: !0,
                                zoom: !0,
                                fillOpacity: !0,
                                floodOpacity: !0,
                                stopOpacity: !0,
                                strokeMiterlimit: !0,
                                strokeOpacity: !0,
                            },
                            cssProps: {},
                            style: function (e, t, n, r) {
                                if (
                                    e &&
                                    3 !== e.nodeType &&
                                    8 !== e.nodeType &&
                                    e.style
                                ) {
                                    var o,
                                        i,
                                        a,
                                        s = oe(t),
                                        c = Ve.test(t),
                                        u = e.style;
                                    if (
                                        (c || (t = rt(s)),
                                        (a = T.cssHooks[t] || T.cssHooks[s]),
                                        void 0 === n)
                                    )
                                        return a &&
                                            "get" in a &&
                                            void 0 !== (o = a.get(e, !1, r))
                                            ? o
                                            : u[t];
                                    "string" === (i = typeof n) &&
                                        (o = fe.exec(n)) &&
                                        o[1] &&
                                        ((n = be(e, t, o)), (i = "number")),
                                        null != n &&
                                            n == n &&
                                            ("number" !== i ||
                                                c ||
                                                (n +=
                                                    (o && o[3]) ||
                                                    (T.cssNumber[s]
                                                        ? ""
                                                        : "px")),
                                            g.clearCloneStyle ||
                                                "" !== n ||
                                                0 !== t.indexOf("background") ||
                                                (u[t] = "inherit"),
                                            (a &&
                                                "set" in a &&
                                                void 0 ===
                                                    (n = a.set(e, n, r))) ||
                                                (c
                                                    ? u.setProperty(t, n)
                                                    : (u[t] = n)));
                                }
                            },
                            css: function (e, t, n, r) {
                                var o,
                                    i,
                                    a,
                                    s = oe(t);
                                return (
                                    Ve.test(t) || (t = rt(s)),
                                    (a = T.cssHooks[t] || T.cssHooks[s]) &&
                                        "get" in a &&
                                        (o = a.get(e, !0, n)),
                                    void 0 === o && (o = Ke(e, t, r)),
                                    "normal" === o && t in at && (o = at[t]),
                                    "" === n || n
                                        ? ((i = parseFloat(o)),
                                          !0 === n || isFinite(i) ? i || 0 : o)
                                        : o
                                );
                            },
                        }),
                            T.each(["height", "width"], function (e, t) {
                                T.cssHooks[t] = {
                                    get: function (e, n, r) {
                                        if (n)
                                            return !ot.test(
                                                T.css(e, "display")
                                            ) ||
                                                (e.getClientRects().length &&
                                                    e.getBoundingClientRect()
                                                        .width)
                                                ? ut(e, t, r)
                                                : Ge(e, it, function () {
                                                      return ut(e, t, r);
                                                  });
                                    },
                                    set: function (e, n, r) {
                                        var o,
                                            i = Je(e),
                                            a =
                                                !g.scrollboxSize() &&
                                                "absolute" === i.position,
                                            s =
                                                (a || r) &&
                                                "border-box" ===
                                                    T.css(
                                                        e,
                                                        "boxSizing",
                                                        !1,
                                                        i
                                                    ),
                                            c = r ? ct(e, t, r, s, i) : 0;
                                        return (
                                            s &&
                                                a &&
                                                (c -= Math.ceil(
                                                    e[
                                                        "offset" +
                                                            t[0].toUpperCase() +
                                                            t.slice(1)
                                                    ] -
                                                        parseFloat(i[t]) -
                                                        ct(
                                                            e,
                                                            t,
                                                            "border",
                                                            !1,
                                                            i
                                                        ) -
                                                        0.5
                                                )),
                                            c &&
                                                (o = fe.exec(n)) &&
                                                "px" !== (o[3] || "px") &&
                                                ((e.style[t] = n),
                                                (n = T.css(e, t))),
                                            st(0, n, c)
                                        );
                                    },
                                };
                            }),
                            (T.cssHooks.marginLeft = Ze(
                                g.reliableMarginLeft,
                                function (e, t) {
                                    if (t)
                                        return (
                                            (parseFloat(Ke(e, "marginLeft")) ||
                                                e.getBoundingClientRect().left -
                                                    Ge(
                                                        e,
                                                        { marginLeft: 0 },
                                                        function () {
                                                            return e.getBoundingClientRect()
                                                                .left;
                                                        }
                                                    )) + "px"
                                        );
                                }
                            )),
                            T.each(
                                { margin: "", padding: "", border: "Width" },
                                function (e, t) {
                                    (T.cssHooks[e + t] = {
                                        expand: function (n) {
                                            for (
                                                var r = 0,
                                                    o = {},
                                                    i =
                                                        "string" == typeof n
                                                            ? n.split(" ")
                                                            : [n];
                                                r < 4;
                                                r++
                                            )
                                                o[e + he[r] + t] =
                                                    i[r] || i[r - 2] || i[0];
                                            return o;
                                        },
                                    }),
                                        "margin" !== e &&
                                            (T.cssHooks[e + t].set = st);
                                }
                            ),
                            T.fn.extend({
                                css: function (e, t) {
                                    return ee(
                                        this,
                                        function (e, t, n) {
                                            var r,
                                                o,
                                                i = {},
                                                a = 0;
                                            if (Array.isArray(t)) {
                                                for (
                                                    r = Je(e), o = t.length;
                                                    a < o;
                                                    a++
                                                )
                                                    i[t[a]] = T.css(
                                                        e,
                                                        t[a],
                                                        !1,
                                                        r
                                                    );
                                                return i;
                                            }
                                            return void 0 !== n
                                                ? T.style(e, t, n)
                                                : T.css(e, t);
                                        },
                                        e,
                                        t,
                                        arguments.length > 1
                                    );
                                },
                            }),
                            (T.Tween = lt),
                            (lt.prototype = {
                                constructor: lt,
                                init: function (e, t, n, r, o, i) {
                                    (this.elem = e),
                                        (this.prop = n),
                                        (this.easing = o || T.easing._default),
                                        (this.options = t),
                                        (this.start = this.now = this.cur()),
                                        (this.end = r),
                                        (this.unit =
                                            i || (T.cssNumber[n] ? "" : "px"));
                                },
                                cur: function () {
                                    var e = lt.propHooks[this.prop];
                                    return e && e.get
                                        ? e.get(this)
                                        : lt.propHooks._default.get(this);
                                },
                                run: function (e) {
                                    var t,
                                        n = lt.propHooks[this.prop];
                                    return (
                                        this.options.duration
                                            ? (this.pos = t =
                                                  T.easing[this.easing](
                                                      e,
                                                      this.options.duration * e,
                                                      0,
                                                      1,
                                                      this.options.duration
                                                  ))
                                            : (this.pos = t = e),
                                        (this.now =
                                            (this.end - this.start) * t +
                                            this.start),
                                        this.options.step &&
                                            this.options.step.call(
                                                this.elem,
                                                this.now,
                                                this
                                            ),
                                        n && n.set
                                            ? n.set(this)
                                            : lt.propHooks._default.set(this),
                                        this
                                    );
                                },
                            }),
                            (lt.prototype.init.prototype = lt.prototype),
                            (lt.propHooks = {
                                _default: {
                                    get: function (e) {
                                        var t;
                                        return 1 !== e.elem.nodeType ||
                                            (null != e.elem[e.prop] &&
                                                null == e.elem.style[e.prop])
                                            ? e.elem[e.prop]
                                            : (t = T.css(e.elem, e.prop, "")) &&
                                              "auto" !== t
                                            ? t
                                            : 0;
                                    },
                                    set: function (e) {
                                        T.fx.step[e.prop]
                                            ? T.fx.step[e.prop](e)
                                            : 1 !== e.elem.nodeType ||
                                              (!T.cssHooks[e.prop] &&
                                                  null ==
                                                      e.elem.style[rt(e.prop)])
                                            ? (e.elem[e.prop] = e.now)
                                            : T.style(
                                                  e.elem,
                                                  e.prop,
                                                  e.now + e.unit
                                              );
                                    },
                                },
                            }),
                            (lt.propHooks.scrollTop = lt.propHooks.scrollLeft =
                                {
                                    set: function (e) {
                                        e.elem.nodeType &&
                                            e.elem.parentNode &&
                                            (e.elem[e.prop] = e.now);
                                    },
                                }),
                            (T.easing = {
                                linear: function (e) {
                                    return e;
                                },
                                swing: function (e) {
                                    return 0.5 - Math.cos(e * Math.PI) / 2;
                                },
                                _default: "swing",
                            }),
                            (T.fx = lt.prototype.init),
                            (T.fx.step = {});
                        var dt,
                            pt,
                            ft = /^(?:toggle|show|hide)$/,
                            ht = /queueHooks$/;
                        function mt() {
                            pt &&
                                (!1 === b.hidden && r.requestAnimationFrame
                                    ? r.requestAnimationFrame(mt)
                                    : r.setTimeout(mt, T.fx.interval),
                                T.fx.tick());
                        }
                        function gt() {
                            return (
                                r.setTimeout(function () {
                                    dt = void 0;
                                }),
                                (dt = Date.now())
                            );
                        }
                        function vt(e, t) {
                            var n,
                                r = 0,
                                o = { height: e };
                            for (t = t ? 1 : 0; r < 4; r += 2 - t)
                                o["margin" + (n = he[r])] = o["padding" + n] =
                                    e;
                            return t && (o.opacity = o.width = e), o;
                        }
                        function yt(e, t, n) {
                            for (
                                var r,
                                    o = (bt.tweeners[t] || []).concat(
                                        bt.tweeners["*"]
                                    ),
                                    i = 0,
                                    a = o.length;
                                i < a;
                                i++
                            )
                                if ((r = o[i].call(n, t, e))) return r;
                        }
                        function bt(e, t, n) {
                            var r,
                                o,
                                i = 0,
                                a = bt.prefilters.length,
                                s = T.Deferred().always(function () {
                                    delete c.elem;
                                }),
                                c = function () {
                                    if (o) return !1;
                                    for (
                                        var t = dt || gt(),
                                            n = Math.max(
                                                0,
                                                u.startTime + u.duration - t
                                            ),
                                            r = 1 - (n / u.duration || 0),
                                            i = 0,
                                            a = u.tweens.length;
                                        i < a;
                                        i++
                                    )
                                        u.tweens[i].run(r);
                                    return (
                                        s.notifyWith(e, [u, r, n]),
                                        r < 1 && a
                                            ? n
                                            : (a || s.notifyWith(e, [u, 1, 0]),
                                              s.resolveWith(e, [u]),
                                              !1)
                                    );
                                },
                                u = s.promise({
                                    elem: e,
                                    props: T.extend({}, t),
                                    opts: T.extend(
                                        !0,
                                        {
                                            specialEasing: {},
                                            easing: T.easing._default,
                                        },
                                        n
                                    ),
                                    originalProperties: t,
                                    originalOptions: n,
                                    startTime: dt || gt(),
                                    duration: n.duration,
                                    tweens: [],
                                    createTween: function (t, n) {
                                        var r = T.Tween(
                                            e,
                                            u.opts,
                                            t,
                                            n,
                                            u.opts.specialEasing[t] ||
                                                u.opts.easing
                                        );
                                        return u.tweens.push(r), r;
                                    },
                                    stop: function (t) {
                                        var n = 0,
                                            r = t ? u.tweens.length : 0;
                                        if (o) return this;
                                        for (o = !0; n < r; n++)
                                            u.tweens[n].run(1);
                                        return (
                                            t
                                                ? (s.notifyWith(e, [u, 1, 0]),
                                                  s.resolveWith(e, [u, t]))
                                                : s.rejectWith(e, [u, t]),
                                            this
                                        );
                                    },
                                }),
                                l = u.props;
                            for (
                                !(function (e, t) {
                                    var n, r, o, i, a;
                                    for (n in e)
                                        if (
                                            ((o = t[(r = oe(n))]),
                                            (i = e[n]),
                                            Array.isArray(i) &&
                                                ((o = i[1]), (i = e[n] = i[0])),
                                            n !== r &&
                                                ((e[r] = i), delete e[n]),
                                            (a = T.cssHooks[r]) &&
                                                ("expand" in a))
                                        )
                                            for (n in ((i = a.expand(i)),
                                            delete e[r],
                                            i))
                                                (n in e) ||
                                                    ((e[n] = i[n]), (t[n] = o));
                                        else t[r] = o;
                                })(l, u.opts.specialEasing);
                                i < a;
                                i++
                            )
                                if (
                                    (r = bt.prefilters[i].call(u, e, l, u.opts))
                                )
                                    return (
                                        v(r.stop) &&
                                            (T._queueHooks(
                                                u.elem,
                                                u.opts.queue
                                            ).stop = r.stop.bind(r)),
                                        r
                                    );
                            return (
                                T.map(l, yt, u),
                                v(u.opts.start) && u.opts.start.call(e, u),
                                u
                                    .progress(u.opts.progress)
                                    .done(u.opts.done, u.opts.complete)
                                    .fail(u.opts.fail)
                                    .always(u.opts.always),
                                T.fx.timer(
                                    T.extend(c, {
                                        elem: e,
                                        anim: u,
                                        queue: u.opts.queue,
                                    })
                                ),
                                u
                            );
                        }
                        (T.Animation = T.extend(bt, {
                            tweeners: {
                                "*": [
                                    function (e, t) {
                                        var n = this.createTween(e, t);
                                        return be(n.elem, e, fe.exec(t), n), n;
                                    },
                                ],
                            },
                            tweener: function (e, t) {
                                v(e)
                                    ? ((t = e), (e = ["*"]))
                                    : (e = e.match(X));
                                for (var n, r = 0, o = e.length; r < o; r++)
                                    (n = e[r]),
                                        (bt.tweeners[n] = bt.tweeners[n] || []),
                                        bt.tweeners[n].unshift(t);
                            },
                            prefilters: [
                                function (e, t, n) {
                                    var r,
                                        o,
                                        i,
                                        a,
                                        s,
                                        c,
                                        u,
                                        l,
                                        d = "width" in t || "height" in t,
                                        p = this,
                                        f = {},
                                        h = e.style,
                                        m = e.nodeType && ye(e),
                                        g = se.get(e, "fxshow");
                                    for (r in (n.queue ||
                                        (null ==
                                            (a = T._queueHooks(e, "fx"))
                                                .unqueued &&
                                            ((a.unqueued = 0),
                                            (s = a.empty.fire),
                                            (a.empty.fire = function () {
                                                a.unqueued || s();
                                            })),
                                        a.unqueued++,
                                        p.always(function () {
                                            p.always(function () {
                                                a.unqueued--,
                                                    T.queue(e, "fx").length ||
                                                        a.empty.fire();
                                            });
                                        })),
                                    t))
                                        if (((o = t[r]), ft.test(o))) {
                                            if (
                                                (delete t[r],
                                                (i = i || "toggle" === o),
                                                o === (m ? "hide" : "show"))
                                            ) {
                                                if (
                                                    "show" !== o ||
                                                    !g ||
                                                    void 0 === g[r]
                                                )
                                                    continue;
                                                m = !0;
                                            }
                                            f[r] = (g && g[r]) || T.style(e, r);
                                        }
                                    if (
                                        (c = !T.isEmptyObject(t)) ||
                                        !T.isEmptyObject(f)
                                    )
                                        for (r in (d &&
                                            1 === e.nodeType &&
                                            ((n.overflow = [
                                                h.overflow,
                                                h.overflowX,
                                                h.overflowY,
                                            ]),
                                            null == (u = g && g.display) &&
                                                (u = se.get(e, "display")),
                                            "none" ===
                                                (l = T.css(e, "display")) &&
                                                (u
                                                    ? (l = u)
                                                    : (je([e], !0),
                                                      (u =
                                                          e.style.display || u),
                                                      (l = T.css(e, "display")),
                                                      je([e]))),
                                            ("inline" === l ||
                                                ("inline-block" === l &&
                                                    null != u)) &&
                                                "none" === T.css(e, "float") &&
                                                (c ||
                                                    (p.done(function () {
                                                        h.display = u;
                                                    }),
                                                    null == u &&
                                                        ((l = h.display),
                                                        (u =
                                                            "none" === l
                                                                ? ""
                                                                : l))),
                                                (h.display = "inline-block"))),
                                        n.overflow &&
                                            ((h.overflow = "hidden"),
                                            p.always(function () {
                                                (h.overflow = n.overflow[0]),
                                                    (h.overflowX =
                                                        n.overflow[1]),
                                                    (h.overflowY =
                                                        n.overflow[2]);
                                            })),
                                        (c = !1),
                                        f))
                                            c ||
                                                (g
                                                    ? "hidden" in g &&
                                                      (m = g.hidden)
                                                    : (g = se.access(
                                                          e,
                                                          "fxshow",
                                                          { display: u }
                                                      )),
                                                i && (g.hidden = !m),
                                                m && je([e], !0),
                                                p.done(function () {
                                                    for (r in (m || je([e]),
                                                    se.remove(e, "fxshow"),
                                                    f))
                                                        T.style(e, r, f[r]);
                                                })),
                                                (c = yt(m ? g[r] : 0, r, p)),
                                                r in g ||
                                                    ((g[r] = c.start),
                                                    m &&
                                                        ((c.end = c.start),
                                                        (c.start = 0)));
                                },
                            ],
                            prefilter: function (e, t) {
                                t
                                    ? bt.prefilters.unshift(e)
                                    : bt.prefilters.push(e);
                            },
                        })),
                            (T.speed = function (e, t, n) {
                                var r =
                                    e && "object" == typeof e
                                        ? T.extend({}, e)
                                        : {
                                              complete:
                                                  n || (!n && t) || (v(e) && e),
                                              duration: e,
                                              easing:
                                                  (n && t) || (t && !v(t) && t),
                                          };
                                return (
                                    T.fx.off
                                        ? (r.duration = 0)
                                        : "number" != typeof r.duration &&
                                          (r.duration in T.fx.speeds
                                              ? (r.duration =
                                                    T.fx.speeds[r.duration])
                                              : (r.duration =
                                                    T.fx.speeds._default)),
                                    (null != r.queue && !0 !== r.queue) ||
                                        (r.queue = "fx"),
                                    (r.old = r.complete),
                                    (r.complete = function () {
                                        v(r.old) && r.old.call(this),
                                            r.queue && T.dequeue(this, r.queue);
                                    }),
                                    r
                                );
                            }),
                            T.fn.extend({
                                fadeTo: function (e, t, n, r) {
                                    return this.filter(ye)
                                        .css("opacity", 0)
                                        .show()
                                        .end()
                                        .animate({ opacity: t }, e, n, r);
                                },
                                animate: function (e, t, n, r) {
                                    var o = T.isEmptyObject(e),
                                        i = T.speed(t, n, r),
                                        a = function () {
                                            var t = bt(
                                                this,
                                                T.extend({}, e),
                                                i
                                            );
                                            (o || se.get(this, "finish")) &&
                                                t.stop(!0);
                                        };
                                    return (
                                        (a.finish = a),
                                        o || !1 === i.queue
                                            ? this.each(a)
                                            : this.queue(i.queue, a)
                                    );
                                },
                                stop: function (e, t, n) {
                                    var r = function (e) {
                                        var t = e.stop;
                                        delete e.stop, t(n);
                                    };
                                    return (
                                        "string" != typeof e &&
                                            ((n = t), (t = e), (e = void 0)),
                                        t && this.queue(e || "fx", []),
                                        this.each(function () {
                                            var t = !0,
                                                o =
                                                    null != e &&
                                                    e + "queueHooks",
                                                i = T.timers,
                                                a = se.get(this);
                                            if (o) a[o] && a[o].stop && r(a[o]);
                                            else
                                                for (o in a)
                                                    a[o] &&
                                                        a[o].stop &&
                                                        ht.test(o) &&
                                                        r(a[o]);
                                            for (o = i.length; o--; )
                                                i[o].elem !== this ||
                                                    (null != e &&
                                                        i[o].queue !== e) ||
                                                    (i[o].anim.stop(n),
                                                    (t = !1),
                                                    i.splice(o, 1));
                                            (!t && n) || T.dequeue(this, e);
                                        })
                                    );
                                },
                                finish: function (e) {
                                    return (
                                        !1 !== e && (e = e || "fx"),
                                        this.each(function () {
                                            var t,
                                                n = se.get(this),
                                                r = n[e + "queue"],
                                                o = n[e + "queueHooks"],
                                                i = T.timers,
                                                a = r ? r.length : 0;
                                            for (
                                                n.finish = !0,
                                                    T.queue(this, e, []),
                                                    o &&
                                                        o.stop &&
                                                        o.stop.call(this, !0),
                                                    t = i.length;
                                                t--;

                                            )
                                                i[t].elem === this &&
                                                    i[t].queue === e &&
                                                    (i[t].anim.stop(!0),
                                                    i.splice(t, 1));
                                            for (t = 0; t < a; t++)
                                                r[t] &&
                                                    r[t].finish &&
                                                    r[t].finish.call(this);
                                            delete n.finish;
                                        })
                                    );
                                },
                            }),
                            T.each(["toggle", "show", "hide"], function (e, t) {
                                var n = T.fn[t];
                                T.fn[t] = function (e, r, o) {
                                    return null == e || "boolean" == typeof e
                                        ? n.apply(this, arguments)
                                        : this.animate(vt(t, !0), e, r, o);
                                };
                            }),
                            T.each(
                                {
                                    slideDown: vt("show"),
                                    slideUp: vt("hide"),
                                    slideToggle: vt("toggle"),
                                    fadeIn: { opacity: "show" },
                                    fadeOut: { opacity: "hide" },
                                    fadeToggle: { opacity: "toggle" },
                                },
                                function (e, t) {
                                    T.fn[e] = function (e, n, r) {
                                        return this.animate(t, e, n, r);
                                    };
                                }
                            ),
                            (T.timers = []),
                            (T.fx.tick = function () {
                                var e,
                                    t = 0,
                                    n = T.timers;
                                for (dt = Date.now(); t < n.length; t++)
                                    (e = n[t])() ||
                                        n[t] !== e ||
                                        n.splice(t--, 1);
                                n.length || T.fx.stop(), (dt = void 0);
                            }),
                            (T.fx.timer = function (e) {
                                T.timers.push(e), T.fx.start();
                            }),
                            (T.fx.interval = 13),
                            (T.fx.start = function () {
                                pt || ((pt = !0), mt());
                            }),
                            (T.fx.stop = function () {
                                pt = null;
                            }),
                            (T.fx.speeds = {
                                slow: 600,
                                fast: 200,
                                _default: 400,
                            }),
                            (T.fn.delay = function (e, t) {
                                return (
                                    (e = (T.fx && T.fx.speeds[e]) || e),
                                    (t = t || "fx"),
                                    this.queue(t, function (t, n) {
                                        var o = r.setTimeout(t, e);
                                        n.stop = function () {
                                            r.clearTimeout(o);
                                        };
                                    })
                                );
                            }),
                            (function () {
                                var e = b.createElement("input"),
                                    t = b
                                        .createElement("select")
                                        .appendChild(b.createElement("option"));
                                (e.type = "checkbox"),
                                    (g.checkOn = "" !== e.value),
                                    (g.optSelected = t.selected),
                                    ((e = b.createElement("input")).value =
                                        "t"),
                                    (e.type = "radio"),
                                    (g.radioValue = "t" === e.value);
                            })();
                        var xt,
                            wt = T.expr.attrHandle;
                        T.fn.extend({
                            attr: function (e, t) {
                                return ee(
                                    this,
                                    T.attr,
                                    e,
                                    t,
                                    arguments.length > 1
                                );
                            },
                            removeAttr: function (e) {
                                return this.each(function () {
                                    T.removeAttr(this, e);
                                });
                            },
                        }),
                            T.extend({
                                attr: function (e, t, n) {
                                    var r,
                                        o,
                                        i = e.nodeType;
                                    if (3 !== i && 8 !== i && 2 !== i)
                                        return void 0 === e.getAttribute
                                            ? T.prop(e, t, n)
                                            : ((1 === i && T.isXMLDoc(e)) ||
                                                  (o =
                                                      T.attrHooks[
                                                          t.toLowerCase()
                                                      ] ||
                                                      (T.expr.match.bool.test(t)
                                                          ? xt
                                                          : void 0)),
                                              void 0 !== n
                                                  ? null === n
                                                      ? void T.removeAttr(e, t)
                                                      : o &&
                                                        "set" in o &&
                                                        void 0 !==
                                                            (r = o.set(e, n, t))
                                                      ? r
                                                      : (e.setAttribute(
                                                            t,
                                                            n + ""
                                                        ),
                                                        n)
                                                  : o &&
                                                    "get" in o &&
                                                    null !== (r = o.get(e, t))
                                                  ? r
                                                  : null ==
                                                    (r = T.find.attr(e, t))
                                                  ? void 0
                                                  : r);
                                },
                                attrHooks: {
                                    type: {
                                        set: function (e, t) {
                                            if (
                                                !g.radioValue &&
                                                "radio" === t &&
                                                A(e, "input")
                                            ) {
                                                var n = e.value;
                                                return (
                                                    e.setAttribute("type", t),
                                                    n && (e.value = n),
                                                    t
                                                );
                                            }
                                        },
                                    },
                                },
                                removeAttr: function (e, t) {
                                    var n,
                                        r = 0,
                                        o = t && t.match(X);
                                    if (o && 1 === e.nodeType)
                                        for (; (n = o[r++]); )
                                            e.removeAttribute(n);
                                },
                            }),
                            (xt = {
                                set: function (e, t, n) {
                                    return (
                                        !1 === t
                                            ? T.removeAttr(e, n)
                                            : e.setAttribute(n, n),
                                        n
                                    );
                                },
                            }),
                            T.each(
                                T.expr.match.bool.source.match(/\w+/g),
                                function (e, t) {
                                    var n = wt[t] || T.find.attr;
                                    wt[t] = function (e, t, r) {
                                        var o,
                                            i,
                                            a = t.toLowerCase();
                                        return (
                                            r ||
                                                ((i = wt[a]),
                                                (wt[a] = o),
                                                (o =
                                                    null != n(e, t, r)
                                                        ? a
                                                        : null),
                                                (wt[a] = i)),
                                            o
                                        );
                                    };
                                }
                            );
                        var jt = /^(?:input|select|textarea|button)$/i,
                            kt = /^(?:a|area)$/i;
                        function Ct(e) {
                            return (e.match(X) || []).join(" ");
                        }
                        function Tt(e) {
                            return (
                                (e.getAttribute && e.getAttribute("class")) ||
                                ""
                            );
                        }
                        function St(e) {
                            return Array.isArray(e)
                                ? e
                                : ("string" == typeof e && e.match(X)) || [];
                        }
                        T.fn.extend({
                            prop: function (e, t) {
                                return ee(
                                    this,
                                    T.prop,
                                    e,
                                    t,
                                    arguments.length > 1
                                );
                            },
                            removeProp: function (e) {
                                return this.each(function () {
                                    delete this[T.propFix[e] || e];
                                });
                            },
                        }),
                            T.extend({
                                prop: function (e, t, n) {
                                    var r,
                                        o,
                                        i = e.nodeType;
                                    if (3 !== i && 8 !== i && 2 !== i)
                                        return (
                                            (1 === i && T.isXMLDoc(e)) ||
                                                ((t = T.propFix[t] || t),
                                                (o = T.propHooks[t])),
                                            void 0 !== n
                                                ? o &&
                                                  "set" in o &&
                                                  void 0 !==
                                                      (r = o.set(e, n, t))
                                                    ? r
                                                    : (e[t] = n)
                                                : o &&
                                                  "get" in o &&
                                                  null !== (r = o.get(e, t))
                                                ? r
                                                : e[t]
                                        );
                                },
                                propHooks: {
                                    tabIndex: {
                                        get: function (e) {
                                            var t = T.find.attr(e, "tabindex");
                                            return t
                                                ? parseInt(t, 10)
                                                : jt.test(e.nodeName) ||
                                                  (kt.test(e.nodeName) &&
                                                      e.href)
                                                ? 0
                                                : -1;
                                        },
                                    },
                                },
                                propFix: { for: "htmlFor", class: "className" },
                            }),
                            g.optSelected ||
                                (T.propHooks.selected = {
                                    get: function (e) {
                                        var t = e.parentNode;
                                        return (
                                            t &&
                                                t.parentNode &&
                                                t.parentNode.selectedIndex,
                                            null
                                        );
                                    },
                                    set: function (e) {
                                        var t = e.parentNode;
                                        t &&
                                            (t.selectedIndex,
                                            t.parentNode &&
                                                t.parentNode.selectedIndex);
                                    },
                                }),
                            T.each(
                                [
                                    "tabIndex",
                                    "readOnly",
                                    "maxLength",
                                    "cellSpacing",
                                    "cellPadding",
                                    "rowSpan",
                                    "colSpan",
                                    "useMap",
                                    "frameBorder",
                                    "contentEditable",
                                ],
                                function () {
                                    T.propFix[this.toLowerCase()] = this;
                                }
                            ),
                            T.fn.extend({
                                addClass: function (e) {
                                    var t, n, r, o, i, a;
                                    return v(e)
                                        ? this.each(function (t) {
                                              T(this).addClass(
                                                  e.call(this, t, Tt(this))
                                              );
                                          })
                                        : (t = St(e)).length
                                        ? this.each(function () {
                                              if (
                                                  ((r = Tt(this)),
                                                  (n =
                                                      1 === this.nodeType &&
                                                      " " + Ct(r) + " "))
                                              ) {
                                                  for (i = 0; i < t.length; i++)
                                                      (o = t[i]),
                                                          n.indexOf(
                                                              " " + o + " "
                                                          ) < 0 &&
                                                              (n += o + " ");
                                                  (a = Ct(n)),
                                                      r !== a &&
                                                          this.setAttribute(
                                                              "class",
                                                              a
                                                          );
                                              }
                                          })
                                        : this;
                                },
                                removeClass: function (e) {
                                    var t, n, r, o, i, a;
                                    return v(e)
                                        ? this.each(function (t) {
                                              T(this).removeClass(
                                                  e.call(this, t, Tt(this))
                                              );
                                          })
                                        : arguments.length
                                        ? (t = St(e)).length
                                            ? this.each(function () {
                                                  if (
                                                      ((r = Tt(this)),
                                                      (n =
                                                          1 === this.nodeType &&
                                                          " " + Ct(r) + " "))
                                                  ) {
                                                      for (
                                                          i = 0;
                                                          i < t.length;
                                                          i++
                                                      )
                                                          for (
                                                              o = t[i];
                                                              n.indexOf(
                                                                  " " + o + " "
                                                              ) > -1;

                                                          )
                                                              n = n.replace(
                                                                  " " + o + " ",
                                                                  " "
                                                              );
                                                      (a = Ct(n)),
                                                          r !== a &&
                                                              this.setAttribute(
                                                                  "class",
                                                                  a
                                                              );
                                                  }
                                              })
                                            : this
                                        : this.attr("class", "");
                                },
                                toggleClass: function (e, t) {
                                    var n,
                                        r,
                                        o,
                                        i,
                                        a = typeof e,
                                        s = "string" === a || Array.isArray(e);
                                    return v(e)
                                        ? this.each(function (n) {
                                              T(this).toggleClass(
                                                  e.call(this, n, Tt(this), t),
                                                  t
                                              );
                                          })
                                        : "boolean" == typeof t && s
                                        ? t
                                            ? this.addClass(e)
                                            : this.removeClass(e)
                                        : ((n = St(e)),
                                          this.each(function () {
                                              if (s)
                                                  for (
                                                      i = T(this), o = 0;
                                                      o < n.length;
                                                      o++
                                                  )
                                                      (r = n[o]),
                                                          i.hasClass(r)
                                                              ? i.removeClass(r)
                                                              : i.addClass(r);
                                              else
                                                  (void 0 !== e &&
                                                      "boolean" !== a) ||
                                                      ((r = Tt(this)) &&
                                                          se.set(
                                                              this,
                                                              "__className__",
                                                              r
                                                          ),
                                                      this.setAttribute &&
                                                          this.setAttribute(
                                                              "class",
                                                              r || !1 === e
                                                                  ? ""
                                                                  : se.get(
                                                                        this,
                                                                        "__className__"
                                                                    ) || ""
                                                          ));
                                          }));
                                },
                                hasClass: function (e) {
                                    var t,
                                        n,
                                        r = 0;
                                    for (t = " " + e + " "; (n = this[r++]); )
                                        if (
                                            1 === n.nodeType &&
                                            (" " + Ct(Tt(n)) + " ").indexOf(t) >
                                                -1
                                        )
                                            return !0;
                                    return !1;
                                },
                            });
                        var At = /\r/g;
                        T.fn.extend({
                            val: function (e) {
                                var t,
                                    n,
                                    r,
                                    o = this[0];
                                return arguments.length
                                    ? ((r = v(e)),
                                      this.each(function (n) {
                                          var o;
                                          1 === this.nodeType &&
                                              (null ==
                                              (o = r
                                                  ? e.call(
                                                        this,
                                                        n,
                                                        T(this).val()
                                                    )
                                                  : e)
                                                  ? (o = "")
                                                  : "number" == typeof o
                                                  ? (o += "")
                                                  : Array.isArray(o) &&
                                                    (o = T.map(o, function (e) {
                                                        return null == e
                                                            ? ""
                                                            : e + "";
                                                    })),
                                              ((t =
                                                  T.valHooks[this.type] ||
                                                  T.valHooks[
                                                      this.nodeName.toLowerCase()
                                                  ]) &&
                                                  "set" in t &&
                                                  void 0 !==
                                                      t.set(
                                                          this,
                                                          o,
                                                          "value"
                                                      )) ||
                                                  (this.value = o));
                                      }))
                                    : o
                                    ? (t =
                                          T.valHooks[o.type] ||
                                          T.valHooks[
                                              o.nodeName.toLowerCase()
                                          ]) &&
                                      "get" in t &&
                                      void 0 !== (n = t.get(o, "value"))
                                        ? n
                                        : "string" == typeof (n = o.value)
                                        ? n.replace(At, "")
                                        : null == n
                                        ? ""
                                        : n
                                    : void 0;
                            },
                        }),
                            T.extend({
                                valHooks: {
                                    option: {
                                        get: function (e) {
                                            var t = T.find.attr(e, "value");
                                            return null != t
                                                ? t
                                                : Ct(T.text(e));
                                        },
                                    },
                                    select: {
                                        get: function (e) {
                                            var t,
                                                n,
                                                r,
                                                o = e.options,
                                                i = e.selectedIndex,
                                                a = "select-one" === e.type,
                                                s = a ? null : [],
                                                c = a ? i + 1 : o.length;
                                            for (
                                                r = i < 0 ? c : a ? i : 0;
                                                r < c;
                                                r++
                                            )
                                                if (
                                                    ((n = o[r]).selected ||
                                                        r === i) &&
                                                    !n.disabled &&
                                                    (!n.parentNode.disabled ||
                                                        !A(
                                                            n.parentNode,
                                                            "optgroup"
                                                        ))
                                                ) {
                                                    if (((t = T(n).val()), a))
                                                        return t;
                                                    s.push(t);
                                                }
                                            return s;
                                        },
                                        set: function (e, t) {
                                            for (
                                                var n,
                                                    r,
                                                    o = e.options,
                                                    i = T.makeArray(t),
                                                    a = o.length;
                                                a--;

                                            )
                                                ((r = o[a]).selected =
                                                    T.inArray(
                                                        T.valHooks.option.get(
                                                            r
                                                        ),
                                                        i
                                                    ) > -1) && (n = !0);
                                            return (
                                                n || (e.selectedIndex = -1), i
                                            );
                                        },
                                    },
                                },
                            }),
                            T.each(["radio", "checkbox"], function () {
                                (T.valHooks[this] = {
                                    set: function (e, t) {
                                        if (Array.isArray(t))
                                            return (e.checked =
                                                T.inArray(T(e).val(), t) > -1);
                                    },
                                }),
                                    g.checkOn ||
                                        (T.valHooks[this].get = function (e) {
                                            return null ===
                                                e.getAttribute("value")
                                                ? "on"
                                                : e.value;
                                        });
                            });
                        var Et = r.location,
                            Dt = { guid: Date.now() },
                            Pt = /\?/;
                        T.parseXML = function (e) {
                            var t, n;
                            if (!e || "string" != typeof e) return null;
                            try {
                                t = new r.DOMParser().parseFromString(
                                    e,
                                    "text/xml"
                                );
                            } catch (e) {}
                            return (
                                (n =
                                    t &&
                                    t.getElementsByTagName("parsererror")[0]),
                                (t && !n) ||
                                    T.error(
                                        "Invalid XML: " +
                                            (n
                                                ? T.map(
                                                      n.childNodes,
                                                      function (e) {
                                                          return e.textContent;
                                                      }
                                                  ).join("\n")
                                                : e)
                                    ),
                                t
                            );
                        };
                        var qt = /^(?:focusinfocus|focusoutblur)$/,
                            Nt = function (e) {
                                e.stopPropagation();
                            };
                        T.extend(T.event, {
                            trigger: function (e, t, n, o) {
                                var i,
                                    a,
                                    s,
                                    c,
                                    u,
                                    l,
                                    d,
                                    p,
                                    h = [n || b],
                                    m = f.call(e, "type") ? e.type : e,
                                    g = f.call(e, "namespace")
                                        ? e.namespace.split(".")
                                        : [];
                                if (
                                    ((a = p = s = n = n || b),
                                    3 !== n.nodeType &&
                                        8 !== n.nodeType &&
                                        !qt.test(m + T.event.triggered) &&
                                        (m.indexOf(".") > -1 &&
                                            ((g = m.split(".")),
                                            (m = g.shift()),
                                            g.sort()),
                                        (u = m.indexOf(":") < 0 && "on" + m),
                                        ((e = e[T.expando]
                                            ? e
                                            : new T.Event(
                                                  m,
                                                  "object" == typeof e && e
                                              )).isTrigger = o ? 2 : 3),
                                        (e.namespace = g.join(".")),
                                        (e.rnamespace = e.namespace
                                            ? new RegExp(
                                                  "(^|\\.)" +
                                                      g.join("\\.(?:.*\\.|)") +
                                                      "(\\.|$)"
                                              )
                                            : null),
                                        (e.result = void 0),
                                        e.target || (e.target = n),
                                        (t =
                                            null == t
                                                ? [e]
                                                : T.makeArray(t, [e])),
                                        (d = T.event.special[m] || {}),
                                        o ||
                                            !d.trigger ||
                                            !1 !== d.trigger.apply(n, t)))
                                ) {
                                    if (!o && !d.noBubble && !y(n)) {
                                        for (
                                            c = d.delegateType || m,
                                                qt.test(c + m) ||
                                                    (a = a.parentNode);
                                            a;
                                            a = a.parentNode
                                        )
                                            h.push(a), (s = a);
                                        s === (n.ownerDocument || b) &&
                                            h.push(
                                                s.defaultView ||
                                                    s.parentWindow ||
                                                    r
                                            );
                                    }
                                    for (
                                        i = 0;
                                        (a = h[i++]) &&
                                        !e.isPropagationStopped();

                                    )
                                        (p = a),
                                            (e.type =
                                                i > 1 ? c : d.bindType || m),
                                            (l =
                                                (se.get(a, "events") ||
                                                    Object.create(null))[
                                                    e.type
                                                ] && se.get(a, "handle")) &&
                                                l.apply(a, t),
                                            (l = u && a[u]) &&
                                                l.apply &&
                                                ie(a) &&
                                                ((e.result = l.apply(a, t)),
                                                !1 === e.result &&
                                                    e.preventDefault());
                                    return (
                                        (e.type = m),
                                        o ||
                                            e.isDefaultPrevented() ||
                                            (d._default &&
                                                !1 !==
                                                    d._default.apply(
                                                        h.pop(),
                                                        t
                                                    )) ||
                                            !ie(n) ||
                                            (u &&
                                                v(n[m]) &&
                                                !y(n) &&
                                                ((s = n[u]) && (n[u] = null),
                                                (T.event.triggered = m),
                                                e.isPropagationStopped() &&
                                                    p.addEventListener(m, Nt),
                                                n[m](),
                                                e.isPropagationStopped() &&
                                                    p.removeEventListener(
                                                        m,
                                                        Nt
                                                    ),
                                                (T.event.triggered = void 0),
                                                s && (n[u] = s))),
                                        e.result
                                    );
                                }
                            },
                            simulate: function (e, t, n) {
                                var r = T.extend(new T.Event(), n, {
                                    type: e,
                                    isSimulated: !0,
                                });
                                T.event.trigger(r, null, t);
                            },
                        }),
                            T.fn.extend({
                                trigger: function (e, t) {
                                    return this.each(function () {
                                        T.event.trigger(e, t, this);
                                    });
                                },
                                triggerHandler: function (e, t) {
                                    var n = this[0];
                                    if (n) return T.event.trigger(e, t, n, !0);
                                },
                            });
                        var Ot = /\[\]$/,
                            _t = /\r?\n/g,
                            $t = /^(?:submit|button|image|reset|file)$/i,
                            Ht = /^(?:input|select|textarea|keygen)/i;
                        function Lt(e, t, n, r) {
                            var o;
                            if (Array.isArray(t))
                                T.each(t, function (t, o) {
                                    n || Ot.test(e)
                                        ? r(e, o)
                                        : Lt(
                                              e +
                                                  "[" +
                                                  ("object" == typeof o &&
                                                  null != o
                                                      ? t
                                                      : "") +
                                                  "]",
                                              o,
                                              n,
                                              r
                                          );
                                });
                            else if (n || "object" !== j(t)) r(e, t);
                            else for (o in t) Lt(e + "[" + o + "]", t[o], n, r);
                        }
                        (T.param = function (e, t) {
                            var n,
                                r = [],
                                o = function (e, t) {
                                    var n = v(t) ? t() : t;
                                    r[r.length] =
                                        encodeURIComponent(e) +
                                        "=" +
                                        encodeURIComponent(null == n ? "" : n);
                                };
                            if (null == e) return "";
                            if (
                                Array.isArray(e) ||
                                (e.jquery && !T.isPlainObject(e))
                            )
                                T.each(e, function () {
                                    o(this.name, this.value);
                                });
                            else for (n in e) Lt(n, e[n], t, o);
                            return r.join("&");
                        }),
                            T.fn.extend({
                                serialize: function () {
                                    return T.param(this.serializeArray());
                                },
                                serializeArray: function () {
                                    return this.map(function () {
                                        var e = T.prop(this, "elements");
                                        return e ? T.makeArray(e) : this;
                                    })
                                        .filter(function () {
                                            var e = this.type;
                                            return (
                                                this.name &&
                                                !T(this).is(":disabled") &&
                                                Ht.test(this.nodeName) &&
                                                !$t.test(e) &&
                                                (this.checked || !Te.test(e))
                                            );
                                        })
                                        .map(function (e, t) {
                                            var n = T(this).val();
                                            return null == n
                                                ? null
                                                : Array.isArray(n)
                                                ? T.map(n, function (e) {
                                                      return {
                                                          name: t.name,
                                                          value: e.replace(
                                                              _t,
                                                              "\r\n"
                                                          ),
                                                      };
                                                  })
                                                : {
                                                      name: t.name,
                                                      value: n.replace(
                                                          _t,
                                                          "\r\n"
                                                      ),
                                                  };
                                        })
                                        .get();
                                },
                            });
                        var Rt = /%20/g,
                            Mt = /#.*$/,
                            It = /([?&])_=[^&]*/,
                            Wt = /^(.*?):[ \t]*([^\r\n]*)$/gm,
                            Ft = /^(?:GET|HEAD)$/,
                            Qt = /^\/\//,
                            Bt = {},
                            zt = {},
                            Ut = "*/".concat("*"),
                            Xt = b.createElement("a");
                        function Vt(e) {
                            return function (t, n) {
                                "string" != typeof t && ((n = t), (t = "*"));
                                var r,
                                    o = 0,
                                    i = t.toLowerCase().match(X) || [];
                                if (v(n))
                                    for (; (r = i[o++]); )
                                        "+" === r[0]
                                            ? ((r = r.slice(1) || "*"),
                                              (e[r] = e[r] || []).unshift(n))
                                            : (e[r] = e[r] || []).push(n);
                            };
                        }
                        function Jt(e, t, n, r) {
                            var o = {},
                                i = e === zt;
                            function a(s) {
                                var c;
                                return (
                                    (o[s] = !0),
                                    T.each(e[s] || [], function (e, s) {
                                        var u = s(t, n, r);
                                        return "string" != typeof u || i || o[u]
                                            ? i
                                                ? !(c = u)
                                                : void 0
                                            : (t.dataTypes.unshift(u),
                                              a(u),
                                              !1);
                                    }),
                                    c
                                );
                            }
                            return a(t.dataTypes[0]) || (!o["*"] && a("*"));
                        }
                        function Gt(e, t) {
                            var n,
                                r,
                                o = T.ajaxSettings.flatOptions || {};
                            for (n in t)
                                void 0 !== t[n] &&
                                    ((o[n] ? e : r || (r = {}))[n] = t[n]);
                            return r && T.extend(!0, e, r), e;
                        }
                        (Xt.href = Et.href),
                            T.extend({
                                active: 0,
                                lastModified: {},
                                etag: {},
                                ajaxSettings: {
                                    url: Et.href,
                                    type: "GET",
                                    isLocal:
                                        /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(
                                            Et.protocol
                                        ),
                                    global: !0,
                                    processData: !0,
                                    async: !0,
                                    contentType:
                                        "application/x-www-form-urlencoded; charset=UTF-8",
                                    accepts: {
                                        "*": Ut,
                                        text: "text/plain",
                                        html: "text/html",
                                        xml: "application/xml, text/xml",
                                        json: "application/json, text/javascript",
                                    },
                                    contents: {
                                        xml: /\bxml\b/,
                                        html: /\bhtml/,
                                        json: /\bjson\b/,
                                    },
                                    responseFields: {
                                        xml: "responseXML",
                                        text: "responseText",
                                        json: "responseJSON",
                                    },
                                    converters: {
                                        "* text": String,
                                        "text html": !0,
                                        "text json": JSON.parse,
                                        "text xml": T.parseXML,
                                    },
                                    flatOptions: { url: !0, context: !0 },
                                },
                                ajaxSetup: function (e, t) {
                                    return t
                                        ? Gt(Gt(e, T.ajaxSettings), t)
                                        : Gt(T.ajaxSettings, e);
                                },
                                ajaxPrefilter: Vt(Bt),
                                ajaxTransport: Vt(zt),
                                ajax: function (e, t) {
                                    "object" == typeof e &&
                                        ((t = e), (e = void 0)),
                                        (t = t || {});
                                    var n,
                                        o,
                                        i,
                                        a,
                                        s,
                                        c,
                                        u,
                                        l,
                                        d,
                                        p,
                                        f = T.ajaxSetup({}, t),
                                        h = f.context || f,
                                        m =
                                            f.context &&
                                            (h.nodeType || h.jquery)
                                                ? T(h)
                                                : T.event,
                                        g = T.Deferred(),
                                        v = T.Callbacks("once memory"),
                                        y = f.statusCode || {},
                                        x = {},
                                        w = {},
                                        j = "canceled",
                                        k = {
                                            readyState: 0,
                                            getResponseHeader: function (e) {
                                                var t;
                                                if (u) {
                                                    if (!a)
                                                        for (
                                                            a = {};
                                                            (t = Wt.exec(i));

                                                        )
                                                            a[
                                                                t[1].toLowerCase() +
                                                                    " "
                                                            ] = (
                                                                a[
                                                                    t[1].toLowerCase() +
                                                                        " "
                                                                ] || []
                                                            ).concat(t[2]);
                                                    t =
                                                        a[
                                                            e.toLowerCase() +
                                                                " "
                                                        ];
                                                }
                                                return null == t
                                                    ? null
                                                    : t.join(", ");
                                            },
                                            getAllResponseHeaders: function () {
                                                return u ? i : null;
                                            },
                                            setRequestHeader: function (e, t) {
                                                return (
                                                    null == u &&
                                                        ((e = w[
                                                            e.toLowerCase()
                                                        ] =
                                                            w[
                                                                e.toLowerCase()
                                                            ] || e),
                                                        (x[e] = t)),
                                                    this
                                                );
                                            },
                                            overrideMimeType: function (e) {
                                                return (
                                                    null == u &&
                                                        (f.mimeType = e),
                                                    this
                                                );
                                            },
                                            statusCode: function (e) {
                                                var t;
                                                if (e)
                                                    if (u)
                                                        k.always(e[k.status]);
                                                    else
                                                        for (t in e)
                                                            y[t] = [y[t], e[t]];
                                                return this;
                                            },
                                            abort: function (e) {
                                                var t = e || j;
                                                return (
                                                    n && n.abort(t),
                                                    C(0, t),
                                                    this
                                                );
                                            },
                                        };
                                    if (
                                        (g.promise(k),
                                        (f.url = (
                                            (e || f.url || Et.href) + ""
                                        ).replace(Qt, Et.protocol + "//")),
                                        (f.type =
                                            t.method ||
                                            t.type ||
                                            f.method ||
                                            f.type),
                                        (f.dataTypes = (f.dataType || "*")
                                            .toLowerCase()
                                            .match(X) || [""]),
                                        null == f.crossDomain)
                                    ) {
                                        c = b.createElement("a");
                                        try {
                                            (c.href = f.url),
                                                (c.href = c.href),
                                                (f.crossDomain =
                                                    Xt.protocol +
                                                        "//" +
                                                        Xt.host !=
                                                    c.protocol + "//" + c.host);
                                        } catch (e) {
                                            f.crossDomain = !0;
                                        }
                                    }
                                    if (
                                        (f.data &&
                                            f.processData &&
                                            "string" != typeof f.data &&
                                            (f.data = T.param(
                                                f.data,
                                                f.traditional
                                            )),
                                        Jt(Bt, f, t, k),
                                        u)
                                    )
                                        return k;
                                    for (d in ((l = T.event && f.global) &&
                                        0 == T.active++ &&
                                        T.event.trigger("ajaxStart"),
                                    (f.type = f.type.toUpperCase()),
                                    (f.hasContent = !Ft.test(f.type)),
                                    (o = f.url.replace(Mt, "")),
                                    f.hasContent
                                        ? f.data &&
                                          f.processData &&
                                          0 ===
                                              (f.contentType || "").indexOf(
                                                  "application/x-www-form-urlencoded"
                                              ) &&
                                          (f.data = f.data.replace(Rt, "+"))
                                        : ((p = f.url.slice(o.length)),
                                          f.data &&
                                              (f.processData ||
                                                  "string" == typeof f.data) &&
                                              ((o +=
                                                  (Pt.test(o) ? "&" : "?") +
                                                  f.data),
                                              delete f.data),
                                          !1 === f.cache &&
                                              ((o = o.replace(It, "$1")),
                                              (p =
                                                  (Pt.test(o) ? "&" : "?") +
                                                  "_=" +
                                                  Dt.guid++ +
                                                  p)),
                                          (f.url = o + p)),
                                    f.ifModified &&
                                        (T.lastModified[o] &&
                                            k.setRequestHeader(
                                                "If-Modified-Since",
                                                T.lastModified[o]
                                            ),
                                        T.etag[o] &&
                                            k.setRequestHeader(
                                                "If-None-Match",
                                                T.etag[o]
                                            )),
                                    ((f.data &&
                                        f.hasContent &&
                                        !1 !== f.contentType) ||
                                        t.contentType) &&
                                        k.setRequestHeader(
                                            "Content-Type",
                                            f.contentType
                                        ),
                                    k.setRequestHeader(
                                        "Accept",
                                        f.dataTypes[0] &&
                                            f.accepts[f.dataTypes[0]]
                                            ? f.accepts[f.dataTypes[0]] +
                                                  ("*" !== f.dataTypes[0]
                                                      ? ", " + Ut + "; q=0.01"
                                                      : "")
                                            : f.accepts["*"]
                                    ),
                                    f.headers))
                                        k.setRequestHeader(d, f.headers[d]);
                                    if (
                                        f.beforeSend &&
                                        (!1 === f.beforeSend.call(h, k, f) || u)
                                    )
                                        return k.abort();
                                    if (
                                        ((j = "abort"),
                                        v.add(f.complete),
                                        k.done(f.success),
                                        k.fail(f.error),
                                        (n = Jt(zt, f, t, k)))
                                    ) {
                                        if (
                                            ((k.readyState = 1),
                                            l && m.trigger("ajaxSend", [k, f]),
                                            u)
                                        )
                                            return k;
                                        f.async &&
                                            f.timeout > 0 &&
                                            (s = r.setTimeout(function () {
                                                k.abort("timeout");
                                            }, f.timeout));
                                        try {
                                            (u = !1), n.send(x, C);
                                        } catch (e) {
                                            if (u) throw e;
                                            C(-1, e);
                                        }
                                    } else C(-1, "No Transport");
                                    function C(e, t, a, c) {
                                        var d,
                                            p,
                                            b,
                                            x,
                                            w,
                                            j = t;
                                        u ||
                                            ((u = !0),
                                            s && r.clearTimeout(s),
                                            (n = void 0),
                                            (i = c || ""),
                                            (k.readyState = e > 0 ? 4 : 0),
                                            (d =
                                                (e >= 200 && e < 300) ||
                                                304 === e),
                                            a &&
                                                (x = (function (e, t, n) {
                                                    for (
                                                        var r,
                                                            o,
                                                            i,
                                                            a,
                                                            s = e.contents,
                                                            c = e.dataTypes;
                                                        "*" === c[0];

                                                    )
                                                        c.shift(),
                                                            void 0 === r &&
                                                                (r =
                                                                    e.mimeType ||
                                                                    t.getResponseHeader(
                                                                        "Content-Type"
                                                                    ));
                                                    if (r)
                                                        for (o in s)
                                                            if (
                                                                s[o] &&
                                                                s[o].test(r)
                                                            ) {
                                                                c.unshift(o);
                                                                break;
                                                            }
                                                    if (c[0] in n) i = c[0];
                                                    else {
                                                        for (o in n) {
                                                            if (
                                                                !c[0] ||
                                                                e.converters[
                                                                    o +
                                                                        " " +
                                                                        c[0]
                                                                ]
                                                            ) {
                                                                i = o;
                                                                break;
                                                            }
                                                            a || (a = o);
                                                        }
                                                        i = i || a;
                                                    }
                                                    if (i)
                                                        return (
                                                            i !== c[0] &&
                                                                c.unshift(i),
                                                            n[i]
                                                        );
                                                })(f, k, a)),
                                            !d &&
                                                T.inArray(
                                                    "script",
                                                    f.dataTypes
                                                ) > -1 &&
                                                T.inArray("json", f.dataTypes) <
                                                    0 &&
                                                (f.converters["text script"] =
                                                    function () {}),
                                            (x = (function (e, t, n, r) {
                                                var o,
                                                    i,
                                                    a,
                                                    s,
                                                    c,
                                                    u = {},
                                                    l = e.dataTypes.slice();
                                                if (l[1])
                                                    for (a in e.converters)
                                                        u[a.toLowerCase()] =
                                                            e.converters[a];
                                                for (i = l.shift(); i; )
                                                    if (
                                                        (e.responseFields[i] &&
                                                            (n[
                                                                e.responseFields[
                                                                    i
                                                                ]
                                                            ] = t),
                                                        !c &&
                                                            r &&
                                                            e.dataFilter &&
                                                            (t = e.dataFilter(
                                                                t,
                                                                e.dataType
                                                            )),
                                                        (c = i),
                                                        (i = l.shift()))
                                                    )
                                                        if ("*" === i) i = c;
                                                        else if (
                                                            "*" !== c &&
                                                            c !== i
                                                        ) {
                                                            if (
                                                                !(a =
                                                                    u[
                                                                        c +
                                                                            " " +
                                                                            i
                                                                    ] ||
                                                                    u["* " + i])
                                                            )
                                                                for (o in u)
                                                                    if (
                                                                        (s =
                                                                            o.split(
                                                                                " "
                                                                            ))[1] ===
                                                                            i &&
                                                                        (a =
                                                                            u[
                                                                                c +
                                                                                    " " +
                                                                                    s[0]
                                                                            ] ||
                                                                            u[
                                                                                "* " +
                                                                                    s[0]
                                                                            ])
                                                                    ) {
                                                                        !0 === a
                                                                            ? (a =
                                                                                  u[
                                                                                      o
                                                                                  ])
                                                                            : !0 !==
                                                                                  u[
                                                                                      o
                                                                                  ] &&
                                                                              ((i =
                                                                                  s[0]),
                                                                              l.unshift(
                                                                                  s[1]
                                                                              ));
                                                                        break;
                                                                    }
                                                            if (!0 !== a)
                                                                if (
                                                                    a &&
                                                                    e.throws
                                                                )
                                                                    t = a(t);
                                                                else
                                                                    try {
                                                                        t =
                                                                            a(
                                                                                t
                                                                            );
                                                                    } catch (e) {
                                                                        return {
                                                                            state: "parsererror",
                                                                            error: a
                                                                                ? e
                                                                                : "No conversion from " +
                                                                                  c +
                                                                                  " to " +
                                                                                  i,
                                                                        };
                                                                    }
                                                        }
                                                return {
                                                    state: "success",
                                                    data: t,
                                                };
                                            })(f, x, k, d)),
                                            d
                                                ? (f.ifModified &&
                                                      ((w =
                                                          k.getResponseHeader(
                                                              "Last-Modified"
                                                          )) &&
                                                          (T.lastModified[o] =
                                                              w),
                                                      (w =
                                                          k.getResponseHeader(
                                                              "etag"
                                                          )) &&
                                                          (T.etag[o] = w)),
                                                  204 === e || "HEAD" === f.type
                                                      ? (j = "nocontent")
                                                      : 304 === e
                                                      ? (j = "notmodified")
                                                      : ((j = x.state),
                                                        (p = x.data),
                                                        (d = !(b = x.error))))
                                                : ((b = j),
                                                  (!e && j) ||
                                                      ((j = "error"),
                                                      e < 0 && (e = 0))),
                                            (k.status = e),
                                            (k.statusText = (t || j) + ""),
                                            d
                                                ? g.resolveWith(h, [p, j, k])
                                                : g.rejectWith(h, [k, j, b]),
                                            k.statusCode(y),
                                            (y = void 0),
                                            l &&
                                                m.trigger(
                                                    d
                                                        ? "ajaxSuccess"
                                                        : "ajaxError",
                                                    [k, f, d ? p : b]
                                                ),
                                            v.fireWith(h, [k, j]),
                                            l &&
                                                (m.trigger("ajaxComplete", [
                                                    k,
                                                    f,
                                                ]),
                                                --T.active ||
                                                    T.event.trigger(
                                                        "ajaxStop"
                                                    )));
                                    }
                                    return k;
                                },
                                getJSON: function (e, t, n) {
                                    return T.get(e, t, n, "json");
                                },
                                getScript: function (e, t) {
                                    return T.get(e, void 0, t, "script");
                                },
                            }),
                            T.each(["get", "post"], function (e, t) {
                                T[t] = function (e, n, r, o) {
                                    return (
                                        v(n) &&
                                            ((o = o || r),
                                            (r = n),
                                            (n = void 0)),
                                        T.ajax(
                                            T.extend(
                                                {
                                                    url: e,
                                                    type: t,
                                                    dataType: o,
                                                    data: n,
                                                    success: r,
                                                },
                                                T.isPlainObject(e) && e
                                            )
                                        )
                                    );
                                };
                            }),
                            T.ajaxPrefilter(function (e) {
                                var t;
                                for (t in e.headers)
                                    "content-type" === t.toLowerCase() &&
                                        (e.contentType = e.headers[t] || "");
                            }),
                            (T._evalUrl = function (e, t, n) {
                                return T.ajax({
                                    url: e,
                                    type: "GET",
                                    dataType: "script",
                                    cache: !0,
                                    async: !1,
                                    global: !1,
                                    converters: {
                                        "text script": function () {},
                                    },
                                    dataFilter: function (e) {
                                        T.globalEval(e, t, n);
                                    },
                                });
                            }),
                            T.fn.extend({
                                wrapAll: function (e) {
                                    var t;
                                    return (
                                        this[0] &&
                                            (v(e) && (e = e.call(this[0])),
                                            (t = T(e, this[0].ownerDocument)
                                                .eq(0)
                                                .clone(!0)),
                                            this[0].parentNode &&
                                                t.insertBefore(this[0]),
                                            t
                                                .map(function () {
                                                    for (
                                                        var e = this;
                                                        e.firstElementChild;

                                                    )
                                                        e = e.firstElementChild;
                                                    return e;
                                                })
                                                .append(this)),
                                        this
                                    );
                                },
                                wrapInner: function (e) {
                                    return v(e)
                                        ? this.each(function (t) {
                                              T(this).wrapInner(
                                                  e.call(this, t)
                                              );
                                          })
                                        : this.each(function () {
                                              var t = T(this),
                                                  n = t.contents();
                                              n.length
                                                  ? n.wrapAll(e)
                                                  : t.append(e);
                                          });
                                },
                                wrap: function (e) {
                                    var t = v(e);
                                    return this.each(function (n) {
                                        T(this).wrapAll(
                                            t ? e.call(this, n) : e
                                        );
                                    });
                                },
                                unwrap: function (e) {
                                    return (
                                        this.parent(e)
                                            .not("body")
                                            .each(function () {
                                                T(this).replaceWith(
                                                    this.childNodes
                                                );
                                            }),
                                        this
                                    );
                                },
                            }),
                            (T.expr.pseudos.hidden = function (e) {
                                return !T.expr.pseudos.visible(e);
                            }),
                            (T.expr.pseudos.visible = function (e) {
                                return !!(
                                    e.offsetWidth ||
                                    e.offsetHeight ||
                                    e.getClientRects().length
                                );
                            }),
                            (T.ajaxSettings.xhr = function () {
                                try {
                                    return new r.XMLHttpRequest();
                                } catch (e) {}
                            });
                        var Yt = { 0: 200, 1223: 204 },
                            Kt = T.ajaxSettings.xhr();
                        (g.cors = !!Kt && "withCredentials" in Kt),
                            (g.ajax = Kt = !!Kt),
                            T.ajaxTransport(function (e) {
                                var t, n;
                                if (g.cors || (Kt && !e.crossDomain))
                                    return {
                                        send: function (o, i) {
                                            var a,
                                                s = e.xhr();
                                            if (
                                                (s.open(
                                                    e.type,
                                                    e.url,
                                                    e.async,
                                                    e.username,
                                                    e.password
                                                ),
                                                e.xhrFields)
                                            )
                                                for (a in e.xhrFields)
                                                    s[a] = e.xhrFields[a];
                                            for (a in (e.mimeType &&
                                                s.overrideMimeType &&
                                                s.overrideMimeType(e.mimeType),
                                            e.crossDomain ||
                                                o["X-Requested-With"] ||
                                                (o["X-Requested-With"] =
                                                    "XMLHttpRequest"),
                                            o))
                                                s.setRequestHeader(a, o[a]);
                                            (t = function (e) {
                                                return function () {
                                                    t &&
                                                        ((t =
                                                            n =
                                                            s.onload =
                                                            s.onerror =
                                                            s.onabort =
                                                            s.ontimeout =
                                                            s.onreadystatechange =
                                                                null),
                                                        "abort" === e
                                                            ? s.abort()
                                                            : "error" === e
                                                            ? "number" !=
                                                              typeof s.status
                                                                ? i(0, "error")
                                                                : i(
                                                                      s.status,
                                                                      s.statusText
                                                                  )
                                                            : i(
                                                                  Yt[
                                                                      s.status
                                                                  ] || s.status,
                                                                  s.statusText,
                                                                  "text" !==
                                                                      (s.responseType ||
                                                                          "text") ||
                                                                      "string" !=
                                                                          typeof s.responseText
                                                                      ? {
                                                                            binary: s.response,
                                                                        }
                                                                      : {
                                                                            text: s.responseText,
                                                                        },
                                                                  s.getAllResponseHeaders()
                                                              ));
                                                };
                                            }),
                                                (s.onload = t()),
                                                (n =
                                                    s.onerror =
                                                    s.ontimeout =
                                                        t("error")),
                                                void 0 !== s.onabort
                                                    ? (s.onabort = n)
                                                    : (s.onreadystatechange =
                                                          function () {
                                                              4 ===
                                                                  s.readyState &&
                                                                  r.setTimeout(
                                                                      function () {
                                                                          t &&
                                                                              n();
                                                                      }
                                                                  );
                                                          }),
                                                (t = t("abort"));
                                            try {
                                                s.send(
                                                    (e.hasContent && e.data) ||
                                                        null
                                                );
                                            } catch (e) {
                                                if (t) throw e;
                                            }
                                        },
                                        abort: function () {
                                            t && t();
                                        },
                                    };
                            }),
                            T.ajaxPrefilter(function (e) {
                                e.crossDomain && (e.contents.script = !1);
                            }),
                            T.ajaxSetup({
                                accepts: {
                                    script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript",
                                },
                                contents: { script: /\b(?:java|ecma)script\b/ },
                                converters: {
                                    "text script": function (e) {
                                        return T.globalEval(e), e;
                                    },
                                },
                            }),
                            T.ajaxPrefilter("script", function (e) {
                                void 0 === e.cache && (e.cache = !1),
                                    e.crossDomain && (e.type = "GET");
                            }),
                            T.ajaxTransport("script", function (e) {
                                var t, n;
                                if (e.crossDomain || e.scriptAttrs)
                                    return {
                                        send: function (r, o) {
                                            (t = T("<script>")
                                                .attr(e.scriptAttrs || {})
                                                .prop({
                                                    charset: e.scriptCharset,
                                                    src: e.url,
                                                })
                                                .on(
                                                    "load error",
                                                    (n = function (e) {
                                                        t.remove(),
                                                            (n = null),
                                                            e &&
                                                                o(
                                                                    "error" ===
                                                                        e.type
                                                                        ? 404
                                                                        : 200,
                                                                    e.type
                                                                );
                                                    })
                                                )),
                                                b.head.appendChild(t[0]);
                                        },
                                        abort: function () {
                                            n && n();
                                        },
                                    };
                            });
                        var Zt,
                            en = [],
                            tn = /(=)\?(?=&|$)|\?\?/;
                        T.ajaxSetup({
                            jsonp: "callback",
                            jsonpCallback: function () {
                                var e = en.pop() || T.expando + "_" + Dt.guid++;
                                return (this[e] = !0), e;
                            },
                        }),
                            T.ajaxPrefilter("json jsonp", function (e, t, n) {
                                var o,
                                    i,
                                    a,
                                    s =
                                        !1 !== e.jsonp &&
                                        (tn.test(e.url)
                                            ? "url"
                                            : "string" == typeof e.data &&
                                              0 ===
                                                  (e.contentType || "").indexOf(
                                                      "application/x-www-form-urlencoded"
                                                  ) &&
                                              tn.test(e.data) &&
                                              "data");
                                if (s || "jsonp" === e.dataTypes[0])
                                    return (
                                        (o = e.jsonpCallback =
                                            v(e.jsonpCallback)
                                                ? e.jsonpCallback()
                                                : e.jsonpCallback),
                                        s
                                            ? (e[s] = e[s].replace(
                                                  tn,
                                                  "$1" + o
                                              ))
                                            : !1 !== e.jsonp &&
                                              (e.url +=
                                                  (Pt.test(e.url) ? "&" : "?") +
                                                  e.jsonp +
                                                  "=" +
                                                  o),
                                        (e.converters["script json"] =
                                            function () {
                                                return (
                                                    a ||
                                                        T.error(
                                                            o +
                                                                " was not called"
                                                        ),
                                                    a[0]
                                                );
                                            }),
                                        (e.dataTypes[0] = "json"),
                                        (i = r[o]),
                                        (r[o] = function () {
                                            a = arguments;
                                        }),
                                        n.always(function () {
                                            void 0 === i
                                                ? T(r).removeProp(o)
                                                : (r[o] = i),
                                                e[o] &&
                                                    ((e.jsonpCallback =
                                                        t.jsonpCallback),
                                                    en.push(o)),
                                                a && v(i) && i(a[0]),
                                                (a = i = void 0);
                                        }),
                                        "script"
                                    );
                            }),
                            (g.createHTMLDocument =
                                (((Zt =
                                    b.implementation.createHTMLDocument(
                                        ""
                                    ).body).innerHTML =
                                    "<form></form><form></form>"),
                                2 === Zt.childNodes.length)),
                            (T.parseHTML = function (e, t, n) {
                                return "string" != typeof e
                                    ? []
                                    : ("boolean" == typeof t &&
                                          ((n = t), (t = !1)),
                                      t ||
                                          (g.createHTMLDocument
                                              ? (((r = (t =
                                                    b.implementation.createHTMLDocument(
                                                        ""
                                                    )).createElement(
                                                    "base"
                                                )).href = b.location.href),
                                                t.head.appendChild(r))
                                              : (t = b)),
                                      (i = !n && []),
                                      (o = I.exec(e))
                                          ? [t.createElement(o[1])]
                                          : ((o = Ne([e], t, i)),
                                            i && i.length && T(i).remove(),
                                            T.merge([], o.childNodes)));
                                var r, o, i;
                            }),
                            (T.fn.load = function (e, t, n) {
                                var r,
                                    o,
                                    i,
                                    a = this,
                                    s = e.indexOf(" ");
                                return (
                                    s > -1 &&
                                        ((r = Ct(e.slice(s))),
                                        (e = e.slice(0, s))),
                                    v(t)
                                        ? ((n = t), (t = void 0))
                                        : t &&
                                          "object" == typeof t &&
                                          (o = "POST"),
                                    a.length > 0 &&
                                        T.ajax({
                                            url: e,
                                            type: o || "GET",
                                            dataType: "html",
                                            data: t,
                                        })
                                            .done(function (e) {
                                                (i = arguments),
                                                    a.html(
                                                        r
                                                            ? T("<div>")
                                                                  .append(
                                                                      T.parseHTML(
                                                                          e
                                                                      )
                                                                  )
                                                                  .find(r)
                                                            : e
                                                    );
                                            })
                                            .always(
                                                n &&
                                                    function (e, t) {
                                                        a.each(function () {
                                                            n.apply(
                                                                this,
                                                                i || [
                                                                    e.responseText,
                                                                    t,
                                                                    e,
                                                                ]
                                                            );
                                                        });
                                                    }
                                            ),
                                    this
                                );
                            }),
                            (T.expr.pseudos.animated = function (e) {
                                return T.grep(T.timers, function (t) {
                                    return e === t.elem;
                                }).length;
                            }),
                            (T.offset = {
                                setOffset: function (e, t, n) {
                                    var r,
                                        o,
                                        i,
                                        a,
                                        s,
                                        c,
                                        u = T.css(e, "position"),
                                        l = T(e),
                                        d = {};
                                    "static" === u &&
                                        (e.style.position = "relative"),
                                        (s = l.offset()),
                                        (i = T.css(e, "top")),
                                        (c = T.css(e, "left")),
                                        ("absolute" === u || "fixed" === u) &&
                                        (i + c).indexOf("auto") > -1
                                            ? ((a = (r = l.position()).top),
                                              (o = r.left))
                                            : ((a = parseFloat(i) || 0),
                                              (o = parseFloat(c) || 0)),
                                        v(t) &&
                                            (t = t.call(e, n, T.extend({}, s))),
                                        null != t.top &&
                                            (d.top = t.top - s.top + a),
                                        null != t.left &&
                                            (d.left = t.left - s.left + o),
                                        "using" in t
                                            ? t.using.call(e, d)
                                            : l.css(d);
                                },
                            }),
                            T.fn.extend({
                                offset: function (e) {
                                    if (arguments.length)
                                        return void 0 === e
                                            ? this
                                            : this.each(function (t) {
                                                  T.offset.setOffset(
                                                      this,
                                                      e,
                                                      t
                                                  );
                                              });
                                    var t,
                                        n,
                                        r = this[0];
                                    return r
                                        ? r.getClientRects().length
                                            ? ((t = r.getBoundingClientRect()),
                                              (n = r.ownerDocument.defaultView),
                                              {
                                                  top: t.top + n.pageYOffset,
                                                  left: t.left + n.pageXOffset,
                                              })
                                            : { top: 0, left: 0 }
                                        : void 0;
                                },
                                position: function () {
                                    if (this[0]) {
                                        var e,
                                            t,
                                            n,
                                            r = this[0],
                                            o = { top: 0, left: 0 };
                                        if ("fixed" === T.css(r, "position"))
                                            t = r.getBoundingClientRect();
                                        else {
                                            for (
                                                t = this.offset(),
                                                    n = r.ownerDocument,
                                                    e =
                                                        r.offsetParent ||
                                                        n.documentElement;
                                                e &&
                                                (e === n.body ||
                                                    e === n.documentElement) &&
                                                "static" ===
                                                    T.css(e, "position");

                                            )
                                                e = e.parentNode;
                                            e &&
                                                e !== r &&
                                                1 === e.nodeType &&
                                                (((o = T(e).offset()).top +=
                                                    T.css(
                                                        e,
                                                        "borderTopWidth",
                                                        !0
                                                    )),
                                                (o.left += T.css(
                                                    e,
                                                    "borderLeftWidth",
                                                    !0
                                                )));
                                        }
                                        return {
                                            top:
                                                t.top -
                                                o.top -
                                                T.css(r, "marginTop", !0),
                                            left:
                                                t.left -
                                                o.left -
                                                T.css(r, "marginLeft", !0),
                                        };
                                    }
                                },
                                offsetParent: function () {
                                    return this.map(function () {
                                        for (
                                            var e = this.offsetParent;
                                            e &&
                                            "static" === T.css(e, "position");

                                        )
                                            e = e.offsetParent;
                                        return e || me;
                                    });
                                },
                            }),
                            T.each(
                                {
                                    scrollLeft: "pageXOffset",
                                    scrollTop: "pageYOffset",
                                },
                                function (e, t) {
                                    var n = "pageYOffset" === t;
                                    T.fn[e] = function (r) {
                                        return ee(
                                            this,
                                            function (e, r, o) {
                                                var i;
                                                if (
                                                    (y(e)
                                                        ? (i = e)
                                                        : 9 === e.nodeType &&
                                                          (i = e.defaultView),
                                                    void 0 === o)
                                                )
                                                    return i ? i[t] : e[r];
                                                i
                                                    ? i.scrollTo(
                                                          n ? i.pageXOffset : o,
                                                          n ? o : i.pageYOffset
                                                      )
                                                    : (e[r] = o);
                                            },
                                            e,
                                            r,
                                            arguments.length
                                        );
                                    };
                                }
                            ),
                            T.each(["top", "left"], function (e, t) {
                                T.cssHooks[t] = Ze(
                                    g.pixelPosition,
                                    function (e, n) {
                                        if (n)
                                            return (
                                                (n = Ke(e, t)),
                                                Xe.test(n)
                                                    ? T(e).position()[t] + "px"
                                                    : n
                                            );
                                    }
                                );
                            }),
                            T.each(
                                { Height: "height", Width: "width" },
                                function (e, t) {
                                    T.each(
                                        {
                                            padding: "inner" + e,
                                            content: t,
                                            "": "outer" + e,
                                        },
                                        function (n, r) {
                                            T.fn[r] = function (o, i) {
                                                var a =
                                                        arguments.length &&
                                                        (n ||
                                                            "boolean" !=
                                                                typeof o),
                                                    s =
                                                        n ||
                                                        (!0 === o || !0 === i
                                                            ? "margin"
                                                            : "border");
                                                return ee(
                                                    this,
                                                    function (t, n, o) {
                                                        var i;
                                                        return y(t)
                                                            ? 0 ===
                                                              r.indexOf("outer")
                                                                ? t["inner" + e]
                                                                : t.document
                                                                      .documentElement[
                                                                      "client" +
                                                                          e
                                                                  ]
                                                            : 9 === t.nodeType
                                                            ? ((i =
                                                                  t.documentElement),
                                                              Math.max(
                                                                  t.body[
                                                                      "scroll" +
                                                                          e
                                                                  ],
                                                                  i[
                                                                      "scroll" +
                                                                          e
                                                                  ],
                                                                  t.body[
                                                                      "offset" +
                                                                          e
                                                                  ],
                                                                  i[
                                                                      "offset" +
                                                                          e
                                                                  ],
                                                                  i[
                                                                      "client" +
                                                                          e
                                                                  ]
                                                              ))
                                                            : void 0 === o
                                                            ? T.css(t, n, s)
                                                            : T.style(
                                                                  t,
                                                                  n,
                                                                  o,
                                                                  s
                                                              );
                                                    },
                                                    t,
                                                    a ? o : void 0,
                                                    a
                                                );
                                            };
                                        }
                                    );
                                }
                            ),
                            T.each(
                                [
                                    "ajaxStart",
                                    "ajaxStop",
                                    "ajaxComplete",
                                    "ajaxError",
                                    "ajaxSuccess",
                                    "ajaxSend",
                                ],
                                function (e, t) {
                                    T.fn[t] = function (e) {
                                        return this.on(t, e);
                                    };
                                }
                            ),
                            T.fn.extend({
                                bind: function (e, t, n) {
                                    return this.on(e, null, t, n);
                                },
                                unbind: function (e, t) {
                                    return this.off(e, null, t);
                                },
                                delegate: function (e, t, n, r) {
                                    return this.on(t, e, n, r);
                                },
                                undelegate: function (e, t, n) {
                                    return 1 === arguments.length
                                        ? this.off(e, "**")
                                        : this.off(t, e || "**", n);
                                },
                                hover: function (e, t) {
                                    return this.on("mouseenter", e).on(
                                        "mouseleave",
                                        t || e
                                    );
                                },
                            }),
                            T.each(
                                "blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(
                                    " "
                                ),
                                function (e, t) {
                                    T.fn[t] = function (e, n) {
                                        return arguments.length > 0
                                            ? this.on(t, null, e, n)
                                            : this.trigger(t);
                                    };
                                }
                            );
                        var nn =
                            /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;
                        (T.proxy = function (e, t) {
                            var n, r, o;
                            if (
                                ("string" == typeof t &&
                                    ((n = e[t]), (t = e), (e = n)),
                                v(e))
                            )
                                return (
                                    (r = s.call(arguments, 2)),
                                    (o = function () {
                                        return e.apply(
                                            t || this,
                                            r.concat(s.call(arguments))
                                        );
                                    }),
                                    (o.guid = e.guid = e.guid || T.guid++),
                                    o
                                );
                        }),
                            (T.holdReady = function (e) {
                                e ? T.readyWait++ : T.ready(!0);
                            }),
                            (T.isArray = Array.isArray),
                            (T.parseJSON = JSON.parse),
                            (T.nodeName = A),
                            (T.isFunction = v),
                            (T.isWindow = y),
                            (T.camelCase = oe),
                            (T.type = j),
                            (T.now = Date.now),
                            (T.isNumeric = function (e) {
                                var t = T.type(e);
                                return (
                                    ("number" === t || "string" === t) &&
                                    !isNaN(e - parseFloat(e))
                                );
                            }),
                            (T.trim = function (e) {
                                return null == e
                                    ? ""
                                    : (e + "").replace(nn, "$1");
                            }),
                            void 0 ===
                                (n = function () {
                                    return T;
                                }.apply(t, [])) || (e.exports = n);
                        var rn = r.jQuery,
                            on = r.$;
                        return (
                            (T.noConflict = function (e) {
                                return (
                                    r.$ === T && (r.$ = on),
                                    e && r.jQuery === T && (r.jQuery = rn),
                                    T
                                );
                            }),
                            void 0 === o && (r.jQuery = r.$ = T),
                            T
                        );
                    }
                );
            },
            98: (e, t, n) => {
                var r, o;
                /*!
                 * jQuery Migrate - v3.5.2 - 2024-07-17T22:31Z
                 * Copyright OpenJS Foundation and other contributors
                 */ !(function () {
                    "use strict";
                    (r = [n(263)]),
                        (o = function (e) {
                            return (function (e, t) {
                                function n(e, t) {
                                    var n,
                                        r = /^(\d+)\.(\d+)\.(\d+)/,
                                        o = r.exec(e) || [],
                                        i = r.exec(t) || [];
                                    for (n = 1; n <= 3; n++) {
                                        if (+o[n] > +i[n]) return 1;
                                        if (+o[n] < +i[n]) return -1;
                                    }
                                    return 0;
                                }
                                function r(t) {
                                    return n(e.fn.jquery, t) >= 0;
                                }
                                e.migrateVersion = "3.5.2";
                                var o = Object.create(null);
                                (e.migrateDisablePatches = function () {
                                    var e;
                                    for (e = 0; e < arguments.length; e++)
                                        o[arguments[e]] = !0;
                                }),
                                    (e.migrateEnablePatches = function () {
                                        var e;
                                        for (e = 0; e < arguments.length; e++)
                                            delete o[arguments[e]];
                                    }),
                                    (e.migrateIsPatchEnabled = function (e) {
                                        return !o[e];
                                    }),
                                    t.console &&
                                        t.console.log &&
                                        ((e && r("3.0.0") && !r("5.0.0")) ||
                                            t.console.log(
                                                "JQMIGRATE: jQuery 3.x-4.x REQUIRED"
                                            ),
                                        e.migrateWarnings &&
                                            t.console.log(
                                                "JQMIGRATE: Migrate plugin loaded multiple times"
                                            ),
                                        t.console.log(
                                            "JQMIGRATE: Migrate is installed" +
                                                (e.migrateMute
                                                    ? ""
                                                    : " with logging active") +
                                                ", version " +
                                                e.migrateVersion
                                        ));
                                var i = {};
                                (e.migrateDeduplicateWarnings = !0),
                                    (e.migrateWarnings = []),
                                    void 0 === e.migrateTrace &&
                                        (e.migrateTrace = !0);
                                function a(n, r) {
                                    var o = t.console;
                                    !e.migrateIsPatchEnabled(n) ||
                                        (e.migrateDeduplicateWarnings &&
                                            i[r]) ||
                                        ((i[r] = !0),
                                        e.migrateWarnings.push(
                                            r + " [" + n + "]"
                                        ),
                                        o &&
                                            o.warn &&
                                            !e.migrateMute &&
                                            (o.warn("JQMIGRATE: " + r),
                                            e.migrateTrace &&
                                                o.trace &&
                                                o.trace()));
                                }
                                function s(e, t, n, r, o) {
                                    Object.defineProperty(e, t, {
                                        configurable: !0,
                                        enumerable: !0,
                                        get: function () {
                                            return a(r, o), n;
                                        },
                                        set: function (e) {
                                            a(r, o), (n = e);
                                        },
                                    });
                                }
                                function c(t, n, r, o, i) {
                                    var s = t[n];
                                    t[n] = function () {
                                        return (
                                            i && a(o, i),
                                            (e.migrateIsPatchEnabled(o)
                                                ? r
                                                : s || e.noop
                                            ).apply(this, arguments)
                                        );
                                    };
                                }
                                function u(e, t, n, r, o) {
                                    if (!o)
                                        throw new Error(
                                            "No warning message provided"
                                        );
                                    return c(e, t, n, r, o);
                                }
                                function l(e, t, n, r) {
                                    return c(e, t, n, r);
                                }
                                (e.migrateReset = function () {
                                    (i = {}), (e.migrateWarnings.length = 0);
                                }),
                                    "BackCompat" === t.document.compatMode &&
                                        a(
                                            "quirks",
                                            "jQuery is not compatible with Quirks Mode"
                                        );
                                var d,
                                    p = {},
                                    f = e.fn.init,
                                    h = e.find,
                                    m =
                                        /\[(\s*[-\w]+\s*)([~|^$*]?=)\s*([-\w#]*?#[-\w#]*)\s*\]/,
                                    g =
                                        /\[(\s*[-\w]+\s*)([~|^$*]?=)\s*([-\w#]*?#[-\w#]*)\s*\]/g,
                                    v =
                                        /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;
                                for (d in (l(
                                    e.fn,
                                    "init",
                                    function (t) {
                                        var n =
                                            Array.prototype.slice.call(
                                                arguments
                                            );
                                        return (
                                            e.migrateIsPatchEnabled(
                                                "selector-empty-id"
                                            ) &&
                                                "string" == typeof t &&
                                                "#" === t &&
                                                (a(
                                                    "selector-empty-id",
                                                    "jQuery( '#' ) is not a valid selector"
                                                ),
                                                (n[0] = [])),
                                            f.apply(this, n)
                                        );
                                    },
                                    "selector-empty-id"
                                ),
                                (e.fn.init.prototype = e.fn),
                                l(
                                    e,
                                    "find",
                                    function (e) {
                                        var n =
                                            Array.prototype.slice.call(
                                                arguments
                                            );
                                        if ("string" == typeof e && m.test(e))
                                            try {
                                                t.document.querySelector(e);
                                            } catch (r) {
                                                e = e.replace(
                                                    g,
                                                    function (e, t, n, r) {
                                                        return (
                                                            "[" +
                                                            t +
                                                            n +
                                                            '"' +
                                                            r +
                                                            '"]'
                                                        );
                                                    }
                                                );
                                                try {
                                                    t.document.querySelector(e),
                                                        a(
                                                            "selector-hash",
                                                            "Attribute selector with '#' must be quoted: " +
                                                                n[0]
                                                        ),
                                                        (n[0] = e);
                                                } catch (e) {
                                                    a(
                                                        "selector-hash",
                                                        "Attribute selector with '#' was not fixed: " +
                                                            n[0]
                                                    );
                                                }
                                            }
                                        return h.apply(this, n);
                                    },
                                    "selector-hash"
                                ),
                                h))
                                    Object.prototype.hasOwnProperty.call(
                                        h,
                                        d
                                    ) && (e.find[d] = h[d]);
                                u(
                                    e.fn,
                                    "size",
                                    function () {
                                        return this.length;
                                    },
                                    "size",
                                    "jQuery.fn.size() is deprecated and removed; use the .length property"
                                ),
                                    u(
                                        e,
                                        "parseJSON",
                                        function () {
                                            return JSON.parse.apply(
                                                null,
                                                arguments
                                            );
                                        },
                                        "parseJSON",
                                        "jQuery.parseJSON is deprecated; use JSON.parse"
                                    ),
                                    u(
                                        e,
                                        "holdReady",
                                        e.holdReady,
                                        "holdReady",
                                        "jQuery.holdReady is deprecated"
                                    ),
                                    u(
                                        e,
                                        "unique",
                                        e.uniqueSort,
                                        "unique",
                                        "jQuery.unique is deprecated; use jQuery.uniqueSort"
                                    ),
                                    s(
                                        e.expr,
                                        "filters",
                                        e.expr.pseudos,
                                        "expr-pre-pseudos",
                                        "jQuery.expr.filters is deprecated; use jQuery.expr.pseudos"
                                    ),
                                    s(
                                        e.expr,
                                        ":",
                                        e.expr.pseudos,
                                        "expr-pre-pseudos",
                                        "jQuery.expr[':'] is deprecated; use jQuery.expr.pseudos"
                                    ),
                                    r("3.1.1") &&
                                        u(
                                            e,
                                            "trim",
                                            function (e) {
                                                return null == e
                                                    ? ""
                                                    : (e + "").replace(v, "$1");
                                            },
                                            "trim",
                                            "jQuery.trim is deprecated; use String.prototype.trim"
                                        );
                                r("3.2.0") &&
                                    (u(
                                        e,
                                        "nodeName",
                                        function (e, t) {
                                            return (
                                                e.nodeName &&
                                                e.nodeName.toLowerCase() ===
                                                    t.toLowerCase()
                                            );
                                        },
                                        "nodeName",
                                        "jQuery.nodeName is deprecated"
                                    ),
                                    u(
                                        e,
                                        "isArray",
                                        Array.isArray,
                                        "isArray",
                                        "jQuery.isArray is deprecated; use Array.isArray"
                                    ));
                                r("3.3.0") &&
                                    (u(
                                        e,
                                        "isNumeric",
                                        function (e) {
                                            var t = typeof e;
                                            return (
                                                ("number" === t ||
                                                    "string" === t) &&
                                                !isNaN(e - parseFloat(e))
                                            );
                                        },
                                        "isNumeric",
                                        "jQuery.isNumeric() is deprecated"
                                    ),
                                    e.each(
                                        "Boolean Number String Function Array Date RegExp Object Error Symbol".split(
                                            " "
                                        ),
                                        function (e, t) {
                                            p["[object " + t + "]"] =
                                                t.toLowerCase();
                                        }
                                    ),
                                    u(
                                        e,
                                        "type",
                                        function (e) {
                                            return null == e
                                                ? e + ""
                                                : "object" == typeof e ||
                                                  "function" == typeof e
                                                ? p[
                                                      Object.prototype.toString.call(
                                                          e
                                                      )
                                                  ] || "object"
                                                : typeof e;
                                        },
                                        "type",
                                        "jQuery.type is deprecated"
                                    ),
                                    u(
                                        e,
                                        "isFunction",
                                        function (e) {
                                            return "function" == typeof e;
                                        },
                                        "isFunction",
                                        "jQuery.isFunction() is deprecated"
                                    ),
                                    u(
                                        e,
                                        "isWindow",
                                        function (e) {
                                            return null != e && e === e.window;
                                        },
                                        "isWindow",
                                        "jQuery.isWindow() is deprecated"
                                    ));
                                if (e.ajax) {
                                    var y = e.ajax,
                                        b = /(=)\?(?=&|$)|\?\?/;
                                    l(
                                        e,
                                        "ajax",
                                        function () {
                                            var e = y.apply(this, arguments);
                                            return (
                                                e.promise &&
                                                    (u(
                                                        e,
                                                        "success",
                                                        e.done,
                                                        "jqXHR-methods",
                                                        "jQXHR.success is deprecated and removed"
                                                    ),
                                                    u(
                                                        e,
                                                        "error",
                                                        e.fail,
                                                        "jqXHR-methods",
                                                        "jQXHR.error is deprecated and removed"
                                                    ),
                                                    u(
                                                        e,
                                                        "complete",
                                                        e.always,
                                                        "jqXHR-methods",
                                                        "jQXHR.complete is deprecated and removed"
                                                    )),
                                                e
                                            );
                                        },
                                        "jqXHR-methods"
                                    ),
                                        r("4.0.0") ||
                                            e.ajaxPrefilter(
                                                "+json",
                                                function (e) {
                                                    !1 !== e.jsonp &&
                                                        (b.test(e.url) ||
                                                            ("string" ==
                                                                typeof e.data &&
                                                                0 ===
                                                                    (
                                                                        e.contentType ||
                                                                        ""
                                                                    ).indexOf(
                                                                        "application/x-www-form-urlencoded"
                                                                    ) &&
                                                                b.test(
                                                                    e.data
                                                                ))) &&
                                                        a(
                                                            "jsonp-promotion",
                                                            "JSON-to-JSONP auto-promotion is deprecated"
                                                        );
                                                }
                                            );
                                }
                                var x = e.fn.removeAttr,
                                    w = e.fn.toggleClass,
                                    j =
                                        /^(?:checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped)$/i,
                                    k = /\S+/g;
                                function C(e) {
                                    return e.replace(
                                        /-([a-z])/g,
                                        function (e, t) {
                                            return t.toUpperCase();
                                        }
                                    );
                                }
                                l(
                                    e.fn,
                                    "removeAttr",
                                    function (t) {
                                        var n = this,
                                            r = !1;
                                        return (
                                            e.each(t.match(k), function (t, o) {
                                                j.test(o) &&
                                                    n.each(function () {
                                                        if (
                                                            !1 !==
                                                            e(this).prop(o)
                                                        )
                                                            return (r = !0), !1;
                                                    }),
                                                    r &&
                                                        (a(
                                                            "removeAttr-bool",
                                                            "jQuery.fn.removeAttr no longer sets boolean properties: " +
                                                                o
                                                        ),
                                                        n.prop(o, !1));
                                            }),
                                            x.apply(this, arguments)
                                        );
                                    },
                                    "removeAttr-bool"
                                ),
                                    l(
                                        e.fn,
                                        "toggleClass",
                                        function (t) {
                                            return void 0 !== t &&
                                                "boolean" != typeof t
                                                ? w.apply(this, arguments)
                                                : (a(
                                                      "toggleClass-bool",
                                                      "jQuery.fn.toggleClass( boolean ) is deprecated"
                                                  ),
                                                  this.each(function () {
                                                      var n =
                                                          (this.getAttribute &&
                                                              this.getAttribute(
                                                                  "class"
                                                              )) ||
                                                          "";
                                                      n &&
                                                          e.data(
                                                              this,
                                                              "__className__",
                                                              n
                                                          ),
                                                          this.setAttribute &&
                                                              this.setAttribute(
                                                                  "class",
                                                                  n || !1 === t
                                                                      ? ""
                                                                      : e.data(
                                                                            this,
                                                                            "__className__"
                                                                        ) || ""
                                                              );
                                                  }));
                                        },
                                        "toggleClass-bool"
                                    );
                                var T,
                                    S,
                                    A = !1,
                                    E = /^[a-z]/,
                                    D =
                                        /^(?:Border(?:Top|Right|Bottom|Left)?(?:Width|)|(?:Margin|Padding)?(?:Top|Right|Bottom|Left)?|(?:Min|Max)?(?:Width|Height))$/;
                                e.swap &&
                                    e.each(
                                        [
                                            "height",
                                            "width",
                                            "reliableMarginRight",
                                        ],
                                        function (t, n) {
                                            var r =
                                                e.cssHooks[n] &&
                                                e.cssHooks[n].get;
                                            r &&
                                                (e.cssHooks[n].get =
                                                    function () {
                                                        var e;
                                                        return (
                                                            (A = !0),
                                                            (e = r.apply(
                                                                this,
                                                                arguments
                                                            )),
                                                            (A = !1),
                                                            e
                                                        );
                                                    });
                                        }
                                    );
                                l(
                                    e,
                                    "swap",
                                    function (e, t, n, r) {
                                        var o,
                                            i,
                                            s = {};
                                        for (i in (A ||
                                            a(
                                                "swap",
                                                "jQuery.swap() is undocumented and deprecated"
                                            ),
                                        t))
                                            (s[i] = e.style[i]),
                                                (e.style[i] = t[i]);
                                        for (i in ((o = n.apply(e, r || [])),
                                        t))
                                            e.style[i] = s[i];
                                        return o;
                                    },
                                    "swap"
                                ),
                                    r("3.4.0") &&
                                        "undefined" != typeof Proxy &&
                                        (e.cssProps = new Proxy(
                                            e.cssProps || {},
                                            {
                                                set: function () {
                                                    return (
                                                        a(
                                                            "cssProps",
                                                            "jQuery.cssProps is deprecated"
                                                        ),
                                                        Reflect.set.apply(
                                                            this,
                                                            arguments
                                                        )
                                                    );
                                                },
                                            }
                                        ));
                                r("4.0.0")
                                    ? ((S = {
                                          animationIterationCount: !0,
                                          aspectRatio: !0,
                                          borderImageSlice: !0,
                                          columnCount: !0,
                                          flexGrow: !0,
                                          flexShrink: !0,
                                          fontWeight: !0,
                                          gridArea: !0,
                                          gridColumn: !0,
                                          gridColumnEnd: !0,
                                          gridColumnStart: !0,
                                          gridRow: !0,
                                          gridRowEnd: !0,
                                          gridRowStart: !0,
                                          lineHeight: !0,
                                          opacity: !0,
                                          order: !0,
                                          orphans: !0,
                                          scale: !0,
                                          widows: !0,
                                          zIndex: !0,
                                          zoom: !0,
                                          fillOpacity: !0,
                                          floodOpacity: !0,
                                          stopOpacity: !0,
                                          strokeMiterlimit: !0,
                                          strokeOpacity: !0,
                                      }),
                                      "undefined" != typeof Proxy
                                          ? (e.cssNumber = new Proxy(S, {
                                                get: function () {
                                                    return (
                                                        a(
                                                            "css-number",
                                                            "jQuery.cssNumber is deprecated"
                                                        ),
                                                        Reflect.get.apply(
                                                            this,
                                                            arguments
                                                        )
                                                    );
                                                },
                                                set: function () {
                                                    return (
                                                        a(
                                                            "css-number",
                                                            "jQuery.cssNumber is deprecated"
                                                        ),
                                                        Reflect.set.apply(
                                                            this,
                                                            arguments
                                                        )
                                                    );
                                                },
                                            }))
                                          : (e.cssNumber = S))
                                    : (S = e.cssNumber);
                                function P(e) {
                                    return (
                                        E.test(e) &&
                                        D.test(e[0].toUpperCase() + e.slice(1))
                                    );
                                }
                                (T = e.fn.css),
                                    l(
                                        e.fn,
                                        "css",
                                        function (t, n) {
                                            var r,
                                                o = this;
                                            return t &&
                                                "object" == typeof t &&
                                                !Array.isArray(t)
                                                ? (e.each(t, function (t, n) {
                                                      e.fn.css.call(o, t, n);
                                                  }),
                                                  this)
                                                : ("number" == typeof n &&
                                                      (P((r = C(t))) ||
                                                          S[r] ||
                                                          a(
                                                              "css-number",
                                                              'Number-typed values are deprecated for jQuery.fn.css( "' +
                                                                  t +
                                                                  '", value )'
                                                          )),
                                                  T.apply(this, arguments));
                                        },
                                        "css-number"
                                    );
                                var q = e.data;
                                if (
                                    (l(
                                        e,
                                        "data",
                                        function (t, n, r) {
                                            var o, i, s;
                                            if (
                                                n &&
                                                "object" == typeof n &&
                                                2 === arguments.length
                                            ) {
                                                for (s in ((o =
                                                    e.hasData(t) &&
                                                    q.call(this, t)),
                                                (i = {}),
                                                n))
                                                    s !== C(s)
                                                        ? (a(
                                                              "data-camelCase",
                                                              "jQuery.data() always sets/gets camelCased names: " +
                                                                  s
                                                          ),
                                                          (o[s] = n[s]))
                                                        : (i[s] = n[s]);
                                                return q.call(this, t, i), n;
                                            }
                                            return n &&
                                                "string" == typeof n &&
                                                n !== C(n) &&
                                                (o =
                                                    e.hasData(t) &&
                                                    q.call(this, t)) &&
                                                n in o
                                                ? (a(
                                                      "data-camelCase",
                                                      "jQuery.data() always sets/gets camelCased names: " +
                                                          n
                                                  ),
                                                  arguments.length > 2 &&
                                                      (o[n] = r),
                                                  o[n])
                                                : q.apply(this, arguments);
                                        },
                                        "data-camelCase"
                                    ),
                                    e.fx)
                                ) {
                                    var N,
                                        O,
                                        _ = e.Tween.prototype.run,
                                        $ = function (e) {
                                            return e;
                                        };
                                    l(
                                        e.Tween.prototype,
                                        "run",
                                        function () {
                                            e.easing[this.easing].length > 1 &&
                                                (a(
                                                    "easing-one-arg",
                                                    "'jQuery.easing." +
                                                        this.easing.toString() +
                                                        "' should use only one argument"
                                                ),
                                                (e.easing[this.easing] = $)),
                                                _.apply(this, arguments);
                                        },
                                        "easing-one-arg"
                                    ),
                                        (N = e.fx.interval),
                                        (O =
                                            "jQuery.fx.interval is deprecated"),
                                        t.requestAnimationFrame &&
                                            Object.defineProperty(
                                                e.fx,
                                                "interval",
                                                {
                                                    configurable: !0,
                                                    enumerable: !0,
                                                    get: function () {
                                                        return (
                                                            t.document.hidden ||
                                                                a(
                                                                    "fx-interval",
                                                                    O
                                                                ),
                                                            e.migrateIsPatchEnabled(
                                                                "fx-interval"
                                                            ) && void 0 === N
                                                                ? 13
                                                                : N
                                                        );
                                                    },
                                                    set: function (e) {
                                                        a("fx-interval", O),
                                                            (N = e);
                                                    },
                                                }
                                            );
                                }
                                var H = e.fn.load,
                                    L = e.event.add,
                                    R = e.event.fix;
                                (e.event.props = []),
                                    (e.event.fixHooks = {}),
                                    s(
                                        e.event.props,
                                        "concat",
                                        e.event.props.concat,
                                        "event-old-patch",
                                        "jQuery.event.props.concat() is deprecated and removed"
                                    ),
                                    l(
                                        e.event,
                                        "fix",
                                        function (t) {
                                            var n,
                                                r = t.type,
                                                o = this.fixHooks[r],
                                                i = e.event.props;
                                            if (i.length)
                                                for (
                                                    a(
                                                        "event-old-patch",
                                                        "jQuery.event.props are deprecated and removed: " +
                                                            i.join()
                                                    );
                                                    i.length;

                                                )
                                                    e.event.addProp(i.pop());
                                            if (
                                                o &&
                                                !o._migrated_ &&
                                                ((o._migrated_ = !0),
                                                a(
                                                    "event-old-patch",
                                                    "jQuery.event.fixHooks are deprecated and removed: " +
                                                        r
                                                ),
                                                (i = o.props) && i.length)
                                            )
                                                for (; i.length; )
                                                    e.event.addProp(i.pop());
                                            return (
                                                (n = R.call(this, t)),
                                                o && o.filter
                                                    ? o.filter(n, t)
                                                    : n
                                            );
                                        },
                                        "event-old-patch"
                                    ),
                                    l(
                                        e.event,
                                        "add",
                                        function (e, n) {
                                            return (
                                                e === t &&
                                                    "load" === n &&
                                                    "complete" ===
                                                        t.document.readyState &&
                                                    a(
                                                        "load-after-event",
                                                        "jQuery(window).on('load'...) called after load event occurred"
                                                    ),
                                                L.apply(this, arguments)
                                            );
                                        },
                                        "load-after-event"
                                    ),
                                    e.each(
                                        ["load", "unload", "error"],
                                        function (t, n) {
                                            l(
                                                e.fn,
                                                n,
                                                function () {
                                                    var e =
                                                        Array.prototype.slice.call(
                                                            arguments,
                                                            0
                                                        );
                                                    return "load" === n &&
                                                        "string" == typeof e[0]
                                                        ? H.apply(this, e)
                                                        : (a(
                                                              "shorthand-removed-v3",
                                                              "jQuery.fn." +
                                                                  n +
                                                                  "() is deprecated"
                                                          ),
                                                          e.splice(0, 0, n),
                                                          arguments.length
                                                              ? this.on.apply(
                                                                    this,
                                                                    e
                                                                )
                                                              : (this.triggerHandler.apply(
                                                                    this,
                                                                    e
                                                                ),
                                                                this));
                                                },
                                                "shorthand-removed-v3"
                                            );
                                        }
                                    ),
                                    e.each(
                                        "blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(
                                            " "
                                        ),
                                        function (t, n) {
                                            u(
                                                e.fn,
                                                n,
                                                function (e, t) {
                                                    return arguments.length > 0
                                                        ? this.on(n, null, e, t)
                                                        : this.trigger(n);
                                                },
                                                "shorthand-deprecated-v3",
                                                "jQuery.fn." +
                                                    n +
                                                    "() event shorthand is deprecated"
                                            );
                                        }
                                    ),
                                    e(function () {
                                        e(t.document).triggerHandler("ready");
                                    }),
                                    (e.event.special.ready = {
                                        setup: function () {
                                            this === t.document &&
                                                a(
                                                    "ready-event",
                                                    "'ready' event is deprecated"
                                                );
                                        },
                                    }),
                                    u(
                                        e.fn,
                                        "bind",
                                        function (e, t, n) {
                                            return this.on(e, null, t, n);
                                        },
                                        "pre-on-methods",
                                        "jQuery.fn.bind() is deprecated"
                                    ),
                                    u(
                                        e.fn,
                                        "unbind",
                                        function (e, t) {
                                            return this.off(e, null, t);
                                        },
                                        "pre-on-methods",
                                        "jQuery.fn.unbind() is deprecated"
                                    ),
                                    u(
                                        e.fn,
                                        "delegate",
                                        function (e, t, n, r) {
                                            return this.on(t, e, n, r);
                                        },
                                        "pre-on-methods",
                                        "jQuery.fn.delegate() is deprecated"
                                    ),
                                    u(
                                        e.fn,
                                        "undelegate",
                                        function (e, t, n) {
                                            return 1 === arguments.length
                                                ? this.off(e, "**")
                                                : this.off(t, e || "**", n);
                                        },
                                        "pre-on-methods",
                                        "jQuery.fn.undelegate() is deprecated"
                                    ),
                                    u(
                                        e.fn,
                                        "hover",
                                        function (e, t) {
                                            return this.on("mouseenter", e).on(
                                                "mouseleave",
                                                t || e
                                            );
                                        },
                                        "pre-on-methods",
                                        "jQuery.fn.hover() is deprecated"
                                    );
                                var M =
                                        /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
                                    I = function (e) {
                                        var n =
                                            t.document.implementation.createHTMLDocument(
                                                ""
                                            );
                                        return (
                                            (n.body.innerHTML = e),
                                            n.body && n.body.innerHTML
                                        );
                                    },
                                    W = function (e) {
                                        var t = e.replace(M, "<$1></$2>");
                                        t !== e &&
                                            I(e) !== I(t) &&
                                            a(
                                                "self-closed-tags",
                                                "HTML tags must be properly nested and closed: " +
                                                    e
                                            );
                                    };
                                u(
                                    e,
                                    "UNSAFE_restoreLegacyHtmlPrefilter",
                                    function () {
                                        e.migrateEnablePatches(
                                            "self-closed-tags"
                                        );
                                    },
                                    "legacy-self-closed-tags",
                                    'jQuery.UNSAFE_restoreLegacyHtmlPrefilter deprecated; use `jQuery.migrateEnablePatches( "self-closed-tags" )`'
                                ),
                                    l(
                                        e,
                                        "htmlPrefilter",
                                        function (e) {
                                            return (
                                                W(e), e.replace(M, "<$1></$2>")
                                            );
                                        },
                                        "self-closed-tags"
                                    ),
                                    e.migrateDisablePatches("self-closed-tags");
                                var F = e.fn.offset;
                                if (
                                    (l(
                                        e.fn,
                                        "offset",
                                        function () {
                                            var e = this[0];
                                            return !e ||
                                                (e.nodeType &&
                                                    e.getBoundingClientRect)
                                                ? F.apply(this, arguments)
                                                : (a(
                                                      "offset-valid-elem",
                                                      "jQuery.fn.offset() requires a valid DOM element"
                                                  ),
                                                  arguments.length
                                                      ? this
                                                      : void 0);
                                        },
                                        "offset-valid-elem"
                                    ),
                                    e.ajax)
                                ) {
                                    var Q = e.param;
                                    l(
                                        e,
                                        "param",
                                        function (t, n) {
                                            var r =
                                                e.ajaxSettings &&
                                                e.ajaxSettings.traditional;
                                            return (
                                                void 0 === n &&
                                                    r &&
                                                    (a(
                                                        "param-ajax-traditional",
                                                        "jQuery.param() no longer uses jQuery.ajaxSettings.traditional"
                                                    ),
                                                    (n = r)),
                                                Q.call(this, t, n)
                                            );
                                        },
                                        "param-ajax-traditional"
                                    );
                                }
                                if (
                                    (u(
                                        e.fn,
                                        "andSelf",
                                        e.fn.addBack,
                                        "andSelf",
                                        "jQuery.fn.andSelf() is deprecated and removed, use jQuery.fn.addBack()"
                                    ),
                                    e.Deferred)
                                ) {
                                    var B = e.Deferred,
                                        z = [
                                            [
                                                "resolve",
                                                "done",
                                                e.Callbacks("once memory"),
                                                e.Callbacks("once memory"),
                                                "resolved",
                                            ],
                                            [
                                                "reject",
                                                "fail",
                                                e.Callbacks("once memory"),
                                                e.Callbacks("once memory"),
                                                "rejected",
                                            ],
                                            [
                                                "notify",
                                                "progress",
                                                e.Callbacks("memory"),
                                                e.Callbacks("memory"),
                                            ],
                                        ];
                                    l(
                                        e,
                                        "Deferred",
                                        function (t) {
                                            var n = B(),
                                                r = n.promise();
                                            function o() {
                                                var t = arguments;
                                                return e
                                                    .Deferred(function (o) {
                                                        e.each(
                                                            z,
                                                            function (e, i) {
                                                                var a =
                                                                    "function" ==
                                                                        typeof t[
                                                                            e
                                                                        ] &&
                                                                    t[e];
                                                                n[i[1]](
                                                                    function () {
                                                                        var e =
                                                                            a &&
                                                                            a.apply(
                                                                                this,
                                                                                arguments
                                                                            );
                                                                        e &&
                                                                        "function" ==
                                                                            typeof e.promise
                                                                            ? e
                                                                                  .promise()
                                                                                  .done(
                                                                                      o.resolve
                                                                                  )
                                                                                  .fail(
                                                                                      o.reject
                                                                                  )
                                                                                  .progress(
                                                                                      o.notify
                                                                                  )
                                                                            : o[
                                                                                  i[0] +
                                                                                      "With"
                                                                              ](
                                                                                  this ===
                                                                                      r
                                                                                      ? o.promise()
                                                                                      : this,
                                                                                  a
                                                                                      ? [
                                                                                            e,
                                                                                        ]
                                                                                      : arguments
                                                                              );
                                                                    }
                                                                );
                                                            }
                                                        ),
                                                            (t = null);
                                                    })
                                                    .promise();
                                            }
                                            return (
                                                u(
                                                    n,
                                                    "pipe",
                                                    o,
                                                    "deferred-pipe",
                                                    "deferred.pipe() is deprecated"
                                                ),
                                                u(
                                                    r,
                                                    "pipe",
                                                    o,
                                                    "deferred-pipe",
                                                    "deferred.pipe() is deprecated"
                                                ),
                                                t && t.call(n, n),
                                                n
                                            );
                                        },
                                        "deferred-pipe"
                                    ),
                                        (e.Deferred.exceptionHook =
                                            B.exceptionHook);
                                }
                                return e;
                            })(e, window);
                        }.apply(t, r)),
                        void 0 === o || (e.exports = o);
                })();
            },
        },
        i = {};
    function a(e) {
        var t = i[e];
        if (void 0 !== t) return t.exports;
        var n = (i[e] = { exports: {} });
        return o[e].call(n.exports, n, n.exports, a), n.exports;
    }
    (a.m = o),
        (a.n = (e) => {
            var t = e && e.__esModule ? () => e.default : () => e;
            return a.d(t, { a: t }), t;
        }),
        (t = Object.getPrototypeOf
            ? (e) => Object.getPrototypeOf(e)
            : (e) => e.__proto__),
        (a.t = function (n, r) {
            if ((1 & r && (n = this(n)), 8 & r)) return n;
            if ("object" == typeof n && n) {
                if (4 & r && n.__esModule) return n;
                if (16 & r && "function" == typeof n.then) return n;
            }
            var o = Object.create(null);
            a.r(o);
            var i = {};
            e = e || [null, t({}), t([]), t(t)];
            for (
                var s = 2 & r && n;
                "object" == typeof s && !~e.indexOf(s);
                s = t(s)
            )
                Object.getOwnPropertyNames(s).forEach(
                    (e) => (i[e] = () => n[e])
                );
            return (i.default = () => n), a.d(o, i), o;
        }),
        (a.d = (e, t) => {
            for (var n in t)
                a.o(t, n) &&
                    !a.o(e, n) &&
                    Object.defineProperty(e, n, { enumerable: !0, get: t[n] });
        }),
        (a.f = {}),
        (a.e = (e) =>
            Promise.all(
                Object.keys(a.f).reduce((t, n) => (a.f[n](e, t), t), [])
            )),
        (a.u = (e) => "dc82bd4db44878dbda1b-chunk.js"),
        (a.g = (function () {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")();
            } catch (e) {
                if ("object" == typeof window) return window;
            }
        })()),
        (a.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
        (n = {}),
        (r = "prestashop-core-theme-js:"),
        (a.l = (e, t, o, i) => {
            if (n[e]) n[e].push(t);
            else {
                var s, c;
                if (void 0 !== o)
                    for (
                        var u = document.getElementsByTagName("script"), l = 0;
                        l < u.length;
                        l++
                    ) {
                        var d = u[l];
                        if (
                            d.getAttribute("src") == e ||
                            d.getAttribute("data-webpack") == r + o
                        ) {
                            s = d;
                            break;
                        }
                    }
                s ||
                    ((c = !0),
                    ((s = document.createElement("script")).charset = "utf-8"),
                    (s.timeout = 120),
                    a.nc && s.setAttribute("nonce", a.nc),
                    s.setAttribute("data-webpack", r + o),
                    (s.src = e)),
                    (n[e] = [t]);
                var p = (t, r) => {
                        (s.onerror = s.onload = null), clearTimeout(f);
                        var o = n[e];
                        if (
                            (delete n[e],
                            s.parentNode && s.parentNode.removeChild(s),
                            o && o.forEach((e) => e(r)),
                            t)
                        )
                            return t(r);
                    },
                    f = setTimeout(
                        p.bind(null, void 0, { type: "timeout", target: s }),
                        12e4
                    );
                (s.onerror = p.bind(null, s.onerror)),
                    (s.onload = p.bind(null, s.onload)),
                    c && document.head.appendChild(s);
            }
        }),
        (a.r = (e) => {
            "undefined" != typeof Symbol &&
                Symbol.toStringTag &&
                Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module",
                }),
                Object.defineProperty(e, "__esModule", { value: !0 });
        }),
        (() => {
            var e;
            a.g.importScripts && (e = a.g.location + "");
            var t = a.g.document;
            if (
                !e &&
                t &&
                (t.currentScript &&
                    "SCRIPT" === t.currentScript.tagName.toUpperCase() &&
                    (e = t.currentScript.src),
                !e)
            ) {
                var n = t.getElementsByTagName("script");
                if (n.length)
                    for (
                        var r = n.length - 1;
                        r > -1 && (!e || !/^http(s?):/.test(e));

                    )
                        e = n[r--].src;
            }
            if (!e)
                throw new Error(
                    "Automatic publicPath is not supported in this browser"
                );
            (e = e
                .replace(/#.*$/, "")
                .replace(/\?.*$/, "")
                .replace(/\/[^\/]+$/, "/")),
                (a.p = e);
        })(),
        (() => {
            var e = { 792: 0 };
            a.f.j = (t, n) => {
                var r = a.o(e, t) ? e[t] : void 0;
                if (0 !== r)
                    if (r) n.push(r[2]);
                    else {
                        var o = new Promise((n, o) => (r = e[t] = [n, o]));
                        n.push((r[2] = o));
                        var i = a.p + a.u(t),
                            s = new Error();
                        a.l(
                            i,
                            (n) => {
                                if (
                                    a.o(e, t) &&
                                    (0 !== (r = e[t]) && (e[t] = void 0), r)
                                ) {
                                    var o =
                                            n &&
                                            ("load" === n.type
                                                ? "missing"
                                                : n.type),
                                        i = n && n.target && n.target.src;
                                    (s.message =
                                        "Loading chunk " +
                                        t +
                                        " failed.\n(" +
                                        o +
                                        ": " +
                                        i +
                                        ")"),
                                        (s.name = "ChunkLoadError"),
                                        (s.type = o),
                                        (s.request = i),
                                        r[1](s);
                                }
                            },
                            "chunk-" + t,
                            t
                        );
                    }
            };
            var t = (t, n) => {
                    var r,
                        o,
                        [i, s, c] = n,
                        u = 0;
                    if (i.some((t) => 0 !== e[t])) {
                        for (r in s) a.o(s, r) && (a.m[r] = s[r]);
                        if (c) c(a);
                    }
                    for (t && t(n); u < i.length; u++)
                        (o = i[u]), a.o(e, o) && e[o] && e[o][0](), (e[o] = 0);
                },
                n = (self.webpackChunkprestashop_core_theme_js =
                    self.webpackChunkprestashop_core_theme_js || []);
            n.forEach(t.bind(null, 0)), (n.push = t.bind(null, n.push.bind(n)));
        })(),
        (() => {
            "use strict";
            var e = a(263),
                t = a.n(e);
            void 0 === t().migrateMute &&
                (t().migrateMute = !window.prestashop.debug);
            a(98);
            const n = prestashop;
            var r = a.n(n);
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            (r().selectors = {
                quantityWanted: "#quantity_wanted",
                product: {
                    imageContainer:
                        ".quickview .images-container, .page-product:not(.modal-open) .row .images-container, .page-product:not(.modal-open) .product-container .images-container, .quickview .js-images-container, .page-product:not(.modal-open) .row .js-images-container, .page-product:not(.modal-open) .product-container .js-images-container",
                    container: ".product-container, .js-product-container",
                    availability:
                        "#product-availability, .js-product-availability",
                    actions: ".product-actions, .js-product-actions",
                    variants: ".product-variants, .js-product-variants",
                    refresh: ".product-refresh, .js-product-refresh",
                    miniature: ".js-product-miniature",
                    minimalQuantity:
                        ".product-minimal-quantity, .js-product-minimal-quantity",
                    addToCart:
                        ".quickview .product-add-to-cart, .page-product:not(.modal-open) .row .product-add-to-cart, .page-product:not(.modal-open) .product-container .product-add-to-cart, .quickview .js-product-add-to-cart, .page-product:not(.modal-open) .row .js-product-add-to-cart, .page-product:not(.modal-open) .product-container .js-product-add-to-cart",
                    prices: ".quickview .product-prices, .page-product:not(.modal-open) .row .product-prices, .page-product:not(.modal-open) .product-container .product-prices, .quickview .js-product-prices, .page-product:not(.modal-open) .row .js-product-prices, .page-product:not(.modal-open) .product-container .js-product-prices",
                    inputCustomization:
                        '.product-actions input[name="id_customization"], .js-product-actions .js-product-customization-id',
                    customization:
                        ".quickview .product-customization, .page-product:not(.modal-open) .row .product-customization, .page-product:not(.modal-open) .product-container .product-customization, .quickview .js-product-customization, .page-product:not(.modal-open) .row .js-product-customization, .page-product:not(.modal-open) .product-container .js-product-customization",
                    variantsUpdate:
                        ".quickview .product-variants, .page-product:not(.modal-open) .row .product-variants, .page-product:not(.modal-open) .product-container .product-variants, .quickview .js-product-variants, .page-product:not(.modal-open) .row .js-product-variants, .page-product:not(.modal-open) .js-product-container .js-product-variants",
                    discounts:
                        ".quickview .product-discounts, .page-product:not(.modal-open) .row .product-discounts, .page-product:not(.modal-open) .product-container .product-discounts, .quickview .js-product-discounts, .page-product:not(.modal-open) .row .js-product-discounts, .page-product:not(.modal-open) .product-container .js-product-discounts",
                    additionalInfos:
                        ".quickview .product-additional-info, .page-product:not(.modal-open) .row .product-additional-info, .page-product:not(.modal-open) .product-container .product-additional-info, .quickview .js-product-additional-info, .page-product:not(.modal-open) .row .js-product-additional-info, .page-product:not(.modal-open) .js-product-container .js-product-additional-info",
                    details:
                        ".quickview #product-details, #product-details, .quickview .js-product-details, .js-product-details",
                    flags: ".quickview .product-flags, .page-product:not(.modal-open) .row .product-flags, .page-product:not(.modal-open) .product-container .product-flags, .quickview .js-product-flags, .page-product:not(.modal-open) .row .js-product-flags, .page-product:not(.modal-open) .js-product-container .js-product-flags",
                },
                listing: { quickview: ".quick-view, .js-quick-view" },
                checkout: {
                    form: ".checkout-step form",
                    currentStep: "js-current-step",
                    step: ".checkout-step",
                    stepTitle: ".step-title, .js-step-title",
                    confirmationSelector:
                        "#payment-confirmation button, .js-payment-confirmation",
                    conditionsSelector:
                        '#conditions-to-approve input[type="checkbox"], .js-conditions-to-approve',
                    conditionAlertSelector: ".js-alert-payment-conditions",
                    additionalInformatonSelector: ".js-additional-information",
                    optionsForm: ".js-payment-option-form",
                    termsCheckboxSelector:
                        '#conditions-to-approve input[name="conditions_to_approve[terms-and-conditions]"], .js-conditions-to-approve input[name="conditions_to_approve[terms-and-conditions]"]',
                    paymentBinary: ".payment-binary, .js-payment-binary",
                    deliveryFormSelector: "#js-delivery",
                    summarySelector: "#js-checkout-summary",
                    deliveryStepSelector: "#checkout-delivery-step",
                    editDeliveryButtonSelector: ".js-edit-delivery",
                    deliveryOption: ".delivery-option, .js-delivery-option",
                    cartPaymentStepRefresh: ".js-cart-payment-step-refresh",
                    editAddresses: ".js-edit-addresses",
                    deliveryAddressRadios:
                        "#delivery-addresses input[type=radio], #invoice-addresses input[type=radio], .js-address-selector input[type=radio]",
                    addressItem: ".address-item, .js-address-item",
                    addressesStep: "#checkout-addresses-step",
                    addressItemChecked:
                        ".address-item:has(input[type=radio]:checked), .js-address-item:has(input[type=radio]:checked)",
                    addressError: ".js-address-error",
                    notValidAddresses:
                        "#not-valid-addresses, .js-not-valid-addresses",
                    invoiceAddresses:
                        "#invoice-addresses, .js-address-selector",
                    addressForm: ".js-address-form",
                },
                cart: {
                    detailedTotals:
                        ".cart-detailed-totals, .js-cart-detailed-totals",
                    summaryItemsSubtotal:
                        ".cart-summary-items-subtotal, .js-cart-summary-items-subtotal",
                    summarySubTotalsContainer:
                        ".cart-summary-subtotals-container, .js-cart-summary-subtotals-container",
                    summaryTotals:
                        ".cart-summary-totals, .js-cart-summary-totals",
                    summaryProducts:
                        ".cart-summary-products, .js-cart-summary-products",
                    detailedActions:
                        ".cart-detailed-actions, .js-cart-detailed-actions",
                    voucher: ".cart-voucher, .js-cart-voucher",
                    overview: ".cart-overview",
                    summaryTop: ".cart-summary-top, .js-cart-summary-top",
                    productCustomizationId:
                        "#product_customization_id, .js-product-customization-id",
                    lineProductQuantity: ".js-cart-line-product-quantity",
                },
            }),
                t()(() => {
                    r().emit("selectorsInit");
                });
            function o(e) {
                const t = {};
                return (
                    window.location.href
                        .replace(location.hash, "")
                        .replace(/[?&]+([^=&]+)=?([^&]*)?/gi, (e, n, r) => {
                            t[n] = void 0 !== r ? r : "";
                        }),
                    void 0 !== e ? (t[e] ? t[e] : null) : t
                );
            }
            function i() {
                const e = o();
                if (e.updatedTransaction) return void window.location.reload();
                e.updatedTransaction = 1;
                const t = Object.entries(e)
                    .map((e) => e.join("="))
                    .join("&");
                window.location.href = `${window.location.pathname}?${t}`;
            }
            (r().checkPasswordScore = (e) => {
                return (
                    (t = void 0),
                    (n = null),
                    (r = function* () {
                        return (0,
                        (yield a.e(48).then(a.t.bind(a, 48, 23))).default)(e);
                    }),
                    new Promise((e, o) => {
                        var i = (e) => {
                                try {
                                    s(r.next(e));
                                } catch (e) {
                                    o(e);
                                }
                            },
                            a = (e) => {
                                try {
                                    s(r.throw(e));
                                } catch (e) {
                                    o(e);
                                }
                            },
                            s = (t) =>
                                t.done
                                    ? e(t.value)
                                    : Promise.resolve(t.value).then(i, a);
                        s((r = r.apply(t, n)).next());
                    })
                );
                var t, n, r;
            }),
                /**
                 * Copyright since 2007 PrestaShop SA and Contributors
                 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
                 *
                 * NOTICE OF LICENSE
                 *
                 * This source file is subject to the Open Software License (OSL 3.0)
                 * that is bundled with this package in the file LICENSE.md.
                 * It is also available through the world-wide-web at this URL:
                 * https://opensource.org/licenses/OSL-3.0
                 * If you did not receive a copy of the license and are unable to
                 * obtain it through the world-wide-web, please send an email
                 * to license@prestashop.com so we can send you a copy immediately.
                 *
                 * DISCLAIMER
                 *
                 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
                 * versions in the future. If you wish to customize PrestaShop for your
                 * needs please refer to https://devdocs.prestashop.com/ for more information.
                 *
                 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
                 * @copyright Since 2007 PrestaShop SA and Contributors
                 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
                 */
                t()(() => {
                    r().on("updateCart", (e) => {
                        r().cart = e.resp.cart;
                        const n = t()(".js-cart").data("refresh-url");
                        if (!n) return;
                        let o = {};
                        e &&
                            e.reason &&
                            (o = {
                                id_product_attribute:
                                    e.reason.idProductAttribute,
                                id_product: e.reason.idProduct,
                            }),
                            t()
                                .post(n, o)
                                .then((e) => {
                                    t()(
                                        r().selectors.cart.detailedTotals
                                    ).replaceWith(e.cart_detailed_totals),
                                        t()(
                                            r().selectors.cart
                                                .summaryItemsSubtotal
                                        ).replaceWith(
                                            e.cart_summary_items_subtotal
                                        ),
                                        t()(
                                            r().selectors.cart
                                                .summarySubTotalsContainer
                                        ).replaceWith(
                                            e.cart_summary_subtotals_container
                                        ),
                                        t()(
                                            r().selectors.cart.summaryProducts
                                        ).replaceWith(e.cart_summary_products),
                                        t()(
                                            r().selectors.cart.summaryTotals
                                        ).replaceWith(e.cart_summary_totals),
                                        t()(
                                            r().selectors.cart.detailedActions
                                        ).replaceWith(e.cart_detailed_actions),
                                        t()(
                                            r().selectors.cart.voucher
                                        ).replaceWith(e.cart_voucher),
                                        t()(
                                            r().selectors.cart.overview
                                        ).replaceWith(e.cart_detailed),
                                        t()(
                                            r().selectors.cart.summaryTop
                                        ).replaceWith(e.cart_summary_top),
                                        t()(
                                            r().selectors.cart
                                                .productCustomizationId
                                        ).val(0),
                                        t()(
                                            r().selectors.cart
                                                .lineProductQuantity
                                        ).each((e, n) => {
                                            const r = t()(n);
                                            r.attr("value", r.val());
                                        }),
                                        t()(
                                            r().selectors.checkout
                                                .cartPaymentStepRefresh
                                        ).length && i(),
                                        r().emit("updatedCart", {
                                            eventType: "updateCart",
                                            resp: e,
                                        });
                                })
                                .fail((e) => {
                                    r().emit("handleError", {
                                        eventType: "updateCart",
                                        resp: e,
                                    });
                                });
                    });
                    const e = t()("body");
                    e.on("click", '[data-button-action="add-to-cart"]', (e) => {
                        e.preventDefault();
                        const n = t()(e.currentTarget.form),
                            o = `${n.serialize()}&add=1&action=update`,
                            i = n.attr("action"),
                            a = t()(e.currentTarget);
                        a.prop("disabled", !0);
                        let s = (e) => {
                            e
                                .parents(r().selectors.product.addToCart)
                                .first()
                                .find(r().selectors.product.minimalQuantity)
                                .addClass("error"),
                                e.parent().find("label").addClass("error");
                        };
                        const c = n.find("input[min]");
                        ((e) => {
                            let n = !0;
                            return (
                                e.each((e, r) => {
                                    const o = t()(r),
                                        i = parseInt(o.attr("min"), 10);
                                    i && o.val() < i && (s(o), (n = !1));
                                }),
                                n
                            );
                        })(c)
                            ? t()
                                  .post(i, o, null, "json")
                                  .then((e) => {
                                      e.hasError
                                          ? r().emit("handleError", {
                                                eventType: "addProductToCart",
                                                resp: e,
                                            })
                                          : r().emit("updateCart", {
                                                reason: {
                                                    idProduct: e.id_product,
                                                    idProductAttribute:
                                                        e.id_product_attribute,
                                                    idCustomization:
                                                        e.id_customization,
                                                    linkAction: "add-to-cart",
                                                    cart: e.cart,
                                                },
                                                resp: e,
                                            });
                                  })
                                  .fail((e) => {
                                      r().emit("handleError", {
                                          eventType: "addProductToCart",
                                          resp: e,
                                      });
                                  })
                                  .always(() => {
                                      setTimeout(() => {
                                          a.prop("disabled", !1);
                                      }, 1e3);
                                  })
                            : s(c);
                    }),
                        e.on(
                            "submit",
                            '[data-link-action="add-voucher"]',
                            (e) => {
                                e.preventDefault();
                                const n = t()(e.currentTarget),
                                    o = n.attr("action");
                                0 === n.find("[name=action]").length &&
                                    n.append(
                                        t()("<input>", {
                                            type: "hidden",
                                            name: "ajax",
                                            value: 1,
                                        })
                                    ),
                                    0 === n.find("[name=action]").length &&
                                        n.append(
                                            t()("<input>", {
                                                type: "hidden",
                                                name: "action",
                                                value: "update",
                                            })
                                        ),
                                    t()
                                        .post(o, n.serialize(), null, "json")
                                        .then((n) => {
                                            n.hasError
                                                ? t()(".js-error")
                                                      .show()
                                                      .find(".js-error-text")
                                                      .text(n.errors[0])
                                                : r().emit("updateCart", {
                                                      reason: e.target.dataset,
                                                      resp: n,
                                                  });
                                        })
                                        .fail((e) => {
                                            r().emit("handleError", {
                                                eventType: "updateCart",
                                                resp: e,
                                            });
                                        });
                            }
                        );
                });
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            const s = o("editAddress"),
                c = o("use_same_address");
            t()(window).on("load", () => {
                let e = t()(`${r().selectors.checkout.addressError}:visible`);
                if (
                    (0 === parseInt(c, 10) &&
                        t()(r().selectors.checkout.invoiceAddresses).trigger(
                            "click"
                        ),
                    (null !== s ||
                        t()(`${r().selectors.checkout.addressForm}:visible`)
                            .length > 1) &&
                        e.hide(),
                    e.length > 0)
                ) {
                    const n = t()(r().selectors.checkout.addressError)
                        .prop("id")
                        .split("-")
                        .pop();
                    e.each(function () {
                        u(!0, n, t()(this).attr("name").split("-").pop());
                    });
                }
                (e = t()(`${r().selectors.checkout.addressError}:visible`)),
                    l(e.length <= 0);
            });
            const u = function (e, n, r) {
                    const o = t()(
                            `#id-address-${r}-address-${n} a.edit-address`
                        ),
                        i = ["text-info", "address-item-invalid"];
                    t()(`#${r}-addresses a.edit-address`).removeClass(i),
                        o.toggleClass(i, e);
                },
                l = function (e) {
                    t()("button[name=confirm-addresses]").prop("disabled", !e);
                };
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            (r().checkout = r().checkout || {}),
                (r().checkout.onCheckOrderableCartResponse = (e, t) =>
                    !0 === e.errors &&
                    (r().emit("orderConfirmationErrors", {
                        resp: e,
                        paymentObject: t,
                    }),
                    !0));
            class d {
                constructor() {
                    (this.confirmationSelector =
                        r().selectors.checkout.confirmationSelector),
                        (this.conditionsSelector =
                            r().selectors.checkout.conditionsSelector),
                        (this.conditionAlertSelector =
                            r().selectors.checkout.conditionAlertSelector),
                        (this.additionalInformatonSelector =
                            r().selectors.checkout.additionalInformatonSelector),
                        (this.optionsForm = r().selectors.checkout.optionsForm),
                        (this.termsCheckboxSelector =
                            r().selectors.checkout.termsCheckboxSelector);
                }
                init() {
                    r().on(
                        "orderConfirmationErrors",
                        ({ resp: e, paymentObject: t }) => {
                            "" !== e.cartUrl && (location.href = e.cartUrl);
                        }
                    );
                    const e = t()("body");
                    e.on(
                        "change",
                        `${this.conditionsSelector} input[type="checkbox"]`,
                        t().proxy(this.toggleOrderButton, this)
                    ),
                        e.on(
                            "change",
                            'input[name="payment-option"]',
                            t().proxy(this.toggleOrderButton, this)
                        ),
                        this.toggleOrderButton(),
                        e.on(
                            "click",
                            `${this.confirmationSelector} button`,
                            t().proxy(this.confirm, this)
                        ),
                        this.getSelectedOption() || this.collapseOptions();
                }
                collapseOptions() {
                    t()(
                        `${this.additionalInformatonSelector}, ${this.optionsForm}`
                    ).hide();
                }
                getSelectedOption() {
                    return t()('input[name="payment-option"]:checked').attr(
                        "id"
                    );
                }
                haveTermsBeenAccepted() {
                    return t()(this.termsCheckboxSelector).prop("checked");
                }
                hideConfirmation() {
                    t()(this.confirmationSelector).hide();
                }
                showConfirmation() {
                    t()(this.confirmationSelector).show();
                }
                toggleOrderButton() {
                    let e = !0;
                    t()(
                        `${this.conditionsSelector} input[type="checkbox"]`
                    ).each((t, n) => {
                        n.checked || (e = !1);
                    }),
                        r().emit("termsUpdated", { isChecked: e }),
                        this.collapseOptions();
                    const n = this.getSelectedOption();
                    if (
                        (n || (e = !1),
                        t()(`#${n}-additional-information`).show(),
                        t()(`#pay-with-${n}-form`).show(),
                        t()(r().selectors.checkout.paymentBinary).hide(),
                        t()(`#${n}`).hasClass("binary"))
                    ) {
                        const r = this.getPaymentOptionSelector(n);
                        this.hideConfirmation(),
                            t()(r).show(),
                            document
                                .querySelectorAll(`${r} button, ${r} input`)
                                .forEach((t) => {
                                    e
                                        ? t.removeAttribute("disabled")
                                        : t.setAttribute("disabled", !e);
                                }),
                            e
                                ? t()(r).removeClass("disabled")
                                : t()(r).addClass("disabled");
                    } else
                        this.showConfirmation(),
                            t()(
                                `${this.confirmationSelector} button`
                            ).toggleClass("disabled", !e),
                            t()(`${this.confirmationSelector} button`).attr(
                                "disabled",
                                !e
                            ),
                            e
                                ? t()(this.conditionAlertSelector).hide()
                                : t()(this.conditionAlertSelector).show();
                }
                getPaymentOptionSelector(e) {
                    return `.js-payment-${t()(`#${e}`).data("module-name")}`;
                }
                showNativeFormErrors() {
                    t()(
                        `input[name=payment-option], ${this.termsCheckboxSelector}`
                    ).each(function () {
                        this.reportValidity();
                    });
                }
                confirm() {
                    return (
                        (e = this),
                        (n = null),
                        (o = function* () {
                            const e = this.getSelectedOption(),
                                n = this.haveTermsBeenAccepted();
                            if (void 0 === e || !1 === n)
                                return void this.showNativeFormErrors();
                            const o = yield t().post(
                                window.prestashop.urls.pages.order,
                                { ajax: 1, action: "checkCartStillOrderable" }
                            );
                            r().checkout.onCheckOrderableCartResponse(
                                o,
                                this
                            ) ||
                                (t()(
                                    `${this.confirmationSelector} button`
                                ).addClass("disabled"),
                                t()(`#pay-with-${e}-form form`).submit());
                        }),
                        new Promise((t, r) => {
                            var i = (e) => {
                                    try {
                                        s(o.next(e));
                                    } catch (e) {
                                        r(e);
                                    }
                                },
                                a = (e) => {
                                    try {
                                        s(o.throw(e));
                                    } catch (e) {
                                        r(e);
                                    }
                                },
                                s = (e) =>
                                    e.done
                                        ? t(e.value)
                                        : Promise.resolve(e.value).then(i, a);
                            s((o = o.apply(e, n)).next());
                        })
                    );
                    var e, n, o;
                }
            }
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            const p = r().selectors.checkout.currentStep,
                f = `.${p}`;
            class h {
                constructor() {
                    (this.$steps = t()(r().selectors.checkout.step)),
                        this.$steps.off("click"),
                        (this.$clickableSteps = t()(f).prevAll().addBack()),
                        this.$clickableSteps.addClass("-clickable");
                }
                getClickableSteps() {
                    return this.$clickableSteps;
                }
                makeCurrent(e) {
                    this.$steps.removeClass("-current"),
                        this.$steps.removeClass(p),
                        e.makeCurrent();
                }
                static getClickedStep(e) {
                    return new m(
                        t()(e.target).closest(r().selectors.checkout.step)
                    );
                }
            }
            class m {
                constructor(e) {
                    this.$step = e;
                }
                isUnreachable() {
                    return this.$step.hasClass("-unreachable");
                }
                makeCurrent() {
                    this.$step.addClass("-current"), this.$step.addClass(p);
                }
                hasContinueButton() {
                    return t()("button.continue", this.$step).length > 0;
                }
                disableAllAfter() {
                    const e = this.$step.nextAll();
                    e.addClass("-unreachable").removeClass("-complete"),
                        t()(r().selectors.checkout.stepTitle, e).addClass(
                            "not-allowed"
                        );
                }
                enableAllBefore() {
                    const e = this.$step.nextAll(
                        `${r().selectors.checkout.step}.-clickable`
                    );
                    e.removeClass("-unreachable").addClass("-complete"),
                        t()(r().selectors.checkout.stepTitle, e).removeClass(
                            "not-allowed"
                        );
                }
            }
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            function g() {
                t()(r().selectors.checkout.editAddresses).on("click", (e) => {
                    e.stopPropagation(),
                        t()(r().selectors.checkout.addressesStep).trigger(
                            "click"
                        ),
                        r().emit("editAddress");
                }),
                    t()(r().selectors.checkout.deliveryAddressRadios).on(
                        "click",
                        function () {
                            t()(r().selectors.checkout.addressItem).removeClass(
                                "selected"
                            ),
                                t()(
                                    r().selectors.checkout.addressItemChecked
                                ).addClass("selected");
                            const e = t()(r().selectors.checkout.addressError)
                                    .prop("id")
                                    .split("-")
                                    .pop(),
                                n = t()(
                                    r().selectors.checkout.notValidAddresses
                                ).val(),
                                o = this.name.split("_").pop(),
                                i = t()(
                                    `${
                                        r().selectors.checkout.addressError
                                    }[name=alert-${o}]`
                                );
                            u(!1, e, o),
                                "" !== n &&
                                null === s &&
                                n.split(",").indexOf(this.value) >= 0
                                    ? (i.show(),
                                      u(!0, this.value, o),
                                      t()(
                                          r().selectors.checkout.addressError
                                      ).prop(
                                          "id",
                                          `id-failure-address-${this.value}`
                                      ))
                                    : i.hide();
                            const a = t()(
                                `${r().selectors.checkout.addressError}:visible`
                            );
                            l(a.length <= 0);
                        }
                    ),
                    /**
                     * Copyright since 2007 PrestaShop SA and Contributors
                     * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
                     *
                     * NOTICE OF LICENSE
                     *
                     * This source file is subject to the Open Software License (OSL 3.0)
                     * that is bundled with this package in the file LICENSE.md.
                     * It is also available through the world-wide-web at this URL:
                     * https://opensource.org/licenses/OSL-3.0
                     * If you did not receive a copy of the license and are unable to
                     * obtain it through the world-wide-web, please send an email
                     * to license@prestashop.com so we can send you a copy immediately.
                     *
                     * DISCLAIMER
                     *
                     * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
                     * versions in the future. If you wish to customize PrestaShop for your
                     * needs please refer to https://devdocs.prestashop.com/ for more information.
                     *
                     * @author    PrestaShop SA and Contributors <contact@prestashop.com>
                     * @copyright Since 2007 PrestaShop SA and Contributors
                     * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
                     */ (function () {
                        const e = t()("body"),
                            { deliveryFormSelector: n } =
                                r().selectors.checkout,
                            { summarySelector: o } = r().selectors.checkout,
                            { deliveryStepSelector: a } =
                                r().selectors.checkout,
                            { editDeliveryButtonSelector: s } =
                                r().selectors.checkout;
                        e.on("change", `${n} input`, (e) => {
                            const a = t()(n),
                                s = a.serialize(),
                                c = t()(e.currentTarget).parents(
                                    r().selectors.checkout.deliveryOption
                                );
                            t()
                                .post(a.data("url-update"), s)
                                .then((e) => {
                                    t()(o).replaceWith(e.preview),
                                        t()(
                                            r().selectors.checkout
                                                .cartPaymentStepRefresh
                                        ).length && i(),
                                        r().emit("updatedDeliveryForm", {
                                            dataForm: a.serializeArray(),
                                            deliveryOption: c,
                                            resp: e,
                                        });
                                })
                                .fail((e) => {
                                    r().trigger("handleError", {
                                        eventType: "updateDeliveryOptions",
                                        resp: e,
                                    });
                                });
                        }),
                            e.on("click", s, (e) => {
                                e.stopPropagation(),
                                    t()(a).trigger("click"),
                                    r().emit("editDelivery");
                            });
                    })(),
                    (function () {
                        const e = new d();
                        e.init();
                    })(),
                    (function () {
                        const e = new h();
                        e.getClickableSteps().on("click", (t) => {
                            const n = h.getClickedStep(t);
                            n.isUnreachable() ||
                                (e.makeCurrent(n),
                                n.hasContinueButton()
                                    ? n.disableAllAfter()
                                    : n.enableAllBefore()),
                                r().emit("changedCheckoutStep", { event: t });
                        });
                    })(),
                    (function () {
                        const e = r().selectors.checkout.form;
                        t()(e).on("submit", function (e) {
                            !0 === t()(this).data("disabled") &&
                                e.preventDefault(),
                                t()(this).data("disabled", !0),
                                t()('button[type="submit"]', this).addClass(
                                    "disabled"
                                );
                        });
                    })();
            }
            t()(() => {
                1 === t()("#checkout").length && g();
            });
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            let v = null;
            function y(e) {
                r().emit("updateProductList", e),
                    window.history.pushState(e, document.title, e.current_url);
            }
            function b(e, t) {
                return "abort" !== t;
            }
            function x(e) {
                v === e && (v = null);
            }
            t()(() => {
                r().on("updateFacets", (e) => {
                    !(function (e) {
                        v && v.abort();
                        const n = e.indexOf("?") >= 0 ? "&" : "?",
                            r = `${e + n}from-xhr`;
                        v = t().ajax({
                            url: r,
                            dataType: "json",
                            success: y,
                            error: b,
                            complete: x,
                        });
                    })(e);
                });
            }),
                /**
                 * Copyright since 2007 PrestaShop SA and Contributors
                 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
                 *
                 * NOTICE OF LICENSE
                 *
                 * This source file is subject to the Open Software License (OSL 3.0)
                 * that is bundled with this package in the file LICENSE.md.
                 * It is also available through the world-wide-web at this URL:
                 * https://opensource.org/licenses/OSL-3.0
                 * If you did not receive a copy of the license and are unable to
                 * obtain it through the world-wide-web, please send an email
                 * to license@prestashop.com so we can send you a copy immediately.
                 *
                 * DISCLAIMER
                 *
                 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
                 * versions in the future. If you wish to customize PrestaShop for your
                 * needs please refer to https://devdocs.prestashop.com/ for more information.
                 *
                 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
                 * @copyright Since 2007 PrestaShop SA and Contributors
                 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
                 */
                t()(() => {
                    t()("body").on(
                        "click",
                        r().selectors.listing.quickview,
                        (e) => {
                            r().emit("clickQuickView", {
                                dataset: t()(e.target)
                                    .closest(r().selectors.product.miniature)
                                    .data(),
                            }),
                                e.preventDefault();
                        }
                    );
                });
            var w = Object.defineProperty,
                j = Object.getOwnPropertySymbols,
                k = Object.prototype.hasOwnProperty,
                C = Object.prototype.propertyIsEnumerable,
                T = (e, t, n) =>
                    t in e
                        ? w(e, t, {
                              enumerable: !0,
                              configurable: !0,
                              writable: !0,
                              value: n,
                          })
                        : (e[t] = n),
                S = (e, t) => {
                    for (var n in t || (t = {})) k.call(t, n) && T(e, n, t[n]);
                    if (j) for (var n of j(t)) C.call(t, n) && T(e, n, t[n]);
                    return e;
                };
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            let A = null,
                E = null,
                D = !1;
            const P = [];
            let q = !1;
            function N(e) {
                !(function (e, n) {
                    const r = t()(
                        `<div class="alert alert-danger ajax-error" role="alert">${n}</div>`
                    );
                    e.replaceWith(r);
                })(
                    t()(
                        ".quickview #product-availability, .page-product:not(.modal-open) .row #product-availability, .page-product:not(.modal-open) .product-container #product-availability"
                    ),
                    e
                );
            }
            function O(e, n, i) {
                const a = t()(r().selectors.product.actions).last(),
                    s = a.find(r().selectors.quantityWanted),
                    c = a.find("form:first"),
                    u = c.serialize();
                let l,
                    d = o("preview");
                if (
                    ("function" == typeof Event
                        ? (l = new Event("updateRating"))
                        : ((l = document.createEvent("Event")),
                          l.initEvent("updateRating", !0, !0)),
                    null !== d)
                ) {
                    const e = o("adtoken"),
                        t = o("id_employee");
                    d = `&preview=${d}&adtoken=${e}&id_employee=${t}`;
                } else d = "";
                if (null === i) return void N();
                if (e && "keyup" === e.type && s.val() === s.data("old-value"))
                    return;
                s.data("old-value", s.val()), E && clearTimeout(E);
                let p = 30;
                "updatedProductQuantity" === n && (p = 750),
                    (E = setTimeout(() => {
                        "" !== u &&
                            (A = t().ajax({
                                url:
                                    i +
                                    (-1 === i.indexOf("?") ? "?" : "&") +
                                    u +
                                    d,
                                method: "POST",
                                data: {
                                    quickview: t()(
                                        ".modal.quickview.in, .modal.quickview.show"
                                    ).length,
                                    ajax: 1,
                                    action: "refresh",
                                    quantity_wanted:
                                        "updatedProductCombination" === n
                                            ? s.attr("min")
                                            : s.val(),
                                },
                                dataType: "json",
                                beforeSend() {
                                    null !== A && A.abort();
                                },
                                error(e, n) {
                                    "abort" !== n &&
                                        0 ===
                                            t()("section#main > .ajax-error")
                                                .length &&
                                        N();
                                },
                                success(e) {
                                    const o = t()("<div>").append(
                                        e.product_cover_thumbnails
                                    );
                                    t()(
                                        r().selectors.product.imageContainer
                                    ).html() !==
                                        o
                                            .find(
                                                r().selectors.product
                                                    .imageContainer
                                            )
                                            .html() &&
                                        t()(
                                            r().selectors.product.imageContainer
                                        ).replaceWith(
                                            e.product_cover_thumbnails
                                        ),
                                        t()(r().selectors.product.prices)
                                            .first()
                                            .replaceWith(e.product_prices),
                                        t()(r().selectors.product.customization)
                                            .first()
                                            .replaceWith(
                                                e.product_customization
                                            ),
                                        ("updatedProductQuantity" !== n &&
                                            "updatedProductCombination" !==
                                                n) ||
                                        !e.id_customization
                                            ? t()(
                                                  r().selectors.product
                                                      .inputCustomization
                                              ).val(0)
                                            : t()(
                                                  r().selectors.cart
                                                      .productCustomizationId
                                              ).val(e.id_customization),
                                        t()(
                                            r().selectors.product.variantsUpdate
                                        )
                                            .first()
                                            .replaceWith(e.product_variants),
                                        t()(r().selectors.product.discounts)
                                            .first()
                                            .replaceWith(e.product_discounts),
                                        t()(
                                            r().selectors.product
                                                .additionalInfos
                                        )
                                            .first()
                                            .replaceWith(
                                                e.product_additional_info
                                            ),
                                        t()(
                                            r().selectors.product.details
                                        ).replaceWith(e.product_details),
                                        t()(r().selectors.product.flags)
                                            .first()
                                            .replaceWith(e.product_flags),
                                        (function (e) {
                                            let n = null;
                                            t()(e.product_add_to_cart).each(
                                                (e, r) =>
                                                    !t()(r).hasClass(
                                                        "product-add-to-cart"
                                                    ) || ((n = t()(r)), !1)
                                            ),
                                                null === n && N();
                                            const o = t()(
                                                    r().selectors.product
                                                        .addToCart
                                                ),
                                                i = "#product-availability",
                                                a = ".product-minimal-quantity";
                                            _({
                                                $addToCartSnippet: n,
                                                $targetParent: o,
                                                targetSelector: ".add",
                                            }),
                                                _({
                                                    $addToCartSnippet: n,
                                                    $targetParent: o,
                                                    targetSelector: i,
                                                }),
                                                _({
                                                    $addToCartSnippet: n,
                                                    $targetParent: o,
                                                    targetSelector: a,
                                                });
                                        })(e);
                                    const i = parseInt(
                                        e.product_minimal_quantity,
                                        10
                                    );
                                    document.dispatchEvent(l),
                                        isNaN(i) ||
                                            "updatedProductQuantity" === n ||
                                            (s.attr("min", i), s.val(i)),
                                        r().emit(
                                            "updatedProduct",
                                            e,
                                            c.serializeArray()
                                        );
                                },
                                complete() {
                                    (A = null), (E = null);
                                },
                            }));
                    }, p));
            }
            function _(e) {
                const n = t()(e.$targetParent.find(e.targetSelector));
                if (n.length <= 0) return;
                const r = e.$addToCartSnippet.find(e.targetSelector);
                r.length > 0 ? n.replaceWith(r[0].outerHTML) : n.html("");
            }
            t()(() => {
                const e = t()(r().selectors.product.actions);
                t()("body").on(
                    "change touchspin.on.startspin",
                    `${r().selectors.product.variants} *[name]`,
                    (e) => {
                        (q = !0),
                            r().emit("updateProduct", {
                                eventType: "updatedProductCombination",
                                event: e,
                                resp: {},
                                reason: {
                                    productUrl: r().urls.pages.product || "",
                                },
                            });
                    }
                ),
                    t()(e.find("form:first").serializeArray()).each(
                        (e, { value: t, name: n }) => {
                            P.push({ value: t, name: n });
                        }
                    ),
                    window.addEventListener("popstate", (e) => {
                        if (
                            ((D = !0),
                            (!e.state ||
                                (e.state &&
                                    e.state.form &&
                                    0 === e.state.form.length)) &&
                                !q)
                        )
                            return;
                        const n = t()(r().selectors.product.actions).find(
                            "form:first"
                        );
                        e.state && e.state.form
                            ? e.state.form.forEach((e) => {
                                  n.find(`[name="${e.name}"]`).val(e.value);
                              })
                            : P.forEach((e) => {
                                  n.find(`[name="${e.name}"]`).val(e.value);
                              }),
                            r().emit("updateProduct", {
                                eventType: "updatedProductCombination",
                                event: e,
                                resp: {},
                                reason: {
                                    productUrl: r().urls.pages.product || "",
                                },
                            });
                    }),
                    t()("body").on(
                        "click",
                        r().selectors.product.refresh,
                        (e, t) => {
                            e.preventDefault();
                            let n = "updatedProductCombination";
                            void 0 !== t && t.eventType && (n = t.eventType),
                                r().emit("updateProduct", {
                                    eventType: n,
                                    event: e,
                                    resp: {},
                                    reason: {
                                        productUrl:
                                            r().urls.pages.product || "",
                                    },
                                });
                        }
                    ),
                    r().on("updateProduct", (e) => {
                        const { eventType: n } = e,
                            { event: o } = e;
                        (function () {
                            const e = t().Deferred(),
                                n = t()(r().selectors.product.actions),
                                o = t()(r().selectors.quantityWanted);
                            if (
                                null !== r() &&
                                null !== r().urls &&
                                null !== r().urls.pages &&
                                "" !== r().urls.pages.product &&
                                null !== r().urls.pages.product
                            )
                                return (
                                    e.resolve(r().urls.pages.product),
                                    e.promise()
                                );
                            const i = {};
                            return (
                                t()(n.find("form:first").serializeArray()).each(
                                    (e, t) => {
                                        i[t.name] = t.value;
                                    }
                                ),
                                t().ajax({
                                    url: n.find("form:first").attr("action"),
                                    method: "POST",
                                    data: S(
                                        {
                                            ajax: 1,
                                            action: "productrefresh",
                                            quantity_wanted: o.val(),
                                        },
                                        i
                                    ),
                                    dataType: "json",
                                    success(t) {
                                        const n = t.productUrl;
                                        (r().page.canonical = n), e.resolve(n);
                                    },
                                    error(t, n, r) {
                                        e.reject({
                                            jqXHR: t,
                                            textStatus: n,
                                            errorThrown: r,
                                        });
                                    },
                                }),
                                e.promise()
                            );
                        })()
                            .done((e) => O(o, n, e))
                            .fail(() => {
                                0 ===
                                    t()("section#main > .ajax-error").length &&
                                    N();
                            });
                    }),
                    r().on("updatedProduct", (e, n) => {
                        if (!e.product_url || !e.id_product_attribute) return;
                        if (t()(".modal.quickview").length) return;
                        let r = document.title;
                        e.product_title &&
                            ((r = e.product_title),
                            t()(document).attr("title", r)),
                            D ||
                                window.history.pushState(
                                    {
                                        id_product_attribute:
                                            e.id_product_attribute,
                                        form: n,
                                    },
                                    r,
                                    e.product_url
                                ),
                            (D = !1);
                    }),
                    r().on("updateCart", (e) => {
                        if (
                            !e ||
                            !e.reason ||
                            "add-to-cart" !== e.reason.linkAction
                        )
                            return;
                        t()("#quantity_wanted").val(1);
                    }),
                    r().on("showErrorNextToAddtoCartButton", (e) => {
                        e && e.errorMessage && N(e.errorMessage);
                    });
            }),
                t()(() => {
                    var e;
                    (e = {
                        country: ".js-country",
                        address: ".js-address-form",
                    }),
                        t()("body").on("change", e.country, (n) => {
                            const o = {
                                    id_country: t()(e.country).val(),
                                    id_address: t()(`${e.address} form`).data(
                                        "id-address"
                                    ),
                                },
                                i = t()(`${e.address} form`).data(
                                    "refresh-url"
                                ),
                                a = `${e.address} input`,
                                s = t()(n.target);
                            t()
                                .post(i, o)
                                .then((n) => {
                                    const o = [];
                                    t()(a).each(function () {
                                        o[t()(this).prop("name")] =
                                            t()(this).val();
                                    }),
                                        t()(s.closest(e.address)).replaceWith(
                                            n.address_form
                                        ),
                                        t()(a).each(function () {
                                            t()(this).val(
                                                o[t()(this).prop("name")]
                                            );
                                        }),
                                        r().emit("updatedAddressForm", {
                                            target: t()(e.address),
                                            resp: n,
                                        });
                                })
                                .fail((e) => {
                                    r().emit("handleError", {
                                        eventType: "updateAddressForm",
                                        resp: e,
                                    });
                                });
                        });
                });
            const $ = 2147483647,
                H = 36,
                L = /^xn--/,
                R = /[^\0-\x7F]/,
                M = /[\x2E\u3002\uFF0E\uFF61]/g,
                I = {
                    overflow: "Overflow: input needs wider integers to process",
                    "not-basic":
                        "Illegal input >= 0x80 (not a basic code point)",
                    "invalid-input": "Invalid input",
                },
                W = Math.floor,
                F = String.fromCharCode;
            function Q(e) {
                throw new RangeError(I[e]);
            }
            function B(e, t) {
                const n = e.split("@");
                let r = "";
                n.length > 1 && ((r = n[0] + "@"), (e = n[1]));
                const o = (function (e, t) {
                    const n = [];
                    let r = e.length;
                    for (; r--; ) n[r] = t(e[r]);
                    return n;
                })((e = e.replace(M, ".")).split("."), t).join(".");
                return r + o;
            }
            function z(e) {
                const t = [];
                let n = 0;
                const r = e.length;
                for (; n < r; ) {
                    const o = e.charCodeAt(n++);
                    if (o >= 55296 && o <= 56319 && n < r) {
                        const r = e.charCodeAt(n++);
                        56320 == (64512 & r)
                            ? t.push(((1023 & o) << 10) + (1023 & r) + 65536)
                            : (t.push(o), n--);
                    } else t.push(o);
                }
                return t;
            }
            const U = function (e, t) {
                    return e + 22 + 75 * (e < 26) - ((0 != t) << 5);
                },
                X = function (e, t, n) {
                    let r = 0;
                    for (
                        e = n ? W(e / 700) : e >> 1, e += W(e / t);
                        e > 455;
                        r += H
                    )
                        e = W(e / 35);
                    return W(r + (36 * e) / (e + 38));
                },
                V = function (e) {
                    const t = [],
                        n = e.length;
                    let r = 0,
                        o = 128,
                        i = 72,
                        a = e.lastIndexOf("-");
                    a < 0 && (a = 0);
                    for (let n = 0; n < a; ++n)
                        e.charCodeAt(n) >= 128 && Q("not-basic"),
                            t.push(e.charCodeAt(n));
                    for (let c = a > 0 ? a + 1 : 0; c < n; ) {
                        const a = r;
                        for (let t = 1, o = H; ; o += H) {
                            c >= n && Q("invalid-input");
                            const a =
                                (s = e.charCodeAt(c++)) >= 48 && s < 58
                                    ? s - 48 + 26
                                    : s >= 65 && s < 91
                                    ? s - 65
                                    : s >= 97 && s < 123
                                    ? s - 97
                                    : H;
                            a >= H && Q("invalid-input"),
                                a > W(($ - r) / t) && Q("overflow"),
                                (r += a * t);
                            const u = o <= i ? 1 : o >= i + 26 ? 26 : o - i;
                            if (a < u) break;
                            const l = H - u;
                            t > W($ / l) && Q("overflow"), (t *= l);
                        }
                        const u = t.length + 1;
                        (i = X(r - a, u, 0 == a)),
                            W(r / u) > $ - o && Q("overflow"),
                            (o += W(r / u)),
                            (r %= u),
                            t.splice(r++, 0, o);
                    }
                    var s;
                    return String.fromCodePoint(...t);
                },
                J = function (e) {
                    const t = [],
                        n = (e = z(e)).length;
                    let r = 128,
                        o = 0,
                        i = 72;
                    for (const n of e) n < 128 && t.push(F(n));
                    const a = t.length;
                    let s = a;
                    for (a && t.push("-"); s < n; ) {
                        let n = $;
                        for (const t of e) t >= r && t < n && (n = t);
                        const c = s + 1;
                        n - r > W(($ - o) / c) && Q("overflow"),
                            (o += (n - r) * c),
                            (r = n);
                        for (const n of e)
                            if ((n < r && ++o > $ && Q("overflow"), n === r)) {
                                let e = o;
                                for (let n = H; ; n += H) {
                                    const r =
                                        n <= i ? 1 : n >= i + 26 ? 26 : n - i;
                                    if (e < r) break;
                                    const o = e - r,
                                        a = H - r;
                                    t.push(F(U(r + (o % a), 0))),
                                        (e = W(o / a));
                                }
                                t.push(F(U(e, 0))),
                                    (i = X(o, c, s === a)),
                                    (o = 0),
                                    ++s;
                            }
                        ++o, ++r;
                    }
                    return t.join("");
                },
                G = {
                    version: "2.3.1",
                    ucs2: {
                        decode: z,
                        encode: (e) => String.fromCodePoint(...e),
                    },
                    decode: V,
                    encode: J,
                    toASCII: function (e) {
                        return B(e, function (e) {
                            return R.test(e) ? "xn--" + J(e) : e;
                        });
                    },
                    toUnicode: function (e) {
                        return B(e, function (e) {
                            return L.test(e) ? V(e.slice(4).toLowerCase()) : e;
                        });
                    },
                },
                Y = function (e) {
                    const n = t()(e);
                    t().each(n, (e, t) => {
                        if (!t.checkValidity()) {
                            const e = t.value.split("@");
                            G.toASCII(e[0]) === e[0] &&
                                (t.value = G.toASCII(t.value));
                        }
                    });
                };
            /**
             * Copyright since 2007 PrestaShop SA and Contributors
             * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
             *
             * NOTICE OF LICENSE
             *
             * This source file is subject to the Open Software License (OSL 3.0)
             * that is bundled with this package in the file LICENSE.md.
             * It is also available through the world-wide-web at this URL:
             * https://opensource.org/licenses/OSL-3.0
             * If you did not receive a copy of the license and are unable to
             * obtain it through the world-wide-web, please send an email
             * to license@prestashop.com so we can send you a copy immediately.
             *
             * DISCLAIMER
             *
             * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
             * versions in the future. If you wish to customize PrestaShop for your
             * needs please refer to https://devdocs.prestashop.com/ for more information.
             *
             * @author    PrestaShop SA and Contributors <contact@prestashop.com>
             * @copyright Since 2007 PrestaShop SA and Contributors
             * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
             */
            (a.p = window.prestashop.core_js_public_path),
                (window.$ = t()),
                (window.jQuery = t()),
                t()(() => {
                    t()(".ps-shown-by-js").show(),
                        t()(".ps-hidden-by-js").hide(),
                        Y('input[type="email"]');
                });
        })();
})();
!(function () {
    var t = {
            58: function (t) {
                "use strict";
                var e,
                    o = "object" == typeof Reflect ? Reflect : null,
                    n =
                        o && "function" == typeof o.apply
                            ? o.apply
                            : function (t, e, o) {
                                  return Function.prototype.apply.call(t, e, o);
                              };
                e =
                    o && "function" == typeof o.ownKeys
                        ? o.ownKeys
                        : Object.getOwnPropertySymbols
                        ? function (t) {
                              return Object.getOwnPropertyNames(t).concat(
                                  Object.getOwnPropertySymbols(t)
                              );
                          }
                        : function (t) {
                              return Object.getOwnPropertyNames(t);
                          };
                var r =
                    Number.isNaN ||
                    function (t) {
                        return t != t;
                    };
                function i() {
                    i.init.call(this);
                }
                (t.exports = i),
                    (t.exports.once = function (t, e) {
                        return new Promise(function (o, n) {
                            function r(o) {
                                t.removeListener(e, i), n(o);
                            }
                            function i() {
                                "function" == typeof t.removeListener &&
                                    t.removeListener("error", r),
                                    o([].slice.call(arguments));
                            }
                            m(t, e, i, { once: !0 }),
                                "error" !== e &&
                                    (function (t, e, o) {
                                        "function" == typeof t.on &&
                                            m(t, "error", e, o);
                                    })(t, r, { once: !0 });
                        });
                    }),
                    (i.EventEmitter = i),
                    (i.prototype._events = void 0),
                    (i.prototype._eventsCount = 0),
                    (i.prototype._maxListeners = void 0);
                var s = 10;
                function a(t) {
                    if ("function" != typeof t)
                        throw new TypeError(
                            'The "listener" argument must be of type Function. Received type ' +
                                typeof t
                        );
                }
                function l(t) {
                    return void 0 === t._maxListeners
                        ? i.defaultMaxListeners
                        : t._maxListeners;
                }
                function c(t, e, o, n) {
                    var r, i, s, c;
                    if (
                        (a(o),
                        void 0 === (i = t._events)
                            ? ((i = t._events = Object.create(null)),
                              (t._eventsCount = 0))
                            : (void 0 !== i.newListener &&
                                  (t.emit(
                                      "newListener",
                                      e,
                                      o.listener ? o.listener : o
                                  ),
                                  (i = t._events)),
                              (s = i[e])),
                        void 0 === s)
                    )
                        (s = i[e] = o), ++t._eventsCount;
                    else if (
                        ("function" == typeof s
                            ? (s = i[e] = n ? [o, s] : [s, o])
                            : n
                            ? s.unshift(o)
                            : s.push(o),
                        (r = l(t)) > 0 && s.length > r && !s.warned)
                    ) {
                        s.warned = !0;
                        var h = new Error(
                            "Possible EventEmitter memory leak detected. " +
                                s.length +
                                " " +
                                String(e) +
                                " listeners added. Use emitter.setMaxListeners() to increase limit"
                        );
                        (h.name = "MaxListenersExceededWarning"),
                            (h.emitter = t),
                            (h.type = e),
                            (h.count = s.length),
                            (c = h),
                            console && console.warn && console.warn(c);
                    }
                    return t;
                }
                function h() {
                    if (!this.fired)
                        return (
                            this.target.removeListener(this.type, this.wrapFn),
                            (this.fired = !0),
                            0 === arguments.length
                                ? this.listener.call(this.target)
                                : this.listener.apply(this.target, arguments)
                        );
                }
                function d(t, e, o) {
                    var n = {
                            fired: !1,
                            wrapFn: void 0,
                            target: t,
                            type: e,
                            listener: o,
                        },
                        r = h.bind(n);
                    return (r.listener = o), (n.wrapFn = r), r;
                }
                function f(t, e, o) {
                    var n = t._events;
                    if (void 0 === n) return [];
                    var r = n[e];
                    return void 0 === r
                        ? []
                        : "function" == typeof r
                        ? o
                            ? [r.listener || r]
                            : [r]
                        : o
                        ? (function (t) {
                              for (
                                  var e = new Array(t.length), o = 0;
                                  o < e.length;
                                  ++o
                              )
                                  e[o] = t[o].listener || t[o];
                              return e;
                          })(r)
                        : u(r, r.length);
                }
                function p(t) {
                    var e = this._events;
                    if (void 0 !== e) {
                        var o = e[t];
                        if ("function" == typeof o) return 1;
                        if (void 0 !== o) return o.length;
                    }
                    return 0;
                }
                function u(t, e) {
                    for (var o = new Array(e), n = 0; n < e; ++n) o[n] = t[n];
                    return o;
                }
                function m(t, e, o, n) {
                    if ("function" == typeof t.on)
                        n.once ? t.once(e, o) : t.on(e, o);
                    else {
                        if ("function" != typeof t.addEventListener)
                            throw new TypeError(
                                'The "emitter" argument must be of type EventEmitter. Received type ' +
                                    typeof t
                            );
                        t.addEventListener(e, function r(i) {
                            n.once && t.removeEventListener(e, r), o(i);
                        });
                    }
                }
                Object.defineProperty(i, "defaultMaxListeners", {
                    enumerable: !0,
                    get: function () {
                        return s;
                    },
                    set: function (t) {
                        if ("number" != typeof t || t < 0 || r(t))
                            throw new RangeError(
                                'The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' +
                                    t +
                                    "."
                            );
                        s = t;
                    },
                }),
                    (i.init = function () {
                        (void 0 !== this._events &&
                            this._events !==
                                Object.getPrototypeOf(this)._events) ||
                            ((this._events = Object.create(null)),
                            (this._eventsCount = 0)),
                            (this._maxListeners = this._maxListeners || void 0);
                    }),
                    (i.prototype.setMaxListeners = function (t) {
                        if ("number" != typeof t || t < 0 || r(t))
                            throw new RangeError(
                                'The value of "n" is out of range. It must be a non-negative number. Received ' +
                                    t +
                                    "."
                            );
                        return (this._maxListeners = t), this;
                    }),
                    (i.prototype.getMaxListeners = function () {
                        return l(this);
                    }),
                    (i.prototype.emit = function (t) {
                        for (var e = [], o = 1; o < arguments.length; o++)
                            e.push(arguments[o]);
                        var r = "error" === t,
                            i = this._events;
                        if (void 0 !== i) r = r && void 0 === i.error;
                        else if (!r) return !1;
                        if (r) {
                            var s;
                            if (
                                (e.length > 0 && (s = e[0]), s instanceof Error)
                            )
                                throw s;
                            var a = new Error(
                                "Unhandled error." +
                                    (s ? " (" + s.message + ")" : "")
                            );
                            throw ((a.context = s), a);
                        }
                        var l = i[t];
                        if (void 0 === l) return !1;
                        if ("function" == typeof l) n(l, this, e);
                        else {
                            var c = l.length,
                                h = u(l, c);
                            for (o = 0; o < c; ++o) n(h[o], this, e);
                        }
                        return !0;
                    }),
                    (i.prototype.addListener = function (t, e) {
                        return c(this, t, e, !1);
                    }),
                    (i.prototype.on = i.prototype.addListener),
                    (i.prototype.prependListener = function (t, e) {
                        return c(this, t, e, !0);
                    }),
                    (i.prototype.once = function (t, e) {
                        return a(e), this.on(t, d(this, t, e)), this;
                    }),
                    (i.prototype.prependOnceListener = function (t, e) {
                        return (
                            a(e), this.prependListener(t, d(this, t, e)), this
                        );
                    }),
                    (i.prototype.removeListener = function (t, e) {
                        var o, n, r, i, s;
                        if ((a(e), void 0 === (n = this._events))) return this;
                        if (void 0 === (o = n[t])) return this;
                        if (o === e || o.listener === e)
                            0 === --this._eventsCount
                                ? (this._events = Object.create(null))
                                : (delete n[t],
                                  n.removeListener &&
                                      this.emit(
                                          "removeListener",
                                          t,
                                          o.listener || e
                                      ));
                        else if ("function" != typeof o) {
                            for (r = -1, i = o.length - 1; i >= 0; i--)
                                if (o[i] === e || o[i].listener === e) {
                                    (s = o[i].listener), (r = i);
                                    break;
                                }
                            if (r < 0) return this;
                            0 === r
                                ? o.shift()
                                : (function (t, e) {
                                      for (; e + 1 < t.length; e++)
                                          t[e] = t[e + 1];
                                      t.pop();
                                  })(o, r),
                                1 === o.length && (n[t] = o[0]),
                                void 0 !== n.removeListener &&
                                    this.emit("removeListener", t, s || e);
                        }
                        return this;
                    }),
                    (i.prototype.off = i.prototype.removeListener),
                    (i.prototype.removeAllListeners = function (t) {
                        var e, o, n;
                        if (void 0 === (o = this._events)) return this;
                        if (void 0 === o.removeListener)
                            return (
                                0 === arguments.length
                                    ? ((this._events = Object.create(null)),
                                      (this._eventsCount = 0))
                                    : void 0 !== o[t] &&
                                      (0 === --this._eventsCount
                                          ? (this._events = Object.create(null))
                                          : delete o[t]),
                                this
                            );
                        if (0 === arguments.length) {
                            var r,
                                i = Object.keys(o);
                            for (n = 0; n < i.length; ++n)
                                "removeListener" !== (r = i[n]) &&
                                    this.removeAllListeners(r);
                            return (
                                this.removeAllListeners("removeListener"),
                                (this._events = Object.create(null)),
                                (this._eventsCount = 0),
                                this
                            );
                        }
                        if ("function" == typeof (e = o[t]))
                            this.removeListener(t, e);
                        else if (void 0 !== e)
                            for (n = e.length - 1; n >= 0; n--)
                                this.removeListener(t, e[n]);
                        return this;
                    }),
                    (i.prototype.listeners = function (t) {
                        return f(this, t, !0);
                    }),
                    (i.prototype.rawListeners = function (t) {
                        return f(this, t, !1);
                    }),
                    (i.listenerCount = function (t, e) {
                        return "function" == typeof t.listenerCount
                            ? t.listenerCount(e)
                            : p.call(t, e);
                    }),
                    (i.prototype.listenerCount = p),
                    (i.prototype.eventNames = function () {
                        return this._eventsCount > 0 ? e(this._events) : [];
                    });
            },
            263: function (t, e, o) {
                var n = o(682),
                    r = o(799);
                void 0 === r.Tether && (r.Tether = n), (t.exports = n);
            },
            682: function (t, e, o) {
                "use strict";
                function n(t, e) {
                    return (n =
                        Object.setPrototypeOf ||
                        function (t, e) {
                            return (t.__proto__ = e), t;
                        })(t, e);
                }
                function r(t) {
                    if (void 0 === t)
                        throw new ReferenceError(
                            "this hasn't been initialised - super() hasn't been called"
                        );
                    return t;
                }
                function i(t) {
                    return "object" == typeof t;
                }
                function s(t) {
                    return "string" == typeof t;
                }
                function a(t) {
                    return void 0 === t;
                }
                function l(t, e) {
                    e.split(" ").forEach(function (e) {
                        e.trim() && t.classList.add(e);
                    });
                }
                function c(t, e, o) {
                    return (
                        void 0 === t && (t = ""),
                        a(e) || a(e[t])
                            ? o
                                ? o + "-" + t
                                : t
                            : !1 === e[t]
                            ? ""
                            : e[t]
                    );
                }
                function h(t, e) {
                    e.split(" ").forEach(function (e) {
                        e.trim() && t.classList.remove(e);
                    });
                }
                function d(t, e, o) {
                    o.forEach(function (o) {
                        -1 === e.indexOf(o) &&
                            t.classList.contains(o) &&
                            h(t, o);
                    }),
                        e.forEach(function (e) {
                            t.classList.contains(e) || l(t, e);
                        });
                }
                o.r(e);
                var f = [];
                function p(t) {
                    f.push(t);
                }
                function u() {
                    for (var t; (t = f.pop()); ) t();
                }
                var m = null;
                function g(t) {
                    void 0 === t && (t = {});
                    var e = [];
                    return (
                        Array.prototype.push.apply(e, arguments),
                        e.slice(1).forEach(function (e) {
                            if (e)
                                for (var o in e)
                                    ({}).hasOwnProperty.call(e, o) &&
                                        (t[o] = e[o]);
                        }),
                        t
                    );
                }
                function v() {
                    if (m) return m;
                    var t = document.createElement("div");
                    (t.style.width = "100%"), (t.style.height = "200px");
                    var e = document.createElement("div");
                    g(e.style, {
                        position: "absolute",
                        top: 0,
                        left: 0,
                        pointerEvents: "none",
                        visibility: "hidden",
                        width: "200px",
                        height: "150px",
                        overflow: "hidden",
                    }),
                        e.appendChild(t),
                        document.body.appendChild(e);
                    var o = t.offsetWidth;
                    e.style.overflow = "scroll";
                    var n = t.offsetWidth;
                    o === n && (n = e.clientWidth),
                        document.body.removeChild(e);
                    var r = o - n;
                    return (m = { width: r, height: r });
                }
                var b = (function () {
                        var t = 0;
                        return function () {
                            return ++t;
                        };
                    })(),
                    w = {},
                    y = null;
                function C(t, e) {
                    var o;
                    e === document
                        ? ((o = document), (e = document.documentElement))
                        : (o = e.ownerDocument);
                    var n = o.documentElement,
                        r = E(e),
                        i = (function (t) {
                            var e = y;
                            (e && t.contains(e)) ||
                                ((e =
                                    document.createElement("div")).setAttribute(
                                    "data-tether-id",
                                    b()
                                ),
                                g(e.style, {
                                    top: 0,
                                    left: 0,
                                    position: "absolute",
                                }),
                                t.appendChild(e),
                                (y = e));
                            var o = e.getAttribute("data-tether-id");
                            a(w[o]) &&
                                ((w[o] = E(e)),
                                p(function () {
                                    delete w[o];
                                }));
                            return w[o];
                        })(t);
                    return (
                        (r.top -= i.top),
                        (r.left -= i.left),
                        a(r.width) &&
                            (r.width =
                                document.body.scrollWidth - r.left - r.right),
                        a(r.height) &&
                            (r.height =
                                document.body.scrollHeight - r.top - r.bottom),
                        (r.top = r.top - n.clientTop),
                        (r.left = r.left - n.clientLeft),
                        (r.right = o.body.clientWidth - r.width - r.left),
                        (r.bottom = o.body.clientHeight - r.height - r.top),
                        r
                    );
                }
                function E(t) {
                    var e = t.getBoundingClientRect(),
                        o = {};
                    for (var n in e) o[n] = e[n];
                    try {
                        if (t.ownerDocument !== document) {
                            var r = t.ownerDocument.defaultView.frameElement;
                            if (r) {
                                var i = E(r);
                                (o.top += i.top),
                                    (o.bottom += i.top),
                                    (o.left += i.left),
                                    (o.right += i.left);
                            }
                        }
                    } catch (t) {}
                    return o;
                }
                var _ = {
                        position: function (t) {
                            var e = this,
                                o = t.top,
                                n = t.left,
                                r = this.cache("element-bounds", function () {
                                    return C(e.element);
                                }),
                                i = r.height,
                                s = r.width,
                                a = this.getTargetBounds(),
                                l = o + i,
                                h = n + s,
                                f = [];
                            o <= a.bottom &&
                                l >= a.top &&
                                ["left", "right"].forEach(function (t) {
                                    var e = a[t];
                                    (e !== n && e !== h) || f.push(t);
                                }),
                                n <= a.right &&
                                    h >= a.left &&
                                    ["top", "bottom"].forEach(function (t) {
                                        var e = a[t];
                                        (e !== o && e !== l) || f.push(t);
                                    });
                            var u = this.options,
                                m = u.classes,
                                g = u.classPrefix;
                            return (
                                this.all.push(c("abutted", m, g)),
                                ["left", "top", "right", "bottom"].forEach(
                                    function (t) {
                                        e.all.push(
                                            c("abutted", m, g) + "-" + t
                                        );
                                    }
                                ),
                                f.length && this.add.push(c("abutted", m, g)),
                                f.forEach(function (t) {
                                    e.add.push(c("abutted", m, g) + "-" + t);
                                }),
                                p(function () {
                                    !1 !== e.options.addTargetClasses &&
                                        d(e.target, e.add, e.all),
                                        d(e.element, e.add, e.all);
                                }),
                                !0
                            );
                        },
                    },
                    O = ["left", "top", "right", "bottom"];
                var x = {
                        position: function (t) {
                            var e = this,
                                o = t.top,
                                n = t.left,
                                r = t.targetAttachment;
                            if (!this.options.constraints) return !0;
                            var i = this.cache("element-bounds", function () {
                                    return C(e.bodyElement, e.element);
                                }),
                                l = i.height,
                                h = i.width;
                            if (0 === h && 0 === l && !a(this.lastSize)) {
                                var f = this.lastSize;
                                (h = f.width), (l = f.height);
                            }
                            var u = this.cache("target-bounds", function () {
                                    return e.getTargetBounds();
                                }),
                                m = u.height,
                                v = u.width,
                                b = this.options,
                                w = b.classes,
                                y = b.classPrefix,
                                E = (function (t, e, o) {
                                    var n = [
                                        c("pinned", t, e),
                                        c("out-of-bounds", t, e),
                                    ];
                                    return (
                                        o.forEach(function (t) {
                                            var e = t.outOfBoundsClass,
                                                o = t.pinnedClass;
                                            e && n.push(e), o && n.push(o);
                                        }),
                                        n.forEach(function (t) {
                                            [
                                                "left",
                                                "top",
                                                "right",
                                                "bottom",
                                            ].forEach(function (e) {
                                                n.push(t + "-" + e);
                                            });
                                        }),
                                        n
                                    );
                                })(w, y, this.options.constraints),
                                _ = [],
                                x = g({}, r),
                                L = g({}, this.attachment);
                            return (
                                this.options.constraints.forEach(function (t) {
                                    var i,
                                        d,
                                        f = t.to,
                                        p = t.attachment,
                                        u = t.pin;
                                    if (
                                        (a(p) && (p = ""), p.indexOf(" ") >= 0)
                                    ) {
                                        var g = p.split(" ");
                                        (d = g[0]), (i = g[1]);
                                    } else i = d = p;
                                    var b = (function (t, e, o) {
                                        if (!o) return null;
                                        if (
                                            ("scrollParent" === o
                                                ? (o = e.scrollParents[0])
                                                : "window" === o &&
                                                  (o = [
                                                      pageXOffset,
                                                      pageYOffset,
                                                      innerWidth + pageXOffset,
                                                      innerHeight + pageYOffset,
                                                  ]),
                                            o === document &&
                                                (o = o.documentElement),
                                            !a(o.nodeType))
                                        ) {
                                            var n = o,
                                                r = C(t, o),
                                                i = r,
                                                s = getComputedStyle(o);
                                            if (
                                                ((o = [
                                                    i.left,
                                                    i.top,
                                                    r.width + i.left,
                                                    r.height + i.top,
                                                ]),
                                                n.ownerDocument !== document)
                                            ) {
                                                var l =
                                                    n.ownerDocument.defaultView;
                                                (o[0] += l.pageXOffset),
                                                    (o[1] += l.pageYOffset),
                                                    (o[2] += l.pageXOffset),
                                                    (o[3] += l.pageYOffset);
                                            }
                                            O.forEach(function (t, e) {
                                                "Top" ===
                                                    (t =
                                                        t[0].toUpperCase() +
                                                        t.substr(1)) ||
                                                "Left" === t
                                                    ? (o[e] += parseFloat(
                                                          s[
                                                              "border" +
                                                                  t +
                                                                  "Width"
                                                          ]
                                                      ))
                                                    : (o[e] -= parseFloat(
                                                          s[
                                                              "border" +
                                                                  t +
                                                                  "Width"
                                                          ]
                                                      ));
                                            });
                                        }
                                        return o;
                                    })(e.bodyElement, e, f);
                                    ("target" !== d && "both" !== d) ||
                                        (o < b[1] &&
                                            "top" === x.top &&
                                            ((o += m), (x.top = "bottom")),
                                        o + l > b[3] &&
                                            "bottom" === x.top &&
                                            ((o -= m), (x.top = "top"))),
                                        "together" === d &&
                                            (o = (function (t, e, o, n, r, i) {
                                                return (
                                                    "top" === t.top &&
                                                        ("bottom" === e.top &&
                                                        i < o[1]
                                                            ? ((i += r),
                                                              (t.top =
                                                                  "bottom"),
                                                              (i += n),
                                                              (e.top = "top"))
                                                            : "top" === e.top &&
                                                              i + n > o[3] &&
                                                              i - (n - r) >=
                                                                  o[1] &&
                                                              ((i -= n - r),
                                                              (t.top =
                                                                  "bottom"),
                                                              (e.top =
                                                                  "bottom"))),
                                                    "bottom" === t.top &&
                                                        ("top" === e.top &&
                                                        i + n > o[3]
                                                            ? ((i -= r),
                                                              (t.top = "top"),
                                                              (i -= n),
                                                              (e.top =
                                                                  "bottom"))
                                                            : "bottom" ===
                                                                  e.top &&
                                                              i < o[1] &&
                                                              i + (2 * n - r) <=
                                                                  o[3] &&
                                                              ((i += n - r),
                                                              (t.top = "top"),
                                                              (e.top = "top"))),
                                                    "middle" === t.top &&
                                                        (i + n > o[3] &&
                                                        "top" === e.top
                                                            ? ((i -= n),
                                                              (e.top =
                                                                  "bottom"))
                                                            : i < o[1] &&
                                                              "bottom" ===
                                                                  e.top &&
                                                              ((i += n),
                                                              (e.top = "top"))),
                                                    i
                                                );
                                            })(x, L, b, l, m, o)),
                                        ("target" !== i && "both" !== i) ||
                                            (n < b[0] &&
                                                "left" === x.left &&
                                                ((n += v), (x.left = "right")),
                                            n + h > b[2] &&
                                                "right" === x.left &&
                                                ((n -= v), (x.left = "left"))),
                                        "together" === i &&
                                            (n = (function (t, e, o, n, r, i) {
                                                return (
                                                    i < o[0] &&
                                                    "left" === t.left
                                                        ? "right" === e.left
                                                            ? ((i += r),
                                                              (t.left =
                                                                  "right"),
                                                              (i += n),
                                                              (e.left = "left"))
                                                            : "left" ===
                                                                  e.left &&
                                                              ((i += r),
                                                              (t.left =
                                                                  "right"),
                                                              (i -= n),
                                                              (e.left =
                                                                  "right"))
                                                        : i + n > o[2] &&
                                                          "right" === t.left
                                                        ? "left" === e.left
                                                            ? ((i -= r),
                                                              (t.left = "left"),
                                                              (i -= n),
                                                              (e.left =
                                                                  "right"))
                                                            : "right" ===
                                                                  e.left &&
                                                              ((i -= r),
                                                              (t.left = "left"),
                                                              (i += n),
                                                              (e.left = "left"))
                                                        : "center" === t.left &&
                                                          (i + n > o[2] &&
                                                          "left" === e.left
                                                              ? ((i -= n),
                                                                (e.left =
                                                                    "right"))
                                                              : i < o[0] &&
                                                                "right" ===
                                                                    e.left &&
                                                                ((i += n),
                                                                (e.left =
                                                                    "left"))),
                                                    i
                                                );
                                            })(x, L, b, h, v, n)),
                                        ("element" !== d && "both" !== d) ||
                                            (o < b[1] &&
                                                "bottom" === L.top &&
                                                ((o += l), (L.top = "top")),
                                            o + l > b[3] &&
                                                "top" === L.top &&
                                                ((o -= l), (L.top = "bottom"))),
                                        ("element" !== i && "both" !== i) ||
                                            (n < b[0] &&
                                                ("right" === L.left
                                                    ? ((n += h),
                                                      (L.left = "left"))
                                                    : "center" === L.left &&
                                                      ((n += h / 2),
                                                      (L.left = "left"))),
                                            n + h > b[2] &&
                                                ("left" === L.left
                                                    ? ((n -= h),
                                                      (L.left = "right"))
                                                    : "center" === L.left &&
                                                      ((n -= h / 2),
                                                      (L.left = "right")))),
                                        s(u)
                                            ? (u = u
                                                  .split(",")
                                                  .map(function (t) {
                                                      return t.trim();
                                                  }))
                                            : !0 === u &&
                                              (u = [
                                                  "top",
                                                  "left",
                                                  "right",
                                                  "bottom",
                                              ]);
                                    var E,
                                        j = [],
                                        S = [];
                                    ((n = (function (t, e, o, n, r, i) {
                                        return (
                                            t < e[0] &&
                                                (n.indexOf("left") >= 0
                                                    ? ((t = e[0]),
                                                      r.push("left"))
                                                    : i.push("left")),
                                            t + o > e[2] &&
                                                (n.indexOf("right") >= 0
                                                    ? ((t = e[2] - o),
                                                      r.push("right"))
                                                    : i.push("right")),
                                            t
                                        );
                                    })(n, b, h, (u = u || []), j, S)),
                                    (o = (function (t, e, o, n, r, i) {
                                        return (
                                            t < e[1] &&
                                                (n.indexOf("top") >= 0
                                                    ? ((t = e[1]),
                                                      r.push("top"))
                                                    : i.push("top")),
                                            t + o > e[3] &&
                                                (n.indexOf("bottom") >= 0
                                                    ? ((t = e[3] - o),
                                                      r.push("bottom"))
                                                    : i.push("bottom")),
                                            t
                                        );
                                    })(o, b, l, u, j, S)),
                                    j.length) &&
                                        ((E = a(e.options.pinnedClass)
                                            ? c("pinned", w, y)
                                            : e.options.pinnedClass),
                                        _.push(E),
                                        j.forEach(function (t) {
                                            _.push(E + "-" + t);
                                        }));
                                    !(function (t, e, o, n, r) {
                                        var i;
                                        t.length &&
                                            ((i = a(r)
                                                ? c("out-of-bounds", o, n)
                                                : r),
                                            e.push(i),
                                            t.forEach(function (t) {
                                                e.push(i + "-" + t);
                                            }));
                                    })(S, _, w, y, e.options.outOfBoundsClass),
                                        (j.indexOf("left") >= 0 ||
                                            j.indexOf("right") >= 0) &&
                                            (L.left = x.left = !1),
                                        (j.indexOf("top") >= 0 ||
                                            j.indexOf("bottom") >= 0) &&
                                            (L.top = x.top = !1),
                                        (x.top === r.top &&
                                            x.left === r.left &&
                                            L.top === e.attachment.top &&
                                            L.left === e.attachment.left) ||
                                            (e.updateAttachClasses(L, x),
                                            e.trigger("update", {
                                                attachment: L,
                                                targetAttachment: x,
                                            }));
                                }),
                                p(function () {
                                    !1 !== e.options.addTargetClasses &&
                                        d(e.target, _, E),
                                        d(e.element, _, E);
                                }),
                                { top: o, left: n }
                            );
                        },
                    },
                    L = {
                        position: function (t) {
                            var e = t.top,
                                o = t.left;
                            if (this.options.shift) {
                                var n,
                                    r,
                                    i = this.options.shift;
                                if (
                                    ("function" == typeof i &&
                                        (i = i.call(this, { top: e, left: o })),
                                    s(i))
                                ) {
                                    (i = i.split(" "))[1] = i[1] || i[0];
                                    var a = i;
                                    (n = a[0]),
                                        (r = a[1]),
                                        (n = parseFloat(n, 10)),
                                        (r = parseFloat(r, 10));
                                } else {
                                    var l = [i.top, i.left];
                                    (n = l[0]), (r = l[1]);
                                }
                                return { top: (e += n), left: (o += r) };
                            }
                        },
                    },
                    j = (function () {
                        function t() {}
                        var e = t.prototype;
                        return (
                            (e.on = function (t, e, o, n) {
                                return (
                                    void 0 === n && (n = !1),
                                    a(this.bindings) && (this.bindings = {}),
                                    a(this.bindings[t]) &&
                                        (this.bindings[t] = []),
                                    this.bindings[t].push({
                                        handler: e,
                                        ctx: o,
                                        once: n,
                                    }),
                                    this
                                );
                            }),
                            (e.once = function (t, e, o) {
                                return this.on(t, e, o, !0);
                            }),
                            (e.off = function (t, e) {
                                var o = this;
                                return (
                                    a(this.bindings) ||
                                        a(this.bindings[t]) ||
                                        (a(e)
                                            ? delete this.bindings[t]
                                            : this.bindings[t].forEach(
                                                  function (n, r) {
                                                      n.handler === e &&
                                                          o.bindings[t].splice(
                                                              r,
                                                              1
                                                          );
                                                  }
                                              )),
                                    this
                                );
                            }),
                            (e.trigger = function (t) {
                                for (
                                    var e = this,
                                        o = arguments.length,
                                        n = new Array(o > 1 ? o - 1 : 0),
                                        r = 1;
                                    r < o;
                                    r++
                                )
                                    n[r - 1] = arguments[r];
                                return (
                                    !a(this.bindings) &&
                                        this.bindings[t] &&
                                        this.bindings[t].forEach(function (
                                            o,
                                            r
                                        ) {
                                            var i = o.ctx,
                                                s = o.handler,
                                                a = o.once,
                                                l = i || e;
                                            s.apply(l, n),
                                                a && e.bindings[t].splice(r, 1);
                                        }),
                                    this
                                );
                            }),
                            t
                        );
                    })(),
                    S = { center: "center", left: "right", right: "left" },
                    T = { middle: "middle", top: "bottom", bottom: "top" },
                    k = {
                        top: 0,
                        left: 0,
                        middle: "50%",
                        center: "50%",
                        bottom: "100%",
                        right: "100%",
                    };
                function P() {
                    for (
                        var t = { top: 0, left: 0 },
                            e = arguments.length,
                            o = new Array(e),
                            n = 0;
                        n < e;
                        n++
                    )
                        o[n] = arguments[n];
                    return (
                        o.forEach(function (e) {
                            var o = e.top,
                                n = e.left;
                            s(o) && (o = parseFloat(o)),
                                s(n) && (n = parseFloat(n)),
                                (t.top += o),
                                (t.left += n);
                        }),
                        t
                    );
                }
                function F(t) {
                    var e = t.left,
                        o = t.top;
                    return (
                        a(k[t.left]) || (e = k[t.left]),
                        a(k[t.top]) || (o = k[t.top]),
                        { left: e, top: o }
                    );
                }
                function W(t, e) {
                    return (
                        s(t.left) &&
                            -1 !== t.left.indexOf("%") &&
                            (t.left = (parseFloat(t.left) / 100) * e.width),
                        s(t.top) &&
                            -1 !== t.top.indexOf("%") &&
                            (t.top = (parseFloat(t.top) / 100) * e.height),
                        t
                    );
                }
                function M(t) {
                    var e = t.split(" ");
                    return { top: e[0], left: e[1] };
                }
                function A(t) {
                    return t.offsetParent || document.documentElement;
                }
                var z = { modules: [x, _, L] };
                function q(t) {
                    var e = t.ownerDocument;
                    return (
                        (e.fullscreenElement ||
                            e.webkitFullscreenElement ||
                            e.mozFullScreenElement ||
                            e.msFullscreenElement) === t
                    );
                }
                function D(t, e, o) {
                    return void 0 === o && (o = 1), t + o >= e && e >= t - o;
                }
                var N,
                    R,
                    H,
                    Y,
                    B = (function () {
                        if (a(document)) return "";
                        for (
                            var t = document.createElement("div"),
                                e = [
                                    "transform",
                                    "WebkitTransform",
                                    "OTransform",
                                    "MozTransform",
                                    "msTransform",
                                ],
                                o = 0;
                            o < e.length;
                            ++o
                        ) {
                            var n = e[o];
                            if (void 0 !== t.style[n]) return n;
                        }
                    })(),
                    X = [],
                    U = function () {
                        X.forEach(function (t) {
                            t.position(!1);
                        }),
                            u();
                    };
                function $() {
                    return performance.now();
                }
                (N = null),
                    (R = null),
                    (H = null),
                    (Y = function t() {
                        if (!a(R) && R > 16)
                            return (
                                (R = Math.min(R - 16, 250)),
                                void (H = setTimeout(t, 250))
                            );
                        (!a(N) && $() - N < 10) ||
                            (null != H && (clearTimeout(H), (H = null)),
                            (N = $()),
                            U(),
                            (R = $() - N));
                    }),
                    a(window) ||
                        a(window.addEventListener) ||
                        ["resize", "scroll", "touchmove"].forEach(function (t) {
                            window.addEventListener(t, Y);
                        });
                var I = (function (t) {
                    var e, o;
                    function f(e) {
                        var o;
                        return (
                            ((o = t.call(this) || this).position =
                                o.position.bind(r(o))),
                            X.push(r(o)),
                            (o.history = []),
                            o.setOptions(e, !1),
                            z.modules.forEach(function (t) {
                                a(t.initialize) || t.initialize.call(r(o));
                            }),
                            o.position(),
                            o
                        );
                    }
                    (o = t),
                        ((e = f).prototype = Object.create(o.prototype)),
                        (e.prototype.constructor = e),
                        n(e, o);
                    var m = f.prototype;
                    return (
                        (m.setOptions = function (t, e) {
                            var o = this;
                            void 0 === e && (e = !0);
                            var n = {
                                offset: "0 0",
                                targetOffset: "0 0",
                                targetAttachment: "auto auto",
                                classPrefix: "tether",
                                bodyElement: document.body,
                            };
                            this.options = g(n, t);
                            var r = this.options,
                                i = r.element,
                                l = r.target,
                                c = r.targetModifier,
                                h = r.bodyElement;
                            if (
                                ((this.element = i),
                                (this.target = l),
                                (this.targetModifier = c),
                                "string" == typeof h &&
                                    (h = document.querySelector(h)),
                                (this.bodyElement = h),
                                "viewport" === this.target
                                    ? ((this.target = document.body),
                                      (this.targetModifier = "visible"))
                                    : "scroll-handle" === this.target &&
                                      ((this.target = document.body),
                                      (this.targetModifier = "scroll-handle")),
                                ["element", "target"].forEach(function (t) {
                                    if (a(o[t]))
                                        throw new Error(
                                            "Tether Error: Both element and target must be defined"
                                        );
                                    a(o[t].jquery)
                                        ? s(o[t]) &&
                                          (o[t] = document.querySelector(o[t]))
                                        : (o[t] = o[t][0]);
                                }),
                                this._addClasses(),
                                !this.options.attachment)
                            )
                                throw new Error(
                                    "Tether Error: You must provide an attachment"
                                );
                            (this.targetAttachment = M(
                                this.options.targetAttachment
                            )),
                                (this.attachment = M(this.options.attachment)),
                                (this.offset = M(this.options.offset)),
                                (this.targetOffset = M(
                                    this.options.targetOffset
                                )),
                                a(this.scrollParents) || this.disable(),
                                "scroll-handle" === this.targetModifier
                                    ? (this.scrollParents = [this.target])
                                    : (this.scrollParents = (function (t) {
                                          var e = (getComputedStyle(t) || {})
                                                  .position,
                                              o = [];
                                          if ("fixed" === e) return [t];
                                          for (
                                              var n = t;
                                              (n = n.parentNode) &&
                                              n &&
                                              1 === n.nodeType;

                                          ) {
                                              var r = void 0;
                                              try {
                                                  r = getComputedStyle(n);
                                              } catch (t) {}
                                              if (a(r) || null === r)
                                                  return o.push(n), o;
                                              var i = r,
                                                  s = i.overflow,
                                                  l = i.overflowX,
                                                  c = i.overflowY;
                                              /(auto|scroll|overlay)/.test(
                                                  s + c + l
                                              ) &&
                                                  ("absolute" !== e ||
                                                      [
                                                          "relative",
                                                          "absolute",
                                                          "fixed",
                                                      ].indexOf(r.position) >=
                                                          0) &&
                                                  o.push(n);
                                          }
                                          return (
                                              o.push(t.ownerDocument.body),
                                              t.ownerDocument !== document &&
                                                  o.push(
                                                      t.ownerDocument
                                                          .defaultView
                                                  ),
                                              o
                                          );
                                      })(this.target)),
                                !1 !== this.options.enabled && this.enable(e);
                        }),
                        (m.getTargetBounds = function () {
                            return a(this.targetModifier)
                                ? C(this.bodyElement, this.target)
                                : "visible" === this.targetModifier
                                ? (function (t, e) {
                                      if (e === document.body)
                                          return {
                                              top: pageYOffset,
                                              left: pageXOffset,
                                              height: innerHeight,
                                              width: innerWidth,
                                          };
                                      var o = C(t, e),
                                          n = {
                                              height: o.height,
                                              width: o.width,
                                              top: o.top,
                                              left: o.left,
                                          };
                                      return (
                                          (n.height = Math.min(
                                              n.height,
                                              o.height - (pageYOffset - o.top)
                                          )),
                                          (n.height = Math.min(
                                              n.height,
                                              o.height -
                                                  (o.top +
                                                      o.height -
                                                      (pageYOffset +
                                                          innerHeight))
                                          )),
                                          (n.height = Math.min(
                                              innerHeight,
                                              n.height
                                          )),
                                          (n.height -= 2),
                                          (n.width = Math.min(
                                              n.width,
                                              o.width - (pageXOffset - o.left)
                                          )),
                                          (n.width = Math.min(
                                              n.width,
                                              o.width -
                                                  (o.left +
                                                      o.width -
                                                      (pageXOffset +
                                                          innerWidth))
                                          )),
                                          (n.width = Math.min(
                                              innerWidth,
                                              n.width
                                          )),
                                          (n.width -= 2),
                                          n.top < pageYOffset &&
                                              (n.top = pageYOffset),
                                          n.left < pageXOffset &&
                                              (n.left = pageXOffset),
                                          n
                                      );
                                  })(this.bodyElement, this.target)
                                : "scroll-handle" === this.targetModifier
                                ? (function (t, e) {
                                      var o,
                                          n = e.scrollTop,
                                          r = e === document.body;
                                      r
                                          ? ((e = document.documentElement),
                                            (o = {
                                                left: pageXOffset,
                                                top: pageYOffset,
                                                height: innerHeight,
                                                width: innerWidth,
                                            }))
                                          : (o = C(t, e));
                                      var i = getComputedStyle(e),
                                          s = 0;
                                      (e.scrollWidth > e.clientWidth ||
                                          [i.overflow, i.overflowX].indexOf(
                                              "scroll"
                                          ) >= 0 ||
                                          !r) &&
                                          (s = 15);
                                      var a =
                                              o.height -
                                              parseFloat(i.borderTopWidth) -
                                              parseFloat(i.borderBottomWidth) -
                                              s,
                                          l = {
                                              width: 15,
                                              height:
                                                  0.975 *
                                                  a *
                                                  (a / e.scrollHeight),
                                              left:
                                                  o.left +
                                                  o.width -
                                                  parseFloat(
                                                      i.borderLeftWidth
                                                  ) -
                                                  15,
                                          },
                                          c = 0;
                                      a < 408 &&
                                          r &&
                                          (c =
                                              -11e-5 * Math.pow(a, 2) -
                                              0.00727 * a +
                                              22.58),
                                          r ||
                                              (l.height = Math.max(
                                                  l.height,
                                                  24
                                              ));
                                      var h = n / (e.scrollHeight - a);
                                      return (
                                          (l.top =
                                              h * (a - l.height - c) +
                                              o.top +
                                              parseFloat(i.borderTopWidth)),
                                          r &&
                                              (l.height = Math.max(
                                                  l.height,
                                                  24
                                              )),
                                          l
                                      );
                                  })(this.bodyElement, this.target)
                                : void 0;
                        }),
                        (m.clearCache = function () {
                            this._cache = {};
                        }),
                        (m.cache = function (t, e) {
                            return (
                                a(this._cache) && (this._cache = {}),
                                a(this._cache[t]) &&
                                    (this._cache[t] = e.call(this)),
                                this._cache[t]
                            );
                        }),
                        (m.enable = function (t) {
                            var e = this;
                            void 0 === t && (t = !0);
                            var o = this.options,
                                n = o.classes,
                                r = o.classPrefix;
                            !1 !== this.options.addTargetClasses &&
                                l(this.target, c("enabled", n, r)),
                                l(this.element, c("enabled", n, r)),
                                (this.enabled = !0),
                                this.scrollParents.forEach(function (t) {
                                    t !== e.target.ownerDocument &&
                                        t.addEventListener(
                                            "scroll",
                                            e.position
                                        );
                                }),
                                t && this.position();
                        }),
                        (m.disable = function () {
                            var t = this,
                                e = this.options,
                                o = e.classes,
                                n = e.classPrefix;
                            h(this.target, c("enabled", o, n)),
                                h(this.element, c("enabled", o, n)),
                                (this.enabled = !1),
                                a(this.scrollParents) ||
                                    this.scrollParents.forEach(function (e) {
                                        e &&
                                            e.removeEventListener &&
                                            e.removeEventListener(
                                                "scroll",
                                                t.position
                                            );
                                    });
                        }),
                        (m.destroy = function () {
                            var t,
                                e = this;
                            this.disable(),
                                this._removeClasses(),
                                X.forEach(function (t, o) {
                                    t === e && X.splice(o, 1);
                                }),
                                0 === X.length &&
                                    ((t = this.bodyElement),
                                    y && t.removeChild(y),
                                    (y = null));
                        }),
                        (m.updateAttachClasses = function (t, e) {
                            var o = this;
                            (t = t || this.attachment),
                                (e = e || this.targetAttachment);
                            var n = this.options,
                                r = n.classes,
                                i = n.classPrefix;
                            !a(this._addAttachClasses) &&
                                this._addAttachClasses.length &&
                                this._addAttachClasses.splice(
                                    0,
                                    this._addAttachClasses.length
                                ),
                                a(this._addAttachClasses) &&
                                    (this._addAttachClasses = []),
                                (this.add = this._addAttachClasses),
                                t.top &&
                                    this.add.push(
                                        c("element-attached", r, i) +
                                            "-" +
                                            t.top
                                    ),
                                t.left &&
                                    this.add.push(
                                        c("element-attached", r, i) +
                                            "-" +
                                            t.left
                                    ),
                                e.top &&
                                    this.add.push(
                                        c("target-attached", r, i) + "-" + e.top
                                    ),
                                e.left &&
                                    this.add.push(
                                        c("target-attached", r, i) +
                                            "-" +
                                            e.left
                                    ),
                                (this.all = []),
                                [
                                    "left",
                                    "top",
                                    "bottom",
                                    "right",
                                    "middle",
                                    "center",
                                ].forEach(function (t) {
                                    o.all.push(
                                        c("element-attached", r, i) + "-" + t
                                    ),
                                        o.all.push(
                                            c("target-attached", r, i) + "-" + t
                                        );
                                }),
                                p(function () {
                                    a(o._addAttachClasses) ||
                                        (d(
                                            o.element,
                                            o._addAttachClasses,
                                            o.all
                                        ),
                                        !1 !== o.options.addTargetClasses &&
                                            d(
                                                o.target,
                                                o._addAttachClasses,
                                                o.all
                                            ),
                                        delete o._addAttachClasses);
                                });
                        }),
                        (m.position = function (t) {
                            var e = this;
                            if ((void 0 === t && (t = !0), this.enabled)) {
                                this.clearCache();
                                var o = (function (t, e) {
                                    var o = t.left,
                                        n = t.top;
                                    return (
                                        "auto" === o && (o = S[e.left]),
                                        "auto" === n && (n = T[e.top]),
                                        { left: o, top: n }
                                    );
                                })(this.targetAttachment, this.attachment);
                                this.updateAttachClasses(this.attachment, o);
                                var n = this.cache(
                                        "element-bounds",
                                        function () {
                                            return C(e.bodyElement, e.element);
                                        }
                                    ),
                                    r = n.width,
                                    s = n.height;
                                if (0 !== r || 0 !== s || a(this.lastSize))
                                    this.lastSize = { width: r, height: s };
                                else {
                                    var l = this.lastSize;
                                    (r = l.width), (s = l.height);
                                }
                                var c = this.cache(
                                        "target-bounds",
                                        function () {
                                            return e.getTargetBounds();
                                        }
                                    ),
                                    h = c,
                                    d = W(F(this.attachment), {
                                        width: r,
                                        height: s,
                                    }),
                                    f = W(F(o), h),
                                    p = W(this.offset, { width: r, height: s }),
                                    m = W(this.targetOffset, h);
                                (d = P(d, p)), (f = P(f, m));
                                for (
                                    var g = c.left + f.left - d.left,
                                        b = c.top + f.top - d.top,
                                        w = 0;
                                    w < z.modules.length;
                                    ++w
                                ) {
                                    var y = z.modules[w].position.call(this, {
                                        left: g,
                                        top: b,
                                        targetAttachment: o,
                                        targetPos: c,
                                        elementPos: n,
                                        offset: d,
                                        targetOffset: f,
                                        manualOffset: p,
                                        manualTargetOffset: m,
                                        scrollbarSize: E,
                                        attachment: this.attachment,
                                    });
                                    if (!1 === y) return !1;
                                    !a(y) &&
                                        i(y) &&
                                        ((b = y.top), (g = y.left));
                                }
                                var E,
                                    _ = {
                                        page: { top: b, left: g },
                                        viewport: {
                                            top: b - pageYOffset,
                                            bottom:
                                                pageYOffset -
                                                b -
                                                s +
                                                innerHeight,
                                            left: g - pageXOffset,
                                            right:
                                                pageXOffset -
                                                g -
                                                r +
                                                innerWidth,
                                        },
                                    },
                                    O = this.target.ownerDocument,
                                    x = O.defaultView;
                                if (
                                    (x.innerHeight >
                                        O.documentElement.clientHeight &&
                                        ((E = this.cache("scrollbar-size", v)),
                                        (_.viewport.bottom -= E.height)),
                                    x.innerWidth >
                                        O.documentElement.clientWidth &&
                                        ((E = this.cache("scrollbar-size", v)),
                                        (_.viewport.right -= E.width)),
                                    (-1 !==
                                        ["", "static"].indexOf(
                                            O.body.style.position
                                        ) &&
                                        -1 !==
                                            ["", "static"].indexOf(
                                                O.body.parentElement.style
                                                    .position
                                            )) ||
                                        ((_.page.bottom =
                                            O.body.scrollHeight - b - s),
                                        (_.page.right =
                                            O.body.scrollWidth - g - r)),
                                    !a(this.options.optimizations) &&
                                        !1 !==
                                            this.options.optimizations
                                                .moveElement &&
                                        a(this.targetModifier))
                                ) {
                                    var L = this.cache(
                                            "target-offsetparent",
                                            function () {
                                                return A(e.target);
                                            }
                                        ),
                                        j = this.cache(
                                            "target-offsetparent-bounds",
                                            function () {
                                                return C(e.bodyElement, L);
                                            }
                                        ),
                                        k = getComputedStyle(L),
                                        M = j,
                                        q = {};
                                    if (
                                        ([
                                            "Top",
                                            "Left",
                                            "Bottom",
                                            "Right",
                                        ].forEach(function (t) {
                                            q[t.toLowerCase()] = parseFloat(
                                                k["border" + t + "Width"]
                                            );
                                        }),
                                        (j.right =
                                            O.body.scrollWidth -
                                            j.left -
                                            M.width +
                                            q.right),
                                        (j.bottom =
                                            O.body.scrollHeight -
                                            j.top -
                                            M.height +
                                            q.bottom),
                                        _.page.top >= j.top + q.top &&
                                            _.page.bottom >= j.bottom &&
                                            _.page.left >= j.left + q.left &&
                                            _.page.right >= j.right)
                                    ) {
                                        var D = L.scrollLeft,
                                            N = L.scrollTop;
                                        _.offset = {
                                            top: _.page.top - j.top + N - q.top,
                                            left:
                                                _.page.left -
                                                j.left +
                                                D -
                                                q.left,
                                        };
                                    }
                                }
                                return (
                                    this.move(_),
                                    this.history.unshift(_),
                                    this.history.length > 3 &&
                                        this.history.pop(),
                                    t && u(),
                                    !0
                                );
                            }
                        }),
                        (m.move = function (t) {
                            var e = this;
                            if (!a(this.element.parentNode)) {
                                var o = {};
                                for (var n in t)
                                    for (var r in ((o[n] = {}), t[n])) {
                                        for (
                                            var i = !1, s = 0;
                                            s < this.history.length;
                                            ++s
                                        ) {
                                            var l = this.history[s];
                                            if (
                                                !a(l[n]) &&
                                                !D(l[n][r], t[n][r])
                                            ) {
                                                i = !0;
                                                break;
                                            }
                                        }
                                        i || (o[n][r] = !0);
                                    }
                                var c = {
                                        top: "",
                                        left: "",
                                        right: "",
                                        bottom: "",
                                    },
                                    h = function (t, o) {
                                        var n, r;
                                        !1 !==
                                        (!a(e.options.optimizations)
                                            ? e.options.optimizations.gpu
                                            : null)
                                            ? (t.top
                                                  ? ((c.top = 0), (n = o.top))
                                                  : ((c.bottom = 0),
                                                    (n = -o.bottom)),
                                              t.left
                                                  ? ((c.left = 0), (r = o.left))
                                                  : ((c.right = 0),
                                                    (r = -o.right)),
                                              "number" ==
                                                  typeof window.devicePixelRatio &&
                                                  devicePixelRatio % 1 == 0 &&
                                                  ((r =
                                                      Math.round(
                                                          r * devicePixelRatio
                                                      ) / devicePixelRatio),
                                                  (n =
                                                      Math.round(
                                                          n * devicePixelRatio
                                                      ) / devicePixelRatio)),
                                              (c[B] =
                                                  "translateX(" +
                                                  r +
                                                  "px) translateY(" +
                                                  n +
                                                  "px)"),
                                              "msTransform" !== B &&
                                                  (c[B] += " translateZ(0)"))
                                            : (t.top
                                                  ? (c.top = o.top + "px")
                                                  : (c.bottom =
                                                        o.bottom + "px"),
                                              t.left
                                                  ? (c.left = o.left + "px")
                                                  : (c.right = o.right + "px"));
                                    },
                                    d = !0;
                                !a(this.options.optimizations) &&
                                    !1 ===
                                        this.options.optimizations
                                            .allowPositionFixed &&
                                    (d = !1);
                                var f = !1;
                                if (
                                    (o.page.top || o.page.bottom) &&
                                    (o.page.left || o.page.right)
                                )
                                    (c.position = "absolute"),
                                        h(o.page, t.page);
                                else if (
                                    d &&
                                    (o.viewport.top || o.viewport.bottom) &&
                                    (o.viewport.left || o.viewport.right)
                                )
                                    (c.position = "fixed"),
                                        h(o.viewport, t.viewport);
                                else if (
                                    !a(o.offset) &&
                                    o.offset.top &&
                                    o.offset.left
                                ) {
                                    c.position = "absolute";
                                    var u = this.cache(
                                        "target-offsetparent",
                                        function () {
                                            return A(e.target);
                                        }
                                    );
                                    A(this.element) !== u &&
                                        p(function () {
                                            e.element.parentNode.removeChild(
                                                e.element
                                            ),
                                                u.appendChild(e.element);
                                        }),
                                        h(o.offset, t.offset),
                                        (f = !0);
                                } else
                                    (c.position = "absolute"),
                                        h({ top: !0, left: !0 }, t.page);
                                if (!f)
                                    if (this.options.bodyElement)
                                        this.element.parentNode !==
                                            this.options.bodyElement &&
                                            this.options.bodyElement.appendChild(
                                                this.element
                                            );
                                    else {
                                        for (
                                            var m = !0,
                                                v = this.element.parentNode;
                                            v &&
                                            1 === v.nodeType &&
                                            "BODY" !== v.tagName &&
                                            !q(v);

                                        ) {
                                            if (
                                                "static" !==
                                                getComputedStyle(v).position
                                            ) {
                                                m = !1;
                                                break;
                                            }
                                            v = v.parentNode;
                                        }
                                        m ||
                                            (this.element.parentNode.removeChild(
                                                this.element
                                            ),
                                            this.element.ownerDocument.body.appendChild(
                                                this.element
                                            ));
                                    }
                                var b = {},
                                    w = !1;
                                for (var y in c) {
                                    var C = c[y];
                                    this.element.style[y] !== C &&
                                        ((w = !0), (b[y] = C));
                                }
                                w &&
                                    p(function () {
                                        g(e.element.style, b),
                                            e.trigger("repositioned");
                                    });
                            }
                        }),
                        (m._addClasses = function () {
                            var t = this.options,
                                e = t.classes,
                                o = t.classPrefix;
                            l(this.element, c("element", e, o)),
                                !1 !== this.options.addTargetClasses &&
                                    l(this.target, c("target", e, o));
                        }),
                        (m._removeClasses = function () {
                            var t = this,
                                e = this.options,
                                o = e.classes,
                                n = e.classPrefix;
                            h(this.element, c("element", o, n)),
                                !1 !== this.options.addTargetClasses &&
                                    h(this.target, c("target", o, n)),
                                this.all.forEach(function (e) {
                                    t.element.classList.remove(e),
                                        t.target.classList.remove(e);
                                });
                        }),
                        f
                    );
                })(j);
                (I.modules = []), (z.position = U);
                var V = g(I, z);
                V.modules.push({
                    initialize: function () {
                        var t = this,
                            e = this.options,
                            o = e.classes,
                            n = e.classPrefix;
                        (this.markers = {}),
                            ["target", "element"].forEach(function (e) {
                                var r = document.createElement("div");
                                r.className = c(e + "-marker", o, n);
                                var i = document.createElement("div");
                                (i.className = c("marker-dot", o, n)),
                                    r.appendChild(i),
                                    t[e].appendChild(r),
                                    (t.markers[e] = { dot: i, el: r });
                            });
                    },
                    position: function (t) {
                        var e = {
                            element: t.manualOffset,
                            target: t.manualTargetOffset,
                        };
                        for (var o in e) {
                            var n = e[o];
                            for (var r in n) {
                                var i,
                                    a = n[r];
                                (!s(a) ||
                                    (-1 === a.indexOf("%") &&
                                        -1 === a.indexOf("px"))) &&
                                    (a += "px"),
                                    this.markers[o] &&
                                        (null == (i = this.markers[o].dot)
                                            ? void 0
                                            : i.style[r]) !== a &&
                                        (this.markers[o].dot.style[r] = a);
                            }
                        }
                        return !0;
                    },
                }),
                    (e.default = V);
            },
            799: function (t, e, o) {
                "use strict";
                t.exports = (function () {
                    if ("object" == typeof globalThis) return globalThis;
                    var t;
                    try {
                        t = this || new Function("return this")();
                    } catch (t) {
                        if ("object" == typeof window) return window;
                        if ("object" == typeof self) return self;
                        if (void 0 !== o.g) return o.g;
                    }
                    return t;
                })();
            },
        },
        e = {};
    function o(n) {
        var r = e[n];
        if (void 0 !== r) return r.exports;
        var i = (e[n] = { exports: {} });
        return t[n](i, i.exports, o), i.exports;
    }
    (o.n = function (t) {
        var e =
            t && t.__esModule
                ? function () {
                      return t.default;
                  }
                : function () {
                      return t;
                  };
        return o.d(e, { a: e }), e;
    }),
        (o.d = function (t, e) {
            for (var n in e)
                o.o(e, n) &&
                    !o.o(t, n) &&
                    Object.defineProperty(t, n, { enumerable: !0, get: e[n] });
        }),
        (o.g = (function () {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")();
            } catch (t) {
                if ("object" == typeof window) return window;
            }
        })()),
        (o.o = function (t, e) {
            return Object.prototype.hasOwnProperty.call(t, e);
        }),
        (o.r = function (t) {
            "undefined" != typeof Symbol &&
                Symbol.toStringTag &&
                Object.defineProperty(t, Symbol.toStringTag, {
                    value: "Module",
                }),
                Object.defineProperty(t, "__esModule", { value: !0 });
        }),
        (function () {
            "use strict";
            o(263);
            var t = prestashop,
                e = o.n(t),
                n = jQuery,
                r = o.n(n);
            let i;
            function s() {
                var t;
                if (!(null == (t = e()) ? void 0 : t.responsive))
                    return void console.warn(
                        "PrestaShop responsive object not found"
                    );
                const o = window.innerWidth;
                (e().responsive.current_width = o),
                    (e().responsive.mobile = o < e().responsive.min_width);
            }
            (e().themeSelectors = {
                product: {
                    tabs: ".tabs .nav-link",
                    activeNavClass: "js-product-nav-active",
                    activeTabClass: "js-product-tab-active",
                    activeTabs:
                        ".tabs .nav-link.active, .js-product-nav-active",
                    imagesModal: ".js-product-images-modal",
                    thumb: ".js-thumb",
                    thumbContainer: ".thumb-container, .js-thumb-container",
                    arrows: ".js-arrows",
                    selected: ".selected, .js-thumb-selected",
                    modalProductCover: ".js-modal-product-cover",
                    cover: ".js-qv-product-cover",
                    customizationModal: ".js-customization-modal",
                },
                listing: {
                    searchFilterToggler:
                        "#search_filter_toggler, .js-search-toggler",
                    searchFiltersWrapper: "#search_filters_wrapper",
                    searchFilterControls: "#search_filter_controls",
                    searchFilters: "#search_filters",
                    activeSearchFilters: "#js-active-search-filters",
                    listTop: "#js-product-list-top",
                    product: ".js-product",
                    list: "#js-product-list",
                    listBottom: "#js-product-list-bottom",
                    listHeader: "#js-product-list-header",
                    searchFiltersClearAll: ".js-search-filters-clear-all",
                    searchLink: ".js-search-link",
                },
                order: {
                    returnForm: "#order-return-form, .js-order-return-form",
                },
                arrowDown: ".arrow-down, .js-arrow-down",
                arrowUp: ".arrow-up, .js-arrow-up",
                clear: ".clear",
                fileInput: ".js-file-input",
                contentWrapper: "#content-wrapper, .js-content-wrapper",
                footer: "#footer, .js-footer",
                modalContent: ".js-modal-content",
                modal: "#modal, .js-checkout-modal",
                touchspin: ".js-touchspin",
                checkout: {
                    termsLink: ".js-terms a",
                    giftCheckbox: ".js-gift-checkbox",
                    imagesLink:
                        ".card-block .cart-summary-products p a, .js-show-details",
                    carrierExtraContent:
                        ".carrier-extra-content, .js-carrier-extra-content",
                    btn: ".checkout a",
                },
                cart: {
                    productLineQty: ".js-cart-line-product-quantity",
                    quickview: ".quickview",
                    touchspin: ".bootstrap-touchspin",
                    promoCode: "#promo-code",
                    displayPromo: ".display-promo",
                    promoCodeButton: ".promo-code-button",
                    discountCode: ".js-discount .code",
                    discountName: "[name=discount_name]",
                    actions:
                        '[data-link-action="delete-from-cart"], [data-link-action="remove-voucher"]',
                },
                notifications: {
                    dangerAlert: "#notifications article.alert-danger",
                    container: "#notifications .notifications-container",
                },
                passwordPolicy: {
                    template: "#password-feedback",
                    hint: ".js-hint-password",
                    container: ".password-strength-feedback",
                    strengthText: ".password-strength-text",
                    requirementScore: ".password-requirements-score",
                    requirementLength: ".password-requirements-length",
                    requirementScoreIcon: ".password-requirements-score i",
                    requirementLengthIcon: ".password-requirements-length i",
                    progressBar: ".progress-bar",
                    inputColumn: ".js-input-column",
                    root: ".field-password-policy",
                },
            }),
                document.addEventListener("DOMContentLoaded", () => {
                    e().emit("themeSelectorsInit");
                }),
                (e().responsive = e().responsive || {}),
                window.addEventListener("resize", () => {
                    clearTimeout(i), (i = setTimeout(s, 100));
                }),
                document.addEventListener("DOMContentLoaded", () => {
                    s();
                });
            class a {
                init() {
                    r()(".js-product-miniature").each((t, e) => {
                        if (r()(e).find(".color").length > 5) {
                            let t = 0;
                            r()(e)
                                .find(".color")
                                .each((e, o) => {
                                    e > 4 && (r()(o).hide(), (t += 1));
                                }),
                                r()(e).find(".js-count").append(`+${t}`);
                        }
                    });
                }
            }
            r()(document).ready(() => {
                const t = (t) => {
                    r()(e().themeSelectors.product.arrows),
                        t.find(".js-qv-product-images");
                    r()(e().themeSelectors.product.thumb).on("click", (t) => {
                        r()(e().themeSelectors.product.thumb).hasClass(
                            "selected"
                        ) &&
                            r()(e().themeSelectors.product.thumb).removeClass(
                                "selected"
                            ),
                            r()(t.currentTarget).addClass("selected"),
                            r()(e().themeSelectors.product.cover).attr(
                                "src",
                                r()(t.target).data("image-large-src")
                            ),
                            r()(e().themeSelectors.product.cover).attr(
                                "alt",
                                r()(t.target).attr("alt")
                            ),
                            r()(e().themeSelectors.product.cover).attr(
                                "title",
                                r()(t.target).attr("title")
                            ),
                            (function (t, e) {
                                if (void 0 === e) return;
                                const o = r()(t).siblings(
                                        'source[type="image/webp"]'
                                    ),
                                    n = r()(t).siblings(
                                        'source[type="image/avif"]'
                                    );
                                void 0 !== e.webp &&
                                    o.length &&
                                    o.attr("srcset", e.webp),
                                    void 0 !== e.avif &&
                                        n.length &&
                                        n.attr("srcset", e.avif);
                            })(
                                r()(e().themeSelectors.product.cover),
                                r()(t.target).data("image-large-sources")
                            );
                    }),
                        t
                            .find(e().selectors.quantityWanted)
                            .TouchSpin({
                                verticalbuttons: !0,
                                verticalupclass: "material-icons touchspin-up",
                                verticaldownclass:
                                    "material-icons touchspin-down",
                                buttondown_class:
                                    "btn btn-touchspin js-touchspin",
                                buttonup_class:
                                    "btn btn-touchspin js-touchspin",
                                min: 1,
                                max: 1e6,
                            }),
                        r()(e().themeSelectors.touchspin).off(
                            "touchstart.touchspin"
                        );
                };
                e().on("clickQuickView", (o) => {
                    const n = {
                        action: "quickview",
                        id_product: o.dataset.idProduct,
                        id_product_attribute: o.dataset.idProductAttribute,
                    };
                    r()
                        .post(e().urls.pages.product, n, null, "json")
                        .then((e) => {
                            r()("body").append(e.quickview_html);
                            const o = r()(
                                `#quickview-modal-${e.product.id}-${e.product.id_product_attribute}`
                            );
                            o.modal("show"),
                                t(o),
                                o.on("hidden.bs.modal", () => {
                                    o.remove();
                                });
                        })
                        .fail((t) => {
                            e().emit("handleError", {
                                eventType: "clickQuickView",
                                resp: t,
                            });
                        });
                }),
                    r()("body").on(
                        "click",
                        e().themeSelectors.listing.searchFilterToggler,
                        () => {
                            r()(
                                e().themeSelectors.listing.searchFiltersWrapper
                            ).removeClass("hidden-sm-down"),
                                r()(e().themeSelectors.contentWrapper).addClass(
                                    "hidden-sm-down"
                                ),
                                r()(e().themeSelectors.footer).addClass(
                                    "hidden-sm-down"
                                );
                        }
                    ),
                    r()(
                        `${e().themeSelectors.listing.searchFilterControls} ${
                            e().themeSelectors.clear
                        }`
                    ).on("click", () => {
                        r()(
                            e().themeSelectors.listing.searchFiltersWrapper
                        ).addClass("hidden-sm-down"),
                            r()(e().themeSelectors.contentWrapper).removeClass(
                                "hidden-sm-down"
                            ),
                            r()(e().themeSelectors.footer).removeClass(
                                "hidden-sm-down"
                            );
                    }),
                    r()(
                        `${e().themeSelectors.listing.searchFilterControls} .ok`
                    ).on("click", () => {
                        r()(
                            e().themeSelectors.listing.searchFiltersWrapper
                        ).addClass("hidden-sm-down"),
                            r()(e().themeSelectors.contentWrapper).removeClass(
                                "hidden-sm-down"
                            ),
                            r()(e().themeSelectors.footer).removeClass(
                                "hidden-sm-down"
                            );
                    });
                const o = function (t) {
                    if (void 0 !== t.target.dataset.searchUrl)
                        return t.target.dataset.searchUrl;
                    if (void 0 === r()(t.target).parent()[0].dataset.searchUrl)
                        throw new Error("Can not parse search URL");
                    return r()(t.target).parent()[0].dataset.searchUrl;
                };
                r()("body").on(
                    "change",
                    `${
                        e().themeSelectors.listing.searchFilters
                    } input[data-search-url]`,
                    (t) => {
                        e().emit("updateFacets", o(t));
                    }
                ),
                    r()("body").on(
                        "click",
                        e().themeSelectors.listing.searchFiltersClearAll,
                        (t) => {
                            e().emit("updateFacets", o(t));
                        }
                    ),
                    r()("body").on(
                        "click",
                        e().themeSelectors.listing.searchLink,
                        (t) => {
                            t.preventDefault(),
                                e().emit(
                                    "updateFacets",
                                    r()(t.target).closest("a").get(0).href
                                );
                        }
                    ),
                    window.addEventListener("popstate", (t) => {
                        t.state &&
                            t.state.current_url &&
                            (window.location.href = t.state.current_url);
                    }),
                    r()("body").on(
                        "change",
                        `${e().themeSelectors.listing.searchFilters} select`,
                        (t) => {
                            const o = r()(t.target).closest("form");
                            e().emit("updateFacets", `?${o.serialize()}`);
                        }
                    ),
                    e().on("updateProductList", (t) => {
                        !(function (t) {
                            r()(
                                e().themeSelectors.listing.searchFilters
                            ).replaceWith(t.rendered_facets),
                                r()(
                                    e().themeSelectors.listing
                                        .activeSearchFilters
                                ).replaceWith(t.rendered_active_filters),
                                r()(
                                    e().themeSelectors.listing.listTop
                                ).replaceWith(t.rendered_products_top);
                            const o = r()(t.rendered_products),
                                n = r()(e().themeSelectors.listing.product);
                            n.length > 0
                                ? n
                                      .removeClass()
                                      .addClass(n.first().attr("class"))
                                : n
                                      .removeClass()
                                      .addClass(o.first().attr("class")),
                                r()(
                                    e().themeSelectors.listing.list
                                ).replaceWith(o),
                                r()(
                                    e().themeSelectors.listing.listBottom
                                ).replaceWith(t.rendered_products_bottom),
                                t.rendered_products_header &&
                                    r()(
                                        e().themeSelectors.listing.listHeader
                                    ).replaceWith(t.rendered_products_header),
                                new a().init();
                        })(t),
                            window.scrollTo(0, 0);
                    });
            });
            var l = o(58),
                c = o.n(l);
            class h {
                constructor(t) {
                    this.el = t;
                }
                init() {
                    this.el.on("show.bs.dropdown", (t, e) => {
                        e
                            ? r()(`#${e}`)
                                  .find(".dropdown-menu")
                                  .first()
                                  .stop(!0, !0)
                                  .slideDown()
                            : r()(t.target)
                                  .find(".dropdown-menu")
                                  .first()
                                  .stop(!0, !0)
                                  .slideDown();
                    }),
                        this.el.on("hide.bs.dropdown", (t, e) => {
                            e
                                ? r()(`#${e}`)
                                      .find(".dropdown-menu")
                                      .first()
                                      .stop(!0, !0)
                                      .slideUp()
                                : r()(t.target)
                                      .find(".dropdown-menu")
                                      .first()
                                      .stop(!0, !0)
                                      .slideUp();
                        }),
                        this.el.find("select.link").each((t, e) => {
                            r()(e).on("change", function () {
                                window.location = r()(this).val();
                            });
                        });
                }
            }
            (e().blockcart = e().blockcart || {}),
                (e().blockcart.showModal = (t) => {
                    function o() {
                        return r()("#blockcart-modal");
                    }
                    let n = o();
                    n.length && n.remove(),
                        r()("body").append(t),
                        (n = o()),
                        n.modal("show").on("hidden.bs.modal", (t) => {
                            e().emit("updateProduct", {
                                reason: t.currentTarget.dataset,
                                event: t,
                            });
                        });
                });
            for (const t in c().prototype) e()[t] = c().prototype[t];
            document.addEventListener("DOMContentLoaded", () => {
                return (
                    (t = null),
                    (e = null),
                    (o = function* () {
                        const t = r()(".js-dropdown");
                        new h(t).init();
                    }),
                    new Promise((n, r) => {
                        var i = (t) => {
                                try {
                                    a(o.next(t));
                                } catch (t) {
                                    r(t);
                                }
                            },
                            s = (t) => {
                                try {
                                    a(o.throw(t));
                                } catch (t) {
                                    r(t);
                                }
                            },
                            a = (t) =>
                                t.done
                                    ? n(t.value)
                                    : Promise.resolve(t.value).then(i, s);
                        a((o = o.apply(t, e)).next());
                    })
                );
                var t, e, o;
            });
        })();
})(); /*! For license information please see front.js.LICENSE.txt */
(() => {
    var e = {
            267: () => {},
            379: (e) => {
                "use strict";
                var t = [];
                function r(e) {
                    for (var r = -1, n = 0; n < t.length; n++)
                        if (t[n].identifier === e) {
                            r = n;
                            break;
                        }
                    return r;
                }
                function n(e, n) {
                    for (var a = {}, o = [], i = 0; i < e.length; i++) {
                        var c = e[i],
                            u = n.base ? c[0] + n.base : c[0],
                            l = a[u] || 0,
                            d = "".concat(u, " ").concat(l);
                        a[u] = l + 1;
                        var p = r(d),
                            f = {
                                css: c[1],
                                media: c[2],
                                sourceMap: c[3],
                                supports: c[4],
                                layer: c[5],
                            };
                        if (-1 !== p) t[p].references++, t[p].updater(f);
                        else {
                            var v = s(f, n);
                            (n.byIndex = i),
                                t.splice(i, 0, {
                                    identifier: d,
                                    updater: v,
                                    references: 1,
                                });
                        }
                        o.push(d);
                    }
                    return o;
                }
                function s(e, t) {
                    var r = t.domAPI(t);
                    return (
                        r.update(e),
                        function (t) {
                            if (t) {
                                if (
                                    t.css === e.css &&
                                    t.media === e.media &&
                                    t.sourceMap === e.sourceMap &&
                                    t.supports === e.supports &&
                                    t.layer === e.layer
                                )
                                    return;
                                r.update((e = t));
                            } else r.remove();
                        }
                    );
                }
                e.exports = function (e, s) {
                    var a = n((e = e || []), (s = s || {}));
                    return function (e) {
                        e = e || [];
                        for (var o = 0; o < a.length; o++) {
                            var i = r(a[o]);
                            t[i].references--;
                        }
                        for (var c = n(e, s), u = 0; u < a.length; u++) {
                            var l = r(a[u]);
                            0 === t[l].references &&
                                (t[l].updater(), t.splice(l, 1));
                        }
                        a = c;
                    };
                };
            },
            569: (e) => {
                "use strict";
                var t = {};
                e.exports = function (e, r) {
                    var n = (function (e) {
                        if (void 0 === t[e]) {
                            var r = document.querySelector(e);
                            if (
                                window.HTMLIFrameElement &&
                                r instanceof window.HTMLIFrameElement
                            )
                                try {
                                    r = r.contentDocument.head;
                                } catch (e) {
                                    r = null;
                                }
                            t[e] = r;
                        }
                        return t[e];
                    })(e);
                    if (!n)
                        throw new Error(
                            "Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid."
                        );
                    n.appendChild(r);
                };
            },
            216: (e) => {
                "use strict";
                e.exports = function (e) {
                    var t = document.createElement("style");
                    return (
                        e.setAttributes(t, e.attributes),
                        e.insert(t, e.options),
                        t
                    );
                };
            },
            565: (e, t, r) => {
                "use strict";
                e.exports = function (e) {
                    var t = r.nc;
                    t && e.setAttribute("nonce", t);
                };
            },
            795: (e) => {
                "use strict";
                e.exports = function (e) {
                    if ("undefined" == typeof document)
                        return {
                            update: function () {},
                            remove: function () {},
                        };
                    var t = e.insertStyleElement(e);
                    return {
                        update: function (r) {
                            !(function (e, t, r) {
                                var n = "";
                                r.supports &&
                                    (n += "@supports (".concat(
                                        r.supports,
                                        ") {"
                                    )),
                                    r.media &&
                                        (n += "@media ".concat(r.media, " {"));
                                var s = void 0 !== r.layer;
                                s &&
                                    (n += "@layer".concat(
                                        r.layer.length > 0
                                            ? " ".concat(r.layer)
                                            : "",
                                        " {"
                                    )),
                                    (n += r.css),
                                    s && (n += "}"),
                                    r.media && (n += "}"),
                                    r.supports && (n += "}");
                                var a = r.sourceMap;
                                a &&
                                    "undefined" != typeof btoa &&
                                    (n +=
                                        "\n/*# sourceMappingURL=data:application/json;base64,".concat(
                                            btoa(
                                                unescape(
                                                    encodeURIComponent(
                                                        JSON.stringify(a)
                                                    )
                                                )
                                            ),
                                            " */"
                                        )),
                                    t.styleTagTransform(n, e, t.options);
                            })(t, e, r);
                        },
                        remove: function () {
                            !(function (e) {
                                if (null === e.parentNode) return !1;
                                e.parentNode.removeChild(e);
                            })(t);
                        },
                    };
                };
            },
            589: (e) => {
                "use strict";
                e.exports = function (e, t) {
                    if (t.styleSheet) t.styleSheet.cssText = e;
                    else {
                        for (; t.firstChild; ) t.removeChild(t.firstChild);
                        t.appendChild(document.createTextNode(e));
                    }
                };
            },
        },
        t = {};
    function r(n) {
        var s = t[n];
        if (void 0 !== s) return s.exports;
        var a = (t[n] = { exports: {} });
        return e[n](a, a.exports, r), a.exports;
    }
    (r.n = (e) => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return r.d(t, { a: t }), t;
    }),
        (r.d = (e, t) => {
            for (var n in t)
                r.o(t, n) &&
                    !r.o(e, n) &&
                    Object.defineProperty(e, n, { enumerable: !0, get: t[n] });
        }),
        (r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
        (r.nc = void 0),
        (() => {
            "use strict";
            var e = r(379),
                t = r.n(e),
                n = r(795),
                s = r.n(n),
                a = r(569),
                o = r.n(a),
                i = r(565),
                c = r.n(i),
                u = r(216),
                l = r.n(u),
                d = r(589),
                p = r.n(d),
                f = r(267),
                v = r.n(f),
                m = {};
            (m.styleTagTransform = p()),
                (m.setAttributes = c()),
                (m.insert = o().bind(null, "head")),
                (m.domAPI = s()),
                (m.insertStyleElement = l()),
                t()(v(), m),
                v() && v().locals && v().locals,
                $(window).ready(() => {
                    const e = $(
                        ".blockreassurance_product img.svg, .blockreassurance img.svg"
                    )
                        .map(function () {
                            return $(this).attr("src");
                        })
                        .toArray();
                    e.filter((t, r) => e.indexOf(t) === r).forEach(function (
                        e
                    ) {
                        const t = $(
                            `.blockreassurance_product img.svg.invisible[src="${e}"], .blockreassurance img.svg.invisible[src="${e}"]`
                        );
                        0 !== t.length &&
                            $.ajax({
                                url: e,
                                type: "GET",
                                success(r) {
                                    if ($.isXMLDoc(r)) {
                                        let n = $(r).find("svg");
                                        (n = n.attr("data-img-url", e)),
                                            (n = n.removeAttr("xmlns:a")),
                                            n
                                                .find("path[fill]")
                                                .attr(
                                                    "fill",
                                                    window.psr_icon_color
                                                ),
                                            n
                                                .find("path:not([fill])")
                                                .css(
                                                    "fill",
                                                    window.psr_icon_color
                                                ),
                                            t.each(function () {
                                                const e = $(this).attr("id"),
                                                    t = $(this).attr("class");
                                                let r = n.clone();
                                                (r =
                                                    void 0 !== e
                                                        ? r.attr("id", e)
                                                        : r),
                                                    (r =
                                                        void 0 !== t
                                                            ? r.attr(
                                                                  "class",
                                                                  `${t} replaced-svg`
                                                              )
                                                            : r.attr(
                                                                  "class",
                                                                  " replaced-svg"
                                                              )),
                                                    r.removeClass("invisible"),
                                                    $(this).replaceWith(r);
                                            });
                                    }
                                },
                            });
                    });
                });
        })();
})();
/**
 * 2007-2020 PrestaShop.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2020 PrestaShop SA
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */
$(document).ready(function () {
    $(".block_newsletter form").on("submit", function () {
        var psemailsubscriptionForm = $(this);
        if (typeof psemailsubscription_subscription === "undefined") {
            return !0;
        }
        $(".block_newsletter_alert").remove();
        $.ajax({
            type: "POST",
            dataType: "JSON",
            url: psemailsubscription_subscription,
            cache: !1,
            data: $(this).serialize(),
            success: function (data) {
                if (data.nw_error) {
                    psemailsubscriptionForm.prepend(
                        '<p class="alert alert-danger block_newsletter_alert">' +
                            data.msg +
                            "</p>"
                    );
                } else {
                    psemailsubscriptionForm.prepend(
                        '<p class="alert alert-success block_newsletter_alert">' +
                            data.msg +
                            "</p>"
                    );
                }
            },
            error: function (err) {
                console.log(err);
            },
        });
        return !1;
    });
});
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
function addNotification(productId, productAttributeId) {
    if (typeof productId === "undefined") {
        var ids = $("div.js-mailalert > input[type=hidden]");
        productId = ids.eq(0).val();
        productIdAttribute = ids.eq(1).val();
    }
    $.ajax({
        type: "POST",
        url: $("div.js-mailalert").data("url"),
        data:
            "id_product=" +
            productId +
            "&id_product_attribute=" +
            productAttributeId +
            "&customer_email=" +
            $("div.js-mailalert input[type=email]").val(),
        success: function (resp) {
            resp = JSON.parse(resp);
            $(".js-mailalert-alerts")
                .html(
                    '<article class="mt-1 alert alert-' +
                        (resp.error ? "danger" : "success") +
                        '" role="alert" data-alert="' +
                        (resp.error ? "error" : "success") +
                        '">' +
                        resp.message +
                        "</article>"
                )
                .show();
            if (!resp.error) {
                $(
                    "div.js-mailalert > .js-mailalert-add, div.js-mailalert > input[type=email], div.js-mailalert .gdpr_consent_wrapper"
                ).hide();
            }
        },
    });
    return !1;
}
$(document).on("ready", function () {
    const mailAlertSubmitButtonClass = ".js-mailalert-add";
    const mailAlertWrapper = $(".js-mailalert");
    const mailAlertSubmitButton = mailAlertWrapper.find(
        mailAlertSubmitButtonClass
    );
    if (mailAlertWrapper.find("#gdpr_consent, .gdpr_consent").length) {
        setTimeout(() => {
            mailAlertSubmitButton.prop("disabled", !0);
            mailAlertWrapper
                .find('[name="psgdpr_consent_checkbox"]')
                .on("change", function (e) {
                    e.stopPropagation();
                    mailAlertSubmitButton.prop(
                        "disabled",
                        !$(this).prop("checked")
                    );
                });
        }, 0);
    }
    $(document).on("click", mailAlertSubmitButtonClass, function (e) {
        e.preventDefault();
        addNotification(
            $(this).data("product"),
            $(this).data("product-attribute")
        );
    });
    $(document).on("click", ".js-remove-email-alert", function () {
        var self = $(this);
        var ids = self.attr("rel").replace("js-id-emailalerts-", "");
        ids = ids.split("-");
        var id_product_mail_alert = ids[0];
        var id_product_attribute_mail_alert = ids[1];
        var parent = self.closest("li");
        $.ajax({
            url: self.data("url"),
            type: "POST",
            data: {
                id_product: id_product_mail_alert,
                id_product_attribute: id_product_attribute_mail_alert,
            },
            success: function (result) {
                if (result == "0") {
                    parent.fadeOut("normal", function () {
                        parent.remove();
                    });
                }
            },
        });
    });
});
/*!
 * Creative Elements - live PageBuilder [in-stock]
 * Copyright 2019-2022 WebshopWorks.com & Elementor.com
 */ !(function (e) {
    var t = {};
    function n(i) {
        if (t[i]) return t[i].exports;
        var r = (t[i] = { i: i, l: !1, exports: {} });
        return e[i].call(r.exports, r, r.exports, n), (r.l = !0), r.exports;
    }
    (n.m = e),
        (n.c = t),
        (n.d = function (e, t, i) {
            n.o(e, t) ||
                Object.defineProperty(e, t, { enumerable: !0, get: i });
        }),
        (n.r = function (e) {
            "undefined" != typeof Symbol &&
                Symbol.toStringTag &&
                Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module",
                }),
                Object.defineProperty(e, "__esModule", { value: !0 });
        }),
        (n.t = function (e, t) {
            if ((1 & t && (e = n(e)), 8 & t)) return e;
            if (4 & t && "object" == typeof e && e && e.__esModule) return e;
            var i = Object.create(null);
            if (
                (n.r(i),
                Object.defineProperty(i, "default", {
                    enumerable: !0,
                    value: e,
                }),
                2 & t && "string" != typeof e)
            )
                for (var r in e)
                    n.d(
                        i,
                        r,
                        function (t) {
                            return e[t];
                        }.bind(null, r)
                    );
            return i;
        }),
        (n.n = function (e) {
            var t =
                e && e.__esModule
                    ? function () {
                          return e.default;
                      }
                    : function () {
                          return e;
                      };
            return n.d(t, "a", t), t;
        }),
        (n.o = function (e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }),
        (n.p = ""),
        n((n.s = 209));
})({
    17: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = (function () {
                function e(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var i = t[n];
                        (i.enumerable = i.enumerable || !1),
                            (i.configurable = !0),
                            "value" in i && (i.writable = !0),
                            Object.defineProperty(e, i.key, i);
                    }
                }
                return function (t, n, i) {
                    return n && e(t.prototype, n), i && e(t, i), t;
                };
            })(),
            r = function e(t, n, i) {
                null === t && (t = Function.prototype);
                var r = Object.getOwnPropertyDescriptor(t, n);
                if (void 0 === r) {
                    var o = Object.getPrototypeOf(t);
                    return null === o ? void 0 : e(o, n, i);
                }
                if ("value" in r) return r.value;
                var s = r.get;
                return void 0 !== s ? s.call(i) : void 0;
            };
        var o = (function (e) {
            function t() {
                return (function (e, t) {
                    if (!e)
                        throw new ReferenceError(
                            "this hasn't been initialised - super() hasn't been called"
                        );
                    return !t ||
                        ("object" != typeof t && "function" != typeof t)
                        ? e
                        : t;
                })(
                    this,
                    (t.__proto__ || Object.getPrototypeOf(t)).apply(
                        this,
                        arguments
                    )
                );
            }
            return (
                (function (e, t) {
                    if ("function" != typeof t && null !== t)
                        throw new TypeError(
                            "Super expression must either be null or a function, not " +
                                typeof t
                        );
                    (e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0,
                        },
                    })),
                        t &&
                            (Object.setPrototypeOf
                                ? Object.setPrototypeOf(e, t)
                                : (e.__proto__ = t));
                })(t, elementorModules.ViewModule),
                i(t, [
                    {
                        key: "getDefaultSettings",
                        value: function () {
                            return {
                                selectors: {
                                    elements: ".elementor-element",
                                    nestedDocumentElements:
                                        ".elementor .elementor-element",
                                },
                                classes: { editMode: "elementor-edit-mode" },
                            };
                        },
                    },
                    {
                        key: "getDefaultElements",
                        value: function () {
                            var e = this.getSettings("selectors");
                            return {
                                $elements: this.$element
                                    .find(e.elements)
                                    .not(
                                        this.$element.find(
                                            e.nestedDocumentElements
                                        )
                                    ),
                            };
                        },
                    },
                    {
                        key: "getDocumentSettings",
                        value: function (e) {
                            var t = void 0;
                            if (this.isEdit) {
                                t = {};
                                var n = elementor.settings.page.model;
                                jQuery.each(
                                    n.getActiveControls(),
                                    function (e) {
                                        t[e] = n.attributes[e];
                                    }
                                );
                            } else
                                t =
                                    this.$element.data("elementor-settings") ||
                                    {};
                            return this.getItems(t, e);
                        },
                    },
                    {
                        key: "runElementsHandlers",
                        value: function () {
                            this.elements.$elements.each(function (e, t) {
                                return ceFrontend.elementsHandler.runReadyTrigger(
                                    t
                                );
                            });
                        },
                    },
                    {
                        key: "onInit",
                        value: function () {
                            (this.$element = this.getSettings("$element")),
                                r(
                                    t.prototype.__proto__ ||
                                        Object.getPrototypeOf(t.prototype),
                                    "onInit",
                                    this
                                ).call(this),
                                (this.isEdit = this.$element.hasClass(
                                    this.getSettings("classes.editMode")
                                )),
                                this.isEdit
                                    ? elementor.settings.page.model.on(
                                          "change",
                                          this.onSettingsChange.bind(this)
                                      )
                                    : this.runElementsHandlers();
                        },
                    },
                    { key: "onSettingsChange", value: function () {} },
                ]),
                t
            );
        })();
        t.default = o;
    },
    19: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = s(n(5)),
            r = s(n(6)),
            o = s(n(20));
        function s(e) {
            return e && e.__esModule ? e : { default: e };
        }
        t.default = window.elementorModules = {
            Module: i.default,
            ViewModule: r.default,
            utils: { Masonry: o.default },
        };
    },
    20: function (e, t, n) {
        "use strict";
        var i,
            r = n(6),
            o = (i = r) && i.__esModule ? i : { default: i };
        e.exports = o.default.extend({
            getDefaultSettings: function () {
                return {
                    container: null,
                    items: null,
                    columnsCount: 3,
                    verticalSpaceBetween: 30,
                };
            },
            getDefaultElements: function () {
                return {
                    $container: jQuery(this.getSettings("container")),
                    $items: jQuery(this.getSettings("items")),
                };
            },
            run: function () {
                var e = [],
                    t = this.elements.$container.position().top,
                    n = this.getSettings(),
                    i = n.columnsCount;
                (t += parseInt(this.elements.$container.css("margin-top"), 10)),
                    this.elements.$items.each(function (r) {
                        var o = Math.floor(r / i),
                            s = jQuery(this),
                            u =
                                s[0].getBoundingClientRect().height +
                                n.verticalSpaceBetween;
                        if (o) {
                            var l = s.position(),
                                c = r % i,
                                a = l.top - t - e[c];
                            (a -= parseInt(s.css("margin-top"), 10)),
                                (a *= -1),
                                s.css("margin-top", a + "px"),
                                (e[c] += u);
                        } else e.push(u);
                    });
            },
        });
    },
    209: function (e, t, n) {
        "use strict";
        var i = u(n(19)),
            r = u(n(17)),
            o = u(n(210)),
            s = u(n(211));
        function u(e) {
            return e && e.__esModule ? e : { default: e };
        }
        i.default.frontend = {
            Document: r.default,
            tools: { StretchElement: o.default },
            handlers: { Base: s.default },
        };
    },
    210: function (e, t, n) {
        "use strict";
        e.exports = elementorModules.ViewModule.extend({
            getDefaultSettings: function () {
                return {
                    element: null,
                    direction: ceFrontend.config.is_rtl ? "right" : "left",
                    selectors: { container: window },
                };
            },
            getDefaultElements: function () {
                return { $element: jQuery(this.getSettings("element")) };
            },
            stretch: function () {
                if (this.elements.$element.length) {
                    var e,
                        t = this.getSettings("selectors.container");
                    try {
                        e = jQuery(t);
                    } catch (e) {}
                    (e && e.length) ||
                        (e = jQuery(
                            this.getDefaultSettings().selectors.container
                        )),
                        this.reset();
                    var n = this.elements.$element,
                        i = e.outerWidth(),
                        r = n.offset().left,
                        o = "fixed" === n.css("position"),
                        s = o ? 0 : r;
                    if (window !== e[0]) {
                        var u = e.offset().left;
                        o && (s = u), r > u && (s = r - u);
                    }
                    o ||
                        (ceFrontend.config.is_rtl &&
                            (s = i - (n.outerWidth() + s)),
                        (s = -s));
                    var l = {};
                    (l.width = i + "px"),
                        (l[this.getSettings("direction")] = s + "px"),
                        n.css(l);
                }
            },
            reset: function () {
                var e = { width: "" };
                (e[this.getSettings("direction")] = ""),
                    this.elements.$element.css(e);
            },
        });
    },
    211: function (e, t, n) {
        "use strict";
        e.exports = elementorModules.ViewModule.extend({
            $element: null,
            editorListeners: null,
            onElementChange: null,
            onEditSettingsChange: null,
            onGeneralSettingsChange: null,
            onPageSettingsChange: null,
            isEdit: null,
            __construct: function (e) {
                (this.$element = e.$element),
                    (this.isEdit = this.$element.hasClass(
                        "elementor-element-edit-mode"
                    )),
                    this.isEdit && this.addEditorListeners();
            },
            findElement: function (e) {
                var t = this.$element;
                return t.find(e).filter(function () {
                    return jQuery(this).closest(".elementor-element").is(t);
                });
            },
            getUniqueHandlerID: function (e, t) {
                return (
                    e || (e = this.getModelCID()),
                    t || (t = this.$element),
                    e + t.attr("data-element_type") + this.getConstructorID()
                );
            },
            initEditorListeners: function () {
                var e = this;
                if (
                    ((e.editorListeners = [
                        {
                            event: "element:destroy",
                            to: elementor.channels.data,
                            callback: function (t) {
                                t.cid === e.getModelCID() && e.onDestroy();
                            },
                        },
                    ]),
                    e.onElementChange)
                ) {
                    var t = e.getWidgetType() || e.getElementType(),
                        n = "change";
                    "global" !== t && (n += ":" + t),
                        e.editorListeners.push({
                            event: n,
                            to: elementor.channels.editor,
                            callback: function (t, n) {
                                e.getUniqueHandlerID(n.model.cid, n.$el) ===
                                    e.getUniqueHandlerID() &&
                                    e.onElementChange(
                                        t.model.get("name"),
                                        t,
                                        n
                                    );
                            },
                        });
                }
                e.onEditSettingsChange &&
                    e.editorListeners.push({
                        event: "change:editSettings",
                        to: elementor.channels.editor,
                        callback: function (t, n) {
                            n.model.cid === e.getModelCID() &&
                                e.onEditSettingsChange(
                                    Object.keys(t.changed)[0]
                                );
                        },
                    }),
                    ["page", "general"].forEach(function (t) {
                        var n =
                            "on" +
                            t[0].toUpperCase() +
                            t.slice(1) +
                            "SettingsChange";
                        e[n] &&
                            e.editorListeners.push({
                                event: "change",
                                to: elementor.settings[t].model,
                                callback: function (t) {
                                    e[n](t.changed);
                                },
                            });
                    });
            },
            getEditorListeners: function () {
                return (
                    this.editorListeners || this.initEditorListeners(),
                    this.editorListeners
                );
            },
            addEditorListeners: function () {
                var e = this.getUniqueHandlerID();
                this.getEditorListeners().forEach(function (t) {
                    ceFrontend.addListenerOnce(e, t.event, t.callback, t.to);
                });
            },
            removeEditorListeners: function () {
                var e = this.getUniqueHandlerID();
                this.getEditorListeners().forEach(function (t) {
                    ceFrontend.removeListeners(e, t.event, null, t.to);
                });
            },
            getElementType: function () {
                return this.$element.data("element_type");
            },
            getWidgetType: function () {
                var e = this.$element.data("widget_type");
                if (e) return e.split(".")[0];
            },
            getID: function () {
                return this.$element.data("id");
            },
            getModelCID: function () {
                return this.$element.data("model-cid");
            },
            getElementSettings: function (e) {
                var t = {},
                    n = this.getModelCID();
                if (this.isEdit && n) {
                    var i = ceFrontend.config.elements.data[n],
                        r = i.attributes,
                        o = r.widgetType || r.elType;
                    r.isInner && (o = "inner-" + o);
                    var s = ceFrontend.config.elements.keys[o];
                    s ||
                        ((s = ceFrontend.config.elements.keys[o] = []),
                        jQuery.each(i.controls, function (e, t) {
                            t.frontend_available && s.push(e);
                        })),
                        jQuery.each(i.getActiveControls(), function (e) {
                            -1 !== s.indexOf(e) && (t[e] = r[e]);
                        });
                } else t = this.$element.data("settings") || {};
                return this.getItems(t, e);
            },
            getEditSettings: function (e) {
                var t = {};
                return (
                    this.isEdit &&
                        (t =
                            ceFrontend.config.elements.editSettings[
                                this.getModelCID()
                            ].attributes),
                    this.getItems(t, e)
                );
            },
            getCurrentDeviceSetting: function (e) {
                return ceFrontend.getCurrentDeviceSetting(
                    this.getElementSettings(),
                    e
                );
            },
            onDestroy: function () {
                this.removeEditorListeners(),
                    this.unbindEvents && this.unbindEvents();
            },
        });
    },
    5: function (e, t, n) {
        "use strict";
        var i =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                    ? function (e) {
                          return typeof e;
                      }
                    : function (e) {
                          return e &&
                              "function" == typeof Symbol &&
                              e.constructor === Symbol &&
                              e !== Symbol.prototype
                              ? "symbol"
                              : typeof e;
                      },
            r = function () {
                var e = jQuery,
                    t = arguments,
                    n = this,
                    r = {},
                    o = void 0;
                (this.getItems = function (e, t) {
                    if (t) {
                        var n = t.split("."),
                            i = n.splice(0, 1);
                        if (!n.length) return e[i];
                        if (!e[i]) return;
                        return this.getItems(e[i], n.join("."));
                    }
                    return e;
                }),
                    (this.getSettings = function (e) {
                        return this.getItems(o, e);
                    }),
                    (this.setSettings = function (t, r, s) {
                        if (
                            (s || (s = o),
                            "object" === (void 0 === t ? "undefined" : i(t)))
                        )
                            return e.extend(s, t), n;
                        var u = t.split("."),
                            l = u.splice(0, 1);
                        return u.length
                            ? (s[l] || (s[l] = {}),
                              n.setSettings(u.join("."), r, s[l]))
                            : ((s[l] = r), n);
                    }),
                    (this.forceMethodImplementation = function (e) {
                        var t = e.callee.name;
                        throw new ReferenceError(
                            "The method " +
                                t +
                                " must to be implemented in the inheritor child."
                        );
                    }),
                    (this.on = function (t, o) {
                        return "object" === (void 0 === t ? "undefined" : i(t))
                            ? (e.each(t, function (e) {
                                  n.on(e, this);
                              }),
                              n)
                            : (t.split(" ").forEach(function (e) {
                                  r[e] || (r[e] = []), r[e].push(o);
                              }),
                              n);
                    }),
                    (this.off = function (e, t) {
                        if (!r[e]) return n;
                        if (!t) return delete r[e], n;
                        var i = r[e].indexOf(t);
                        return -1 !== i && delete r[e][i], n;
                    }),
                    (this.trigger = function (t) {
                        var i = "on" + t[0].toUpperCase() + t.slice(1),
                            o = Array.prototype.slice.call(arguments, 1);
                        n[i] && n[i].apply(n, o);
                        var s = r[t];
                        return s
                            ? (e.each(s, function (e, t) {
                                  t.apply(n, o);
                              }),
                              n)
                            : n;
                    }),
                    n.__construct.apply(n, t),
                    e.each(n, function (e) {
                        var t = n[e];
                        "function" == typeof t &&
                            (n[e] = function () {
                                return t.apply(n, arguments);
                            });
                    }),
                    (function () {
                        o = n.getDefaultSettings();
                        var i = t[0];
                        i && e.extend(!0, o, i);
                    })(),
                    n.trigger("init");
            };
        (r.prototype.__construct = function () {}),
            (r.prototype.getDefaultSettings = function () {
                return {};
            }),
            (r.extendsCount = 0),
            (r.extend = function (e) {
                var t = jQuery,
                    n = this,
                    i = function () {
                        return n.apply(this, arguments);
                    };
                t.extend(i, n),
                    ((i.prototype = Object.create(
                        t.extend({}, n.prototype, e)
                    )).constructor = i);
                var o = ++r.extendsCount;
                return (
                    (i.prototype.getConstructorID = function () {
                        return o;
                    }),
                    (i.__super__ = n.prototype),
                    i
                );
            }),
            (e.exports = r);
    },
    6: function (e, t, n) {
        "use strict";
        var i,
            r = n(5),
            o = (i = r) && i.__esModule ? i : { default: i };
        e.exports = o.default.extend({
            elements: null,
            getDefaultElements: function () {
                return {};
            },
            bindEvents: function () {},
            onInit: function () {
                this.initElements(), this.bindEvents();
            },
            initElements: function () {
                this.elements = this.getDefaultElements();
            },
        });
    },
}); /*! dialogs-manager v4.7.1 | (c) Kobi Zaltzberg | https://github.com/kobizz/dialogs-manager/blob/master/LICENSE.txt
 2019-01-13 15:53 */
!(function (a, b) {
    "use strict";
    var c = {
        widgetsTypes: {},
        createWidgetType: function (b, d, e) {
            e || (e = this.Widget);
            var f = function () {
                    e.apply(this, arguments);
                },
                g = (f.prototype = new e(b));
            return (
                (g.types = g.types.concat([b])),
                a.extend(g, d),
                (g.constructor = f),
                (f.extend = function (a, b) {
                    return c.createWidgetType(a, b, f);
                }),
                f
            );
        },
        addWidgetType: function (a, b, c) {
            return b && b.prototype instanceof this.Widget
                ? (this.widgetsTypes[a] = b)
                : (this.widgetsTypes[a] = this.createWidgetType(a, b, c));
        },
        getWidgetType: function (a) {
            return this.widgetsTypes[a];
        },
    };
    (c.Instance = function () {
        var b = this,
            d = {},
            e = {},
            f = function () {
                d.body = a("body");
            },
            g = function (b) {
                var c = {
                    classPrefix: "dialog",
                    effects: { show: "fadeIn", hide: "fadeOut" },
                };
                a.extend(e, c, b);
            };
        (this.createWidget = function (a, d) {
            var e = c.getWidgetType(a),
                f = new e(a);
            return (d = d || {}), f.init(b, d), f;
        }),
            (this.getSettings = function (a) {
                return a ? e[a] : Object.create(e);
            }),
            (this.init = function (a) {
                return g(a), f(), b;
            }),
            b.init();
    }),
        (c.Widget = function (b) {
            var d = this,
                e = {},
                f = {},
                g = {},
                h = 0,
                i = ["refreshPosition"],
                j = function () {
                    var a = [g.window];
                    g.iframe && a.push(jQuery(g.iframe[0].contentWindow)),
                        a.forEach(function (a) {
                            e.hide.onEscKeyPress && a.on("keyup", u),
                                e.hide.onOutsideClick &&
                                    a[0].addEventListener("click", o, !0),
                                e.hide.onOutsideContextMenu &&
                                    a[0].addEventListener("contextmenu", o, !0),
                                e.position.autoRefresh &&
                                    a.on("resize", d.refreshPosition);
                        }),
                        (e.hide.onClick || e.hide.onBackgroundClick) &&
                            g.widget.on("click", n);
                },
                k = function (b, c) {
                    var d = e.effects[b],
                        f = g.widget;
                    if (a.isFunction(d)) d.apply(f, c);
                    else {
                        if (!f[d])
                            throw (
                                "Reference Error: The effect " +
                                d +
                                " not found"
                            );
                        f[d].apply(f, c);
                    }
                },
                l = function () {
                    var b = i.concat(d.getClosureMethods());
                    a.each(b, function () {
                        var a = this,
                            b = d[a];
                        d[a] = function () {
                            b.apply(d, arguments);
                        };
                    });
                },
                m = function (a) {
                    if (a.my) {
                        var b = /left|right/,
                            c = /([+-]\d+)?$/,
                            d = g.iframe.offset(),
                            e = g.iframe[0].contentWindow,
                            f = a.my.split(" "),
                            h = [];
                        1 === f.length &&
                            (b.test(f[0])
                                ? f.push("center")
                                : f.unshift("center")),
                            f.forEach(function (a, b) {
                                var f = a.replace(c, function (a) {
                                    return (
                                        (a = +a || 0),
                                        (a += b
                                            ? d.top - e.scrollY
                                            : d.left - e.scrollX),
                                        a >= 0 && (a = "+" + a),
                                        a
                                    );
                                });
                                h.push(f);
                            }),
                            (a.my = h.join(" "));
                    }
                },
                n = function (b) {
                    if (!s(b)) {
                        if (e.hide.onClick) {
                            if (
                                a(b.target).closest(e.selectors.preventClose)
                                    .length
                            )
                                return;
                        } else if (b.target !== this) return;
                        d.hide();
                    }
                },
                o = function (b) {
                    s(b) || a(b.target).closest(g.widget).length || d.hide();
                },
                p = function () {
                    d.addElement("widget"),
                        d.addElement("header"),
                        d.addElement("message"),
                        d.addElement("window", window),
                        d.addElement("body", document.body),
                        d.addElement("container", e.container),
                        e.iframe && d.addElement("iframe", e.iframe),
                        e.closeButton &&
                            d.addElement(
                                "closeButton",
                                '<div><i class="' +
                                    e.closeButtonClass +
                                    '"></i></div>'
                            );
                    var b = d.getSettings("id");
                    b && d.setID(b);
                    var c = [];
                    a.each(d.types, function () {
                        c.push(e.classes.globalPrefix + "-type-" + this);
                    }),
                        c.push(d.getSettings("className")),
                        g.widget.addClass(c.join(" "));
                },
                q = function (c, f) {
                    var g = a.extend(!0, {}, c.getSettings());
                    (e = {
                        headerMessage: "",
                        message: "",
                        effects: g.effects,
                        classes: {
                            globalPrefix: g.classPrefix,
                            prefix: g.classPrefix + "-" + b,
                            preventScroll: g.classPrefix + "-prevent-scroll",
                        },
                        selectors: {
                            preventClose:
                                "." + g.classPrefix + "-prevent-close",
                        },
                        container: "body",
                        preventScroll: !1,
                        iframe: null,
                        closeButton: !1,
                        closeButtonClass: g.classPrefix + "-close-button-icon",
                        position: {
                            element: "widget",
                            my: "center",
                            at: "center",
                            enable: !0,
                            autoRefresh: !1,
                        },
                        hide: {
                            auto: !1,
                            autoDelay: 5e3,
                            onClick: !1,
                            onOutsideClick: !0,
                            onOutsideContextMenu: !1,
                            onBackgroundClick: !0,
                            onEscKeyPress: !0,
                        },
                    }),
                        a.extend(!0, e, d.getDefaultSettings(), f),
                        r();
                },
                r = function () {
                    a.each(e, function (a) {
                        var b = a.match(/^on([A-Z].*)/);
                        b &&
                            ((b = b[1].charAt(0).toLowerCase() + b[1].slice(1)),
                            d.on(b, this));
                    });
                },
                s = function (a) {
                    return "click" === a.type && 2 === a.button;
                },
                t = function (a) {
                    return a.replace(/([a-z])([A-Z])/g, function () {
                        return arguments[1] + "-" + arguments[2].toLowerCase();
                    });
                },
                u = function (a) {
                    var b = 27,
                        c = a.which;
                    b === c && d.hide();
                },
                v = function () {
                    var a = [g.window];
                    g.iframe && a.push(jQuery(g.iframe[0].contentWindow)),
                        a.forEach(function (a) {
                            e.hide.onEscKeyPress && a.off("keyup", u),
                                e.hide.onOutsideClick &&
                                    a[0].removeEventListener("click", o, !0),
                                e.hide.onOutsideContextMenu &&
                                    a[0].removeEventListener(
                                        "contextmenu",
                                        o,
                                        !0
                                    ),
                                e.position.autoRefresh &&
                                    a.off("resize", d.refreshPosition);
                        }),
                        (e.hide.onClick || e.hide.onBackgroundClick) &&
                            g.widget.off("click", n);
                };
            (this.addElement = function (b, c, d) {
                var f = (g[b] = a(c || "<div>")),
                    h = t(b),
                    i = [];
                return (
                    d && i.push(e.classes.globalPrefix + "-" + d),
                    i.push(e.classes.globalPrefix + "-" + h),
                    i.push(e.classes.prefix + "-" + h),
                    f.addClass(i.join(" ")),
                    f
                );
            }),
                (this.destroy = function () {
                    return v(), g.widget.remove(), d.trigger("destroy"), d;
                }),
                (this.getElements = function (a) {
                    return a ? g[a] : g;
                }),
                (this.getSettings = function (a) {
                    var b = Object.create(e);
                    return a ? b[a] : b;
                }),
                (this.hide = function () {
                    return (
                        clearTimeout(h),
                        k("hide", arguments),
                        v(),
                        e.preventScroll &&
                            d
                                .getElements("body")
                                .removeClass(e.classes.preventScroll),
                        d.trigger("hide"),
                        d
                    );
                }),
                (this.init = function (a, b) {
                    if (!(a instanceof c.Instance))
                        throw (
                            "The " +
                            d.widgetName +
                            " must to be initialized from an instance of DialogsManager.Instance"
                        );
                    return (
                        l(),
                        d.trigger("init", b),
                        q(a, b),
                        p(),
                        d.buildWidget(),
                        d.attachEvents(),
                        d.trigger("ready"),
                        d
                    );
                }),
                (this.isVisible = function () {
                    return g.widget.is(":visible");
                }),
                (this.on = function (b, c) {
                    if ("object" == typeof b)
                        return (
                            a.each(b, function (a) {
                                d.on(a, this);
                            }),
                            d
                        );
                    var e = b.split(" ");
                    return (
                        e.forEach(function (a) {
                            f[a] || (f[a] = []), f[a].push(c);
                        }),
                        d
                    );
                }),
                (this.off = function (a, b) {
                    if (!f[a]) return d;
                    if (!b) return delete f[a], d;
                    var c = f[a].indexOf(b);
                    return -1 !== c && f[a].splice(c, 1), d;
                }),
                (this.refreshPosition = function () {
                    if (e.position.enable) {
                        var b = a.extend({}, e.position);
                        g[b.of] && (b.of = g[b.of]),
                            b.of || (b.of = window),
                            e.iframe && m(b),
                            g[b.element].position(b);
                    }
                }),
                (this.setID = function (a) {
                    return g.widget.attr("id", a), d;
                }),
                (this.setHeaderMessage = function (a) {
                    return d.getElements("header").html(a), this;
                }),
                (this.setMessage = function (a) {
                    return g.message.html(a), d;
                }),
                (this.setSettings = function (b, c) {
                    return (
                        jQuery.isPlainObject(c)
                            ? a.extend(!0, e[b], c)
                            : (e[b] = c),
                        d
                    );
                }),
                (this.show = function () {
                    return (
                        clearTimeout(h),
                        g.widget.appendTo(g.container).hide(),
                        k("show", arguments),
                        d.refreshPosition(),
                        e.hide.auto &&
                            (h = setTimeout(d.hide, e.hide.autoDelay)),
                        j(),
                        e.preventScroll &&
                            d
                                .getElements("body")
                                .addClass(e.classes.preventScroll),
                        d.trigger("show"),
                        d
                    );
                }),
                (this.trigger = function (b, c) {
                    var e = "on" + b[0].toUpperCase() + b.slice(1);
                    d[e] && d[e](c);
                    var g = f[b];
                    if (g)
                        return (
                            a.each(g, function (a, b) {
                                b.call(d, c);
                            }),
                            d
                        );
                });
        }),
        (c.Widget.prototype.types = []),
        (c.Widget.prototype.buildWidget = function () {
            var a = this.getElements(),
                b = this.getSettings();
            a.widget.append(a.header, a.message),
                this.setHeaderMessage(b.headerMessage),
                this.setMessage(b.message),
                this.getSettings("closeButton") &&
                    a.widget.prepend(a.closeButton);
        }),
        (c.Widget.prototype.attachEvents = function () {
            var a = this;
            a.getSettings("closeButton") &&
                a.getElements("closeButton").on("click", function () {
                    a.hide();
                });
        }),
        (c.Widget.prototype.getDefaultSettings = function () {
            return {};
        }),
        (c.Widget.prototype.getClosureMethods = function () {
            return [];
        }),
        (c.Widget.prototype.onHide = function () {}),
        (c.Widget.prototype.onShow = function () {}),
        (c.Widget.prototype.onInit = function () {}),
        (c.Widget.prototype.onReady = function () {}),
        (c.widgetsTypes.simple = c.Widget),
        c.addWidgetType("buttons", {
            activeKeyUp: function (a) {
                var b = 9;
                a.which === b && a.preventDefault(),
                    this.hotKeys[a.which] && this.hotKeys[a.which](this);
            },
            activeKeyDown: function (a) {
                if (this.focusedButton) {
                    var b = 9;
                    if (a.which === b) {
                        a.preventDefault();
                        var c,
                            d = this.focusedButton.index();
                        a.shiftKey
                            ? ((c = d - 1),
                              c < 0 && (c = this.buttons.length - 1))
                            : ((c = d + 1),
                              c >= this.buttons.length && (c = 0)),
                            (this.focusedButton = this.buttons[c].focus());
                    }
                }
            },
            addButton: function (b) {
                var c = this,
                    d = c.getSettings(),
                    e = jQuery.extend(d.button, b),
                    f = c.addElement(
                        b.name,
                        a("<" + e.tag + ">").text(b.text),
                        "button"
                    );
                c.buttons.push(f);
                var g = function () {
                    d.hide.onButtonClick && c.hide(),
                        a.isFunction(b.callback) && b.callback.call(this, c);
                };
                return (
                    f.on("click", g),
                    b.hotKey && (this.hotKeys[b.hotKey] = g),
                    this.getElements("buttonsWrapper").append(f),
                    b.focus && (this.focusedButton = f),
                    c
                );
            },
            bindHotKeys: function () {
                this.getElements("window").on({
                    keyup: this.activeKeyUp,
                    keydown: this.activeKeyDown,
                });
            },
            buildWidget: function () {
                c.Widget.prototype.buildWidget.apply(this, arguments);
                var a = this.addElement("buttonsWrapper");
                this.getElements("widget").append(a);
            },
            getClosureMethods: function () {
                return ["activeKeyUp", "activeKeyDown"];
            },
            getDefaultSettings: function () {
                return {
                    hide: { onButtonClick: !0 },
                    button: { tag: "button" },
                };
            },
            onHide: function () {
                this.unbindHotKeys();
            },
            onInit: function () {
                (this.buttons = []),
                    (this.hotKeys = {}),
                    (this.focusedButton = null);
            },
            onShow: function () {
                this.bindHotKeys(),
                    this.focusedButton ||
                        (this.focusedButton = this.buttons[0]),
                    this.focusedButton && this.focusedButton.focus();
            },
            unbindHotKeys: function () {
                this.getElements("window").off({
                    keyup: this.activeKeyUp,
                    keydown: this.activeKeyDown,
                });
            },
        }),
        c.addWidgetType(
            "lightbox",
            c.getWidgetType("buttons").extend("lightbox", {
                getDefaultSettings: function () {
                    var b = c
                        .getWidgetType("buttons")
                        .prototype.getDefaultSettings.apply(this, arguments);
                    return a.extend(!0, b, {
                        contentWidth: "auto",
                        contentHeight: "auto",
                        position: {
                            element: "widgetContent",
                            of: "widget",
                            autoRefresh: !0,
                        },
                    });
                },
                buildWidget: function () {
                    c.getWidgetType("buttons").prototype.buildWidget.apply(
                        this,
                        arguments
                    );
                    var a = this.addElement("widgetContent"),
                        b = this.getElements();
                    a.append(b.header, b.message, b.buttonsWrapper),
                        b.widget.html(a),
                        b.closeButton && a.prepend(b.closeButton);
                },
                onReady: function () {
                    var a = this.getElements(),
                        b = this.getSettings();
                    "auto" !== b.contentWidth &&
                        a.message.width(b.contentWidth),
                        "auto" !== b.contentHeight &&
                            a.message.height(b.contentHeight);
                },
            })
        ),
        c.addWidgetType(
            "confirm",
            c.getWidgetType("lightbox").extend("confirm", {
                onReady: function () {
                    c.getWidgetType("lightbox").prototype.onReady.apply(
                        this,
                        arguments
                    );
                    var a = this.getSettings("strings"),
                        b = "cancel" === this.getSettings("defaultOption");
                    this.addButton({
                        name: "cancel",
                        text: a.cancel,
                        callback: function (a) {
                            a.trigger("cancel");
                        },
                        focus: b,
                    }),
                        this.addButton({
                            name: "ok",
                            text: a.confirm,
                            callback: function (a) {
                                a.trigger("confirm");
                            },
                            focus: !b,
                        });
                },
                getDefaultSettings: function () {
                    var a = c
                        .getWidgetType("lightbox")
                        .prototype.getDefaultSettings.apply(this, arguments);
                    return (
                        (a.strings = { confirm: "OK", cancel: "Cancel" }),
                        (a.defaultOption = "cancel"),
                        a
                    );
                },
            })
        ),
        c.addWidgetType(
            "alert",
            c.getWidgetType("lightbox").extend("alert", {
                onReady: function () {
                    c.getWidgetType("lightbox").prototype.onReady.apply(
                        this,
                        arguments
                    );
                    var a = this.getSettings("strings");
                    this.addButton({
                        name: "ok",
                        text: a.confirm,
                        callback: function (a) {
                            a.trigger("confirm");
                        },
                    });
                },
                getDefaultSettings: function () {
                    var a = c
                        .getWidgetType("lightbox")
                        .prototype.getDefaultSettings.apply(this, arguments);
                    return (a.strings = { confirm: "OK" }), a;
                },
            })
        ),
        (b.DialogsManager = c);
})(
    "undefined" != typeof jQuery
        ? jQuery
        : "function" == typeof require && require("jquery"),
    "undefined" != typeof module ? module.exports : window
);
((n) => {
    var i = {};
    function o(e) {
        var t;
        return (
            i[e] ||
            ((t = i[e] = { i: e, l: !1, exports: {} }),
            n[e].call(t.exports, t, t.exports, o),
            (t.l = !0),
            t)
        ).exports;
    }
    (o.m = n),
        (o.c = i),
        (o.d = function (e, t, n) {
            o.o(e, t) ||
                Object.defineProperty(e, t, { enumerable: !0, get: n });
        }),
        (o.r = function (e) {
            "undefined" != typeof Symbol &&
                Symbol.toStringTag &&
                Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module",
                }),
                Object.defineProperty(e, "__esModule", { value: !0 });
        }),
        (o.t = function (t, e) {
            if ((1 & e && (t = o(t)), 8 & e)) return t;
            if (4 & e && "object" == typeof t && t && t.__esModule) return t;
            var n = Object.create(null);
            if (
                (o.r(n),
                Object.defineProperty(n, "default", {
                    enumerable: !0,
                    value: t,
                }),
                2 & e && "string" != typeof t)
            )
                for (var i in t)
                    o.d(
                        n,
                        i,
                        function (e) {
                            return t[e];
                        }.bind(null, i)
                    );
            return n;
        }),
        (o.n = function (e) {
            var t =
                e && e.__esModule
                    ? function () {
                          return e.default;
                      }
                    : function () {
                          return e;
                      };
            return o.d(t, "a", t), t;
        }),
        (o.o = function (e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }),
        (o.p = ""),
        o((o.s = 182));
})({
    1: function (e, t, n) {
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = navigator.userAgent;
        t.default = {
            webkit: -1 !== i.indexOf("AppleWebKit"),
            firefox: -1 !== i.indexOf("Firefox"),
            ie: /Trident|MSIE/.test(i),
            edge: -1 !== i.indexOf("Edge"),
            mac: -1 !== i.indexOf("Macintosh"),
        };
    },
    13: function (e, t, n) {
        e.exports = function () {
            var o,
                n = Array.prototype.slice,
                a = { actions: {}, filters: {} };
            function i(e, t, n, i) {
                var o, s, r;
                if (a[e][t])
                    if (n)
                        if (((o = a[e][t]), i))
                            for (r = o.length; r--; )
                                (s = o[r]).callback === n &&
                                    s.context === i &&
                                    o.splice(r, 1);
                        else
                            for (r = o.length; r--; )
                                o[r].callback === n && o.splice(r, 1);
                    else a[e][t] = [];
            }
            function s(e, t, n, i, o) {
                (i = { callback: n, priority: i, context: o }), (o = a[e][t]);
                if (o) {
                    var s = !1;
                    if (
                        (jQuery.each(o, function () {
                            if (this.callback === n) return !(s = !0);
                        }),
                        s)
                    )
                        return;
                    o.push(i),
                        (o = ((e) => {
                            for (var t, n, i, o = 1, s = e.length; o < s; o++) {
                                for (
                                    t = e[o], n = o;
                                    (i = e[n - 1]) && i.priority > t.priority;

                                )
                                    (e[n] = e[n - 1]), --n;
                                e[n] = t;
                            }
                            return e;
                        })(o));
                } else o = [i];
                a[e][t] = o;
            }
            function r(e, t, n) {
                var i,
                    o,
                    s = a[e][t];
                if (!s) return "filters" === e && n[0];
                if (((o = s.length), "filters" === e))
                    for (i = 0; i < o; i++)
                        n[0] = s[i].callback.apply(s[i].context, n);
                else
                    for (i = 0; i < o; i++)
                        s[i].callback.apply(s[i].context, n);
                return "filters" !== e || n[0];
            }
            return (o = {
                removeFilter: function (e, t) {
                    return "string" == typeof e && i("filters", e, t), o;
                },
                applyFilters: function () {
                    var e = n.call(arguments),
                        t = e.shift();
                    return "string" == typeof t ? r("filters", t, e) : o;
                },
                addFilter: function (e, t, n, i) {
                    return (
                        "string" == typeof e &&
                            "function" == typeof t &&
                            s("filters", e, t, (n = parseInt(n || 10, 10)), i),
                        o
                    );
                },
                removeAction: function (e, t) {
                    return "string" == typeof e && i("actions", e, t), o;
                },
                doAction: function () {
                    var e = n.call(arguments),
                        t = e.shift();
                    return "string" == typeof t && r("actions", t, e), o;
                },
                addAction: function (e, t, n, i) {
                    return (
                        "string" == typeof e &&
                            "function" == typeof t &&
                            s("actions", e, t, (n = parseInt(n || 10, 10)), i),
                        o
                    );
                },
            });
        };
    },
    10: function (e, t, n) {
        var E = jQuery,
            i =
                ((window.Sticky = function (e, t) {
                    function n() {
                        l.$spacer.remove();
                    }
                    var o,
                        s,
                        i = !1,
                        r = !1,
                        a = !1,
                        l = {},
                        d = {
                            to: "top",
                            offset: 0,
                            effectsOffset: 0,
                            parent: !1,
                            classes: {
                                sticky: "sticky",
                                stickyActive: "sticky-active",
                                stickyEffects: "sticky-effects",
                                spacer: "sticky-spacer",
                            },
                        },
                        c = function (e, t, n) {
                            var i = {},
                                o = e[0].style;
                            n.forEach(function (e) {
                                i[e] = void 0 !== o[e] ? o[e] : "";
                            }),
                                e.data("css-backup-" + t, i);
                        },
                        u = function (e, t) {
                            return e.data("css-backup-" + t);
                        },
                        h = function () {
                            (l.$spacer = o
                                .clone()
                                .addClass(s.classes.spacer)
                                .css({
                                    visibility: "hidden",
                                    transition: "none",
                                    animation: "none",
                                })),
                                o.after(l.$spacer);
                        },
                        p = function () {
                            c(o, "unsticky", [
                                "position",
                                "width",
                                "margin-top",
                                "margin-bottom",
                                "top",
                                "bottom",
                            ]);
                            var e = {
                                position: "fixed",
                                width: v(o, "width"),
                                marginTop: 0,
                                marginBottom: 0,
                            };
                            (e[s.to] = s.offset),
                                (e["top" === s.to ? "bottom" : "top"] = ""),
                                o.css(e).addClass(s.classes.stickyActive);
                        },
                        f = function () {
                            o.css(u(o, "unsticky")).removeClass(
                                s.classes.stickyActive
                            );
                        },
                        m = function () {
                            c(l.$parent, "childNotFollowing", ["position"]),
                                l.$parent.css("position", "relative"),
                                c(o, "notFollowing", [
                                    "position",
                                    "top",
                                    "bottom",
                                ]);
                            var e = { position: "absolute" };
                            (e[s.to] = ""),
                                (e["top" === s.to ? "bottom" : "top"] = 0),
                                o.css(e),
                                (r = !0);
                        },
                        g = function () {
                            l.$parent.css(u(l.$parent, "childNotFollowing")),
                                o.css(u(o, "notFollowing")),
                                (r = !1);
                        },
                        v = function (e, t, n) {
                            var i = getComputedStyle(e[0]),
                                o = parseFloat(i[t]),
                                s =
                                    "height" === t
                                        ? ["top", "bottom"]
                                        : ["left", "right"],
                                e = [];
                            return (
                                "border-box" !== i.boxSizing &&
                                    e.push("border", "padding"),
                                n && e.push("margin"),
                                e.forEach(function (t) {
                                    s.forEach(function (e) {
                                        o += parseFloat(i[t + "-" + e]);
                                    });
                                }),
                                o
                            );
                        },
                        y = function (e) {
                            var t = l.$window.scrollTop(),
                                n = v(e, "height"),
                                i = innerHeight,
                                e = e.offset().top - t,
                                t = e - i;
                            return {
                                top: { fromTop: e, fromBottom: t },
                                bottom: { fromTop: e + n, fromBottom: t + n },
                            };
                        },
                        b = function () {
                            h(),
                                p(),
                                (i = !0),
                                o.find("input[checked]").prop("checked", !0),
                                o.trigger("sticky:stick");
                        },
                        w = function () {
                            f(), n(), (i = !1), o.trigger("sticky:unstick");
                        },
                        S = function () {
                            var e,
                                t,
                                n = y(o),
                                i = "top" === s.to;
                            r
                                ? (i
                                      ? n.top.fromTop > s.offset
                                      : n.bottom.fromBottom < -s.offset) && g()
                                : ((t = y(l.$parent)),
                                  (e = getComputedStyle(l.$parent[0])),
                                  (e = parseFloat(
                                      e[
                                          i
                                              ? "borderBottomWidth"
                                              : "borderTopWidth"
                                      ]
                                  )),
                                  (t = i
                                      ? t.bottom.fromTop - e
                                      : t.top.fromBottom + e),
                                  (i
                                      ? t <= n.bottom.fromTop
                                      : t >= n.top.fromBottom) && m());
                        },
                        _ = function (e) {
                            a && -e < s.effectsOffset
                                ? (o.removeClass(s.classes.stickyEffects),
                                  (a = !1))
                                : !a &&
                                  -e >= s.effectsOffset &&
                                  (o.addClass(s.classes.stickyEffects),
                                  (a = !0));
                        },
                        k = function () {
                            var e,
                                t,
                                n = s.offset;
                            i
                                ? ((e = y(l.$spacer)),
                                  (e =
                                      "top" === s.to
                                          ? e.top.fromTop - n
                                          : -e.bottom.fromBottom - n),
                                  s.parent && S(),
                                  0 < e && w())
                                : ((t = y(o)),
                                  (e =
                                      "top" === s.to
                                          ? t.top.fromTop - n
                                          : -t.bottom.fromBottom - n) <= 0 &&
                                      (b(), s.parent) &&
                                      S()),
                                _(e);
                        },
                        $ = function () {
                            k();
                        },
                        C = function () {
                            i && (f(), p(), s.parent) && ((r = !1), S());
                        };
                    (this.destroy = function () {
                        i && w(),
                            l.$window.off("scroll", $).off("resize", C),
                            o.removeClass(s.classes.sticky);
                    }),
                        (s = jQuery.extend(!0, d, t)),
                        (o = E(e).addClass(s.classes.sticky)),
                        (l.$window = E(window)),
                        s.parent &&
                            ("parent" === s.parent
                                ? (l.$parent = o.parent())
                                : (l.$parent = o.closest(s.parent))),
                        l.$window.on({ scroll: $, resize: C }),
                        k();
                }),
                (E.fn.sticky = function (n) {
                    var i = "string" == typeof n;
                    return (
                        this.each(function () {
                            var e = E(this);
                            if (i) {
                                var t = e.data("sticky");
                                if (!t)
                                    throw Error(
                                        "Trying to perform the `" +
                                            n +
                                            "` method prior to initialization"
                                    );
                                if (!t[n])
                                    throw ReferenceError(
                                        "Method `" +
                                            n +
                                            "` not found in sticky instance"
                                    );
                                t[n].apply(
                                    t,
                                    Array.prototype.slice.call(arguments, 1)
                                ),
                                    "destroy" === n && e.removeData("sticky");
                            } else e.data("sticky", new Sticky(this, n));
                        }),
                        this
                    );
                }),
                elementorModules.frontend.handlers.Base.extend({
                    bindEvents: function () {
                        ceFrontend.addListenerOnce(
                            this.getUniqueHandlerID() + "sticky",
                            "resize",
                            this.run
                        );
                    },
                    unbindEvents: function () {
                        ceFrontend.removeListeners(
                            this.getUniqueHandlerID() + "sticky",
                            "resize",
                            this.run
                        );
                    },
                    isActive: function () {
                        return void 0 !== this.$element.data("sticky");
                    },
                    activate: function () {
                        var e = this.getElementSettings(),
                            t = {
                                to: e.sticky,
                                offset: e.sticky_offset,
                                effectsOffset: e.sticky_effects_offset,
                                classes: {
                                    sticky: "elementor-sticky",
                                    stickyActive:
                                        "elementor-sticky--active elementor-section--handles-inside",
                                    stickyEffects: "elementor-sticky--effects",
                                    spacer: "elementor-sticky__spacer",
                                },
                            };
                        e.sticky_parent &&
                            (t.parent = ".elementor-widget-wrap"),
                            this.$element.sticky(t);
                    },
                    deactivate: function () {
                        this.isActive() && this.$element.sticky("destroy");
                    },
                    run: function (e) {
                        var t;
                        this.getElementSettings("sticky") &&
                        ((t = ceFrontend.getCurrentDeviceMode()),
                        -1 !== this.getElementSettings("sticky_on").indexOf(t))
                            ? !0 === e
                                ? this.reactivate()
                                : this.isActive() || this.activate()
                            : this.deactivate();
                    },
                    reactivate: function () {
                        this.deactivate(), this.activate();
                    },
                    onElementChange: function (e) {
                        -1 !== ["sticky", "sticky_on"].indexOf(e) &&
                            this.run(!0),
                            -1 !==
                                [
                                    "sticky_offset",
                                    "sticky_effects_offset",
                                    "sticky_parent",
                                ].indexOf(e) && this.reactivate();
                    },
                    onInit: function () {
                        elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                            this,
                            arguments
                        ),
                            this.run();
                    },
                    onDestroy: function () {
                        elementorModules.frontend.handlers.Base.prototype.onDestroy.apply(
                            this,
                            arguments
                        ),
                            this.deactivate();
                    },
                }));
        e.exports = function (e) {
            new i({ $element: e });
        };
    },
    15: function (e, t, n) {
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = function (e, t, n) {
            return t && o(e.prototype, t), n && o(e, n), e;
        };
        function o(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                (i.enumerable = i.enumerable || !1),
                    (i.configurable = !0),
                    "value" in i && (i.writable = !0),
                    Object.defineProperty(e, i.key, i);
            }
        }
        var s = ((e) => {
            var t = n;
            if ("function" != typeof e && null !== e)
                throw new TypeError(
                    "Super expression must either be null or a function, not " +
                        typeof e
                );
            function n() {
                var e = this,
                    t = n;
                if (!(e instanceof t))
                    throw new TypeError("Cannot call a class as a function");
                (e = this),
                    (t = (n.__proto__ || Object.getPrototypeOf(n)).apply(
                        this,
                        arguments
                    ));
                if (e)
                    return !t ||
                        ("object" != typeof t && "function" != typeof t)
                        ? e
                        : t;
                throw new ReferenceError(
                    "this hasn't been initialised - super() hasn't been called"
                );
            }
            return (
                (t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0,
                    },
                })),
                e &&
                    (Object.setPrototypeOf
                        ? Object.setPrototypeOf(t, e)
                        : (t.__proto__ = e)),
                i(n, [
                    {
                        key: "get",
                        value: function (t, e) {
                            e = e || {};
                            var n = void 0;
                            try {
                                n = e.session ? sessionStorage : localStorage;
                            } catch (e) {
                                return t ? void 0 : {};
                            }
                            var i = n.getItem("elementor"),
                                o =
                                    ((i = i ? JSON.parse(i) : {})
                                        .__expiration || (i.__expiration = {}),
                                    i.__expiration),
                                n = [],
                                s =
                                    (t
                                        ? o[t] && (n = [t])
                                        : (n = Object.keys(o)),
                                    !1);
                            return (
                                n.forEach(function (e) {
                                    new Date(o[e]) < new Date() &&
                                        (delete i[e], delete o[e], (s = !0));
                                }),
                                s && this.save(i, e.session),
                                t ? i[t] : i
                            );
                        },
                    },
                    {
                        key: "set",
                        value: function (e, t, n) {
                            var i = this.get(null, (n = n || {}));
                            (i[e] = t),
                                n.lifetimeInSeconds &&
                                    ((t = new Date()).setTime(
                                        t.getTime() + 1e3 * n.lifetimeInSeconds
                                    ),
                                    (i.__expiration[e] = t.getTime())),
                                this.save(i, n.session);
                        },
                    },
                    {
                        key: "save",
                        value: function (e, t) {
                            var n = void 0;
                            try {
                                n = t ? sessionStorage : localStorage;
                            } catch (e) {
                                return;
                            }
                            n.setItem("elementor", JSON.stringify(e));
                        },
                    },
                ]),
                n
            );
        })(elementorModules.Module);
        t.default = s;
    },
    16: function (e, t, n) {
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = function (e, t, n) {
            return t && o(e.prototype, t), n && o(e, n), e;
        };
        function o(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                (i.enumerable = i.enumerable || !1),
                    (i.configurable = !0),
                    "value" in i && (i.writable = !0),
                    Object.defineProperty(e, i.key, i);
            }
        }
        var n = n(1),
            s = (n = n) && n.__esModule ? n : { default: n };
        function r() {
            if (!(this instanceof r))
                throw new TypeError("Cannot call a class as a function");
            this.hotKeysHandlers = {};
        }
        i(r, [
            {
                key: "applyHotKey",
                value: function (n) {
                    var e = this.hotKeysHandlers[n.which];
                    e &&
                        jQuery.each(e, function (e, t) {
                            (t.isWorthHandling && !t.isWorthHandling(n)) ||
                                (!t.allowAltKey && n.altKey) ||
                                (n.preventDefault(), t.handle(n));
                        });
                },
            },
            {
                key: "isControlEvent",
                value: function (e) {
                    return e[s.default.mac ? "metaKey" : "ctrlKey"];
                },
            },
            {
                key: "addHotKeyHandler",
                value: function (e, t, n) {
                    this.hotKeysHandlers[e] || (this.hotKeysHandlers[e] = {}),
                        (this.hotKeysHandlers[e][t] = n);
                },
            },
            {
                key: "bindListener",
                value: function (e) {
                    e.on("keydown", this.applyHotKey.bind(this));
                },
            },
        ]),
            (t.default = r);
    },
    17: function (e, t, n) {
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = function (e, t, n) {
            return t && o(e.prototype, t), n && o(e, n), e;
        };
        function o(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                (i.enumerable = i.enumerable || !1),
                    (i.configurable = !0),
                    "value" in i && (i.writable = !0),
                    Object.defineProperty(e, i.key, i);
            }
        }
        function s(e, t, n) {
            null === e && (e = Function.prototype);
            var i = Object.getOwnPropertyDescriptor(e, t);
            return void 0 !== i
                ? "value" in i
                    ? i.value
                    : void 0 !== (i = i.get)
                    ? i.call(n)
                    : void 0
                : null !== (i = Object.getPrototypeOf(e))
                ? s(i, t, n)
                : void 0;
        }
        var r = ((e) => {
            var t = n;
            if ("function" != typeof e && null !== e)
                throw new TypeError(
                    "Super expression must either be null or a function, not " +
                        typeof e
                );
            function n() {
                var e = this,
                    t = n;
                if (!(e instanceof t))
                    throw new TypeError("Cannot call a class as a function");
                (e = this),
                    (t = (n.__proto__ || Object.getPrototypeOf(n)).apply(
                        this,
                        arguments
                    ));
                if (e)
                    return !t ||
                        ("object" != typeof t && "function" != typeof t)
                        ? e
                        : t;
                throw new ReferenceError(
                    "this hasn't been initialised - super() hasn't been called"
                );
            }
            return (
                (t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0,
                    },
                })),
                e &&
                    (Object.setPrototypeOf
                        ? Object.setPrototypeOf(t, e)
                        : (t.__proto__ = e)),
                i(n, [
                    {
                        key: "getDefaultSettings",
                        value: function () {
                            return {
                                selectors: {
                                    elements: ".elementor-element",
                                    nestedDocumentElements:
                                        ".elementor .elementor-element",
                                },
                                classes: { editMode: "elementor-edit-mode" },
                            };
                        },
                    },
                    {
                        key: "getDefaultElements",
                        value: function () {
                            var e = this.getSettings("selectors");
                            return {
                                $elements: this.$element
                                    .find(e.elements)
                                    .not(
                                        this.$element.find(
                                            e.nestedDocumentElements
                                        )
                                    ),
                            };
                        },
                    },
                    {
                        key: "getDocumentSettings",
                        value: function (e) {
                            var t,
                                n = void 0;
                            return (
                                this.isEdit
                                    ? ((n = {}),
                                      (t = elementor.settings.page.model),
                                      jQuery.each(
                                          t.getActiveControls(),
                                          function (e) {
                                              n[e] = t.attributes[e];
                                          }
                                      ))
                                    : (n =
                                          this.$element.data(
                                              "elementor-settings"
                                          ) || {}),
                                this.getItems(n, e)
                            );
                        },
                    },
                    {
                        key: "runElementsHandlers",
                        value: function () {
                            this.elements.$elements.each(function (e, t) {
                                return ceFrontend.elementsHandler.runReadyTrigger(
                                    t
                                );
                            });
                        },
                    },
                    {
                        key: "onInit",
                        value: function () {
                            (this.$element = this.getSettings("$element")),
                                s(
                                    n.prototype.__proto__ ||
                                        Object.getPrototypeOf(n.prototype),
                                    "onInit",
                                    this
                                ).call(this),
                                (this.isEdit = this.$element.hasClass(
                                    this.getSettings("classes.editMode")
                                )),
                                this.isEdit
                                    ? elementor.settings.page.model.on(
                                          "change",
                                          this.onSettingsChange.bind(this)
                                      )
                                    : this.runElementsHandlers();
                        },
                    },
                    { key: "onSettingsChange", value: function () {} },
                ]),
                n
            );
        })(elementorModules.ViewModule);
        t.default = r;
    },
    18: function (e, t, n) {
        e.exports = elementorModules.frontend.handlers.Base.extend({
            $activeContent: null,
            getDefaultSettings: function () {
                return {
                    selectors: {
                        tabTitle: ".elementor-tab-title",
                        tabContent: ".elementor-tab-content",
                    },
                    classes: { active: "elementor-active" },
                    showTabFn: "show",
                    hideTabFn: "hide",
                    toggleSelf: !0,
                    hidePrevious: !0,
                    autoExpand: !0,
                };
            },
            getDefaultElements: function () {
                var e = this.getSettings("selectors");
                return {
                    $tabTitles: this.findElement(e.tabTitle),
                    $tabContents: this.findElement(e.tabContent),
                };
            },
            activateDefaultTab: function () {
                var e,
                    t = this.getSettings();
                t.autoExpand &&
                    ("editor" !== t.autoExpand || this.isEdit) &&
                    ((e = this.getEditSettings("activeItemIndex") || 1),
                    (t = { showTabFn: t.showTabFn, hideTabFn: t.hideTabFn }),
                    this.setSettings({ showTabFn: "show", hideTabFn: "hide" }),
                    this.changeActiveTab(e),
                    this.setSettings(t));
            },
            deactivateActiveTab: function (e) {
                var t = this.getSettings(),
                    n = t.classes.active,
                    e = e ? '[data-tab="' + e + '"]' : "." + n,
                    i = this.elements.$tabTitles.filter(e),
                    e = this.elements.$tabContents.filter(e);
                i.add(e).removeClass(n), e[t.hideTabFn]();
            },
            activateTab: function (e) {
                var t = this.getSettings(),
                    n = t.classes.active,
                    i = this.elements.$tabTitles.filter(
                        '[data-tab="' + e + '"]'
                    ),
                    e = this.elements.$tabContents.filter(
                        '[data-tab="' + e + '"]'
                    );
                i.add(e).addClass(n), e[t.showTabFn]();
            },
            isActiveTab: function (e) {
                return this.elements.$tabTitles
                    .filter('[data-tab="' + e + '"]')
                    .hasClass(this.getSettings("classes.active"));
            },
            bindEvents: function () {
                var t = this;
                this.elements.$tabTitles.on({
                    keydown: function (e) {
                        "Enter" === e.key &&
                            (e.preventDefault(),
                            t.changeActiveTab(
                                e.currentTarget.getAttribute("data-tab")
                            ));
                    },
                    click: function (e) {
                        e.preventDefault(),
                            t.changeActiveTab(
                                e.currentTarget.getAttribute("data-tab")
                            );
                    },
                });
            },
            onInit: function () {
                elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                    this,
                    arguments
                ),
                    this.activateDefaultTab();
            },
            onEditSettingsChange: function (e) {
                "activeItemIndex" === e && this.activateDefaultTab();
            },
            changeActiveTab: function (e) {
                var t = this.isActiveTab(e),
                    n = this.getSettings();
                (!n.toggleSelf && t) ||
                    !n.hidePrevious ||
                    this.deactivateActiveTab(),
                    !n.hidePrevious && t && this.deactivateActiveTab(e),
                    t || this.activateTab(e);
            },
        });
    },
    182: function (e, t, n) {
        var i = function (e, t, n) {
            return t && o(e.prototype, t), n && o(e, n), e;
        };
        function o(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                (i.enumerable = i.enumerable || !1),
                    (i.configurable = !0),
                    "value" in i && (i.writable = !0),
                    Object.defineProperty(e, i.key, i);
            }
        }
        var r = s(n(183)),
            a = s(n(16)),
            l = s(n(15)),
            d = s(n(1));
        function s(e) {
            return e && e.__esModule ? e : { default: e };
        }
        var c = n(13),
            u = n(184),
            h = n(196),
            p = n(197),
            f = n(198),
            n = ((e) => {
                var t = s;
                if ("function" != typeof e && null !== e)
                    throw new TypeError(
                        "Super expression must either be null or a function, not " +
                            typeof e
                    );
                function s() {
                    var e = this,
                        t = s;
                    if (!(e instanceof t))
                        throw new TypeError(
                            "Cannot call a class as a function"
                        );
                    for (
                        var n = arguments.length, i = Array(n), o = 0;
                        o < n;
                        o++
                    )
                        i[o] = arguments[o];
                    t = ((e, t) => {
                        if (e)
                            return !t ||
                                ("object" != typeof t && "function" != typeof t)
                                ? e
                                : t;
                        throw new ReferenceError(
                            "this hasn't been initialised - super() hasn't been called"
                        );
                    })(
                        this,
                        (e =
                            s.__proto__ || Object.getPrototypeOf(s)).call.apply(
                            e,
                            [this].concat(i)
                        )
                    );
                    return (t.config = ceFrontendConfig), t;
                }
                return (
                    (t.prototype = Object.create(e && e.prototype, {
                        constructor: {
                            value: t,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0,
                        },
                    })),
                    e &&
                        (Object.setPrototypeOf
                            ? Object.setPrototypeOf(t, e)
                            : (t.__proto__ = e)),
                    i(s, [
                        {
                            key: "getDefaultSettings",
                            value: function () {
                                return {
                                    selectors: {
                                        elementor: ".elementor",
                                        adminBar: "#wpadminbar",
                                    },
                                    classes: { ie: "elementor-msie" },
                                };
                            },
                        },
                        {
                            key: "getDefaultElements",
                            value: function () {
                                var e = {
                                    window: window,
                                    $window: jQuery(window),
                                    $document: jQuery(document),
                                    $head: jQuery(document.head),
                                    $body: jQuery(document.body),
                                    $deviceMode: jQuery("<span>", {
                                        id: "elementor-device-mode",
                                        class: "elementor-screen-only",
                                    }),
                                };
                                return e.$body.append(e.$deviceMode), e;
                            },
                        },
                        {
                            key: "bindEvents",
                            value: function () {
                                var e = this;
                                this.elements.$window.on("resize", function () {
                                    return e.setDeviceModeData();
                                });
                            },
                        },
                        {
                            key: "getElements",
                            value: function (e) {
                                return this.getItems(this.elements, e);
                            },
                        },
                        {
                            key: "getPageSettings",
                            value: function (e) {
                                var t = this.isEditMode()
                                    ? elementor.settings.page.model.attributes
                                    : this.config.settings.page;
                                return this.getItems(t, e);
                            },
                        },
                        {
                            key: "getGeneralSettings",
                            value: function (e) {
                                var t = this.isEditMode()
                                    ? elementor.settings.general.model
                                          .attributes
                                    : this.config.settings.general;
                                return this.getItems(t, e);
                            },
                        },
                        {
                            key: "getCurrentDeviceMode",
                            value: function () {
                                return getComputedStyle(
                                    this.elements.$deviceMode[0],
                                    ":after"
                                ).content.replace(/"/g, "");
                            },
                        },
                        {
                            key: "getCurrentDeviceSetting",
                            value: function (e, t) {
                                for (
                                    var n = ["desktop", "tablet", "mobile"],
                                        i = ceFrontend.getCurrentDeviceMode(),
                                        o = n.indexOf(i);
                                    0 < o;

                                ) {
                                    var s = e[t + "_" + n[o]];
                                    if (s) return s;
                                    o--;
                                }
                                return e[t];
                            },
                        },
                        {
                            key: "isEditMode",
                            value: function () {
                                return this.config.environmentMode.edit;
                            },
                        },
                        {
                            key: "isWPPreviewMode",
                            value: function () {
                                return this.config.environmentMode.wpPreview;
                            },
                        },
                        {
                            key: "initDialogsManager",
                            value: function () {
                                var e = void 0;
                                this.getDialogsManager = function () {
                                    return (e =
                                        e || new DialogsManager.Instance());
                                };
                            },
                        },
                        {
                            key: "initHotKeys",
                            value: function () {
                                (this.hotKeys = new a.default()),
                                    this.hotKeys.bindListener(
                                        this.elements.$window
                                    );
                            },
                        },
                        {
                            key: "initOnReadyComponents",
                            value: function () {
                                (this.utils = {
                                    youtube: new h(),
                                    anchors: new p(),
                                    lightbox: new f(),
                                }),
                                    (this.modules = {
                                        StretchElement:
                                            elementorModules.frontend.tools
                                                .StretchElement,
                                        Masonry: elementorModules.utils.Masonry,
                                    }),
                                    (this.elementsHandler = new u(jQuery)),
                                    (this.documentsManager = new r.default()),
                                    this.trigger("components:init");
                            },
                        },
                        {
                            key: "initOnReadyElements",
                            value: function () {
                                this.elements.$wpAdminBar =
                                    this.elements.$document.find(
                                        this.getSettings("selectors.adminBar")
                                    );
                            },
                        },
                        {
                            key: "addIeCompatibility",
                            value: function () {
                                var e =
                                    "string" ==
                                    typeof document.createElement("div").style
                                        .grid;
                                (!d.default.ie && e) ||
                                    (this.elements.$body.addClass(
                                        this.getSettings("classes.ie")
                                    ),
                                    (e =
                                        '<link rel="stylesheet" id="elementor-frontend-css-msie" href="' +
                                        this.config.urls.assets +
                                        "css/frontend-msie.min.css?" +
                                        this.config.version +
                                        '" type="text/css" />'),
                                    this.elements.$body.append(e));
                            },
                        },
                        {
                            key: "setDeviceModeData",
                            value: function () {
                                this.elements.$body.attr(
                                    "data-elementor-device-mode",
                                    this.getCurrentDeviceMode()
                                );
                            },
                        },
                        {
                            key: "addListenerOnce",
                            value: function (e, t, n, i) {
                                (i = i || this.elements.$window),
                                    this.isEditMode()
                                        ? (this.removeListeners(e, t, i),
                                          i instanceof jQuery
                                              ? i.on(t + "." + e, n)
                                              : i.on(t, n, e))
                                        : i.on(t, n);
                            },
                        },
                        {
                            key: "removeListeners",
                            value: function (e, t, n, i) {
                                (i = i || this.elements.$window) instanceof
                                jQuery
                                    ? i.off(t + "." + e, n)
                                    : i.off(t, n, e);
                            },
                        },
                        {
                            key: "debounce",
                            value: function (i, o) {
                                var s = void 0;
                                return function () {
                                    var e = this,
                                        t = arguments,
                                        n = !s;
                                    clearTimeout(s),
                                        (s = setTimeout(function () {
                                            (s = null), i.apply(e, t);
                                        }, o)),
                                        n && i.apply(e, t);
                                };
                            },
                        },
                        {
                            key: "waypoint",
                            value: function (e, t, n) {
                                function i() {
                                    var e = this.element || this,
                                        e = t.apply(e, arguments);
                                    return (
                                        n.triggerOnce &&
                                            this.destroy &&
                                            this.destroy(),
                                        e
                                    );
                                }
                                n = jQuery.extend(
                                    { offset: "100%", triggerOnce: !0 },
                                    n
                                );
                                return e.elementorWaypoint
                                    ? e.elementorWaypoint(i, n)
                                    : e.waypoint(i, n);
                            },
                        },
                        {
                            key: "muteMigrationTraces",
                            value: function () {
                                (jQuery.migrateMute = !0),
                                    (jQuery.migrateTrace = !1);
                            },
                        },
                        {
                            key: "init",
                            value: function () {
                                (this.hooks = new c()),
                                    (this.storage = new l.default()),
                                    this.addIeCompatibility(),
                                    this.setDeviceModeData(),
                                    this.initDialogsManager(),
                                    this.isEditMode() &&
                                        this.muteMigrationTraces(),
                                    this.elements.$window.trigger(
                                        "elementor/frontend/init"
                                    ),
                                    this.isEditMode() || this.initHotKeys(),
                                    this.initOnReadyElements(),
                                    this.initOnReadyComponents();
                            },
                        },
                        {
                            key: "Module",
                            get: function () {
                                return elementorModules.frontend.handlers.Base;
                            },
                        },
                    ]),
                    s
                );
            })(elementorModules.ViewModule);
        (window.ceFrontend = new n()),
            ceFrontend.isEditMode() ||
                jQuery(function () {
                    return ceFrontend.init();
                });
    },
    183: function (e, t, n) {
        Object.defineProperty(t, "__esModule", { value: !0 });
        var i = function (e, t, n) {
            return t && o(e.prototype, t), n && o(e, n), e;
        };
        function o(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                (i.enumerable = i.enumerable || !1),
                    (i.configurable = !0),
                    "value" in i && (i.writable = !0),
                    Object.defineProperty(e, i.key, i);
            }
        }
        var n = n(17),
            r = (n = n) && n.__esModule ? n : { default: n };
        n = ((e) => {
            var t = s;
            if ("function" != typeof e && null !== e)
                throw new TypeError(
                    "Super expression must either be null or a function, not " +
                        typeof e
                );
            function s() {
                var e = this,
                    t = s;
                if (!(e instanceof t))
                    throw new TypeError("Cannot call a class as a function");
                for (var n = arguments.length, i = Array(n), o = 0; o < n; o++)
                    i[o] = arguments[o];
                t = ((e, t) => {
                    if (e)
                        return !t ||
                            ("object" != typeof t && "function" != typeof t)
                            ? e
                            : t;
                    throw new ReferenceError(
                        "this hasn't been initialised - super() hasn't been called"
                    );
                })(
                    this,
                    (e = s.__proto__ || Object.getPrototypeOf(s)).call.apply(
                        e,
                        [this].concat(i)
                    )
                );
                return (
                    (t.documents = {}),
                    t.initDocumentClasses(),
                    t.attachDocumentsClasses(),
                    t
                );
            }
            return (
                (t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0,
                    },
                })),
                e &&
                    (Object.setPrototypeOf
                        ? Object.setPrototypeOf(t, e)
                        : (t.__proto__ = e)),
                i(s, [
                    {
                        key: "getDefaultSettings",
                        value: function () {
                            return { selectors: { document: ".elementor" } };
                        },
                    },
                    {
                        key: "getDefaultElements",
                        value: function () {
                            var e = this.getSettings("selectors");
                            return { $documents: jQuery(e.document) };
                        },
                    },
                    {
                        key: "initDocumentClasses",
                        value: function () {
                            (this.documentClasses = { base: r.default }),
                                ceFrontend.hooks.doAction(
                                    "elementor/frontend/documents-manager/init-classes",
                                    this
                                );
                        },
                    },
                    {
                        key: "addDocumentClass",
                        value: function (e, t) {
                            this.documentClasses[e] = t;
                        },
                    },
                    {
                        key: "attachDocumentsClasses",
                        value: function () {
                            var n = this;
                            this.elements.$documents.each(function (e, t) {
                                return n.attachDocumentClass(jQuery(t));
                            });
                        },
                    },
                    {
                        key: "attachDocumentClass",
                        value: function (e) {
                            var t = e.data(),
                                n = t.elementorId,
                                t =
                                    this.documentClasses[t.elementorType] ||
                                    this.documentClasses.base;
                            this.documents[n] = new t({ $element: e, id: n });
                        },
                    },
                ]),
                s
            );
        })(elementorModules.ViewModule);
        t.default = n;
    },
    184: function (e, t, i) {
        e.exports = function (n) {
            var e = this,
                t = {
                    section: i(185),
                    "accordion.default": i(186),
                    "alert.default": i(187),
                    "counter.default": i(188),
                    "progress.default": i(189),
                    "tabs.default": i(190),
                    "toggle.default": i(191),
                    "video.default": i(192),
                    "image-carousel.default": i(193),
                    "text-editor.default": i(194),
                },
                s = {};
            (this.initHandlers = function () {
                ceFrontend.hooks.addAction(
                    "frontend/element_ready/global",
                    i(195)
                ),
                    n.each(t, function (e, t) {
                        ceFrontend.hooks.addAction(
                            "frontend/element_ready/" + e,
                            t
                        );
                    }),
                    ceFrontend.hooks.addAction(
                        "frontend/element_ready/section",
                        i(10)
                    ),
                    ceFrontend.hooks.addAction(
                        "frontend/element_ready/widget",
                        i(10)
                    );
            }),
                (this.addHandler = function (e, t) {
                    var n = t.$element.data("model-cid"),
                        i = void 0,
                        o =
                            (n &&
                                ((i = e.prototype.getConstructorID()),
                                s[n] || (s[n] = {}),
                                (o = s[n][i])) &&
                                o.onDestroy(),
                            new e(t));
                    n && (s[n][i] = o);
                }),
                (this.getHandlers = function (e) {
                    return e ? t[e] : t;
                }),
                (this.runReadyTrigger = function (e) {
                    var e = jQuery(e),
                        t = e.attr("data-element_type");
                    t &&
                        (ceFrontend.hooks.doAction(
                            "frontend/element_ready/global",
                            e,
                            n
                        ),
                        ceFrontend.hooks.doAction(
                            "frontend/element_ready/" + t,
                            e,
                            n
                        ),
                        "widget" === t) &&
                        ceFrontend.hooks.doAction(
                            "frontend/element_ready/" +
                                e.attr("data-widget_type"),
                            e,
                            n
                        );
                }),
                e.initHandlers();
        };
    },
    185: function (e, t, n) {
        var i = elementorModules.frontend.handlers.Base.extend({
                player: null,
                isYTVideo: null,
                getDefaultSettings: function () {
                    return {
                        selectors: {
                            backgroundVideoContainer:
                                ".elementor-background-video-container",
                            backgroundVideoEmbed:
                                ".elementor-background-video-embed",
                            backgroundVideoHosted:
                                ".elementor-background-video-hosted",
                        },
                    };
                },
                getDefaultElements: function () {
                    var e = this.getSettings("selectors"),
                        t = {
                            $backgroundVideoContainer: this.$element.find(
                                e.backgroundVideoContainer
                            ),
                        };
                    return (
                        (t.$backgroundVideoEmbed =
                            t.$backgroundVideoContainer.children(
                                e.backgroundVideoEmbed
                            )),
                        (t.$backgroundVideoHosted =
                            t.$backgroundVideoContainer.children(
                                e.backgroundVideoHosted
                            )),
                        t
                    );
                },
                calcVideosSize: function () {
                    var e =
                            this.elements.$backgroundVideoContainer.outerWidth(),
                        t =
                            this.elements.$backgroundVideoContainer.outerHeight(),
                        n = "16:9".split(":"),
                        n = n[0] / n[1],
                        i = n < e / t;
                    return { width: i ? e : t * n, height: i ? e / n : t };
                },
                changeVideoSize: function () {
                    var e, t;
                    (this.isYTVideo && !this.player) ||
                        ((e = this.isYTVideo
                            ? jQuery(this.player.getIframe())
                            : this.elements.$backgroundVideoHosted),
                        (t = this.calcVideosSize()),
                        e.width(t.width).height(t.height));
                },
                startVideoLoop: function () {
                    var e,
                        t,
                        n = this;
                    n.player.getIframe().contentWindow &&
                        ((e =
                            (t = n.getElementSettings())
                                .background_video_start || 0),
                        (t = t.background_video_end),
                        n.player.seekTo(e),
                        t) &&
                        setTimeout(function () {
                            n.startVideoLoop();
                        }, 1e3 * (t - e + 1));
                },
                prepareYTVideo: function (t, e) {
                    var n = this,
                        i = n.elements.$backgroundVideoContainer,
                        o = n.getElementSettings(),
                        s = t.PlayerState.PLAYING;
                    window.chrome && (s = t.PlayerState.UNSTARTED),
                        i.addClass("elementor-loading elementor-invisible"),
                        (n.player = new t.Player(
                            n.elements.$backgroundVideoEmbed[0],
                            {
                                videoId: e,
                                events: {
                                    onReady: function () {
                                        n.player.mute(),
                                            n.changeVideoSize(),
                                            n.startVideoLoop(),
                                            n.player.playVideo();
                                    },
                                    onStateChange: function (e) {
                                        switch (e.data) {
                                            case s:
                                                i.removeClass(
                                                    "elementor-invisible elementor-loading"
                                                );
                                                break;
                                            case t.PlayerState.ENDED:
                                                n.player.seekTo(
                                                    o.background_video_start ||
                                                        0
                                                );
                                        }
                                    },
                                },
                                playerVars: { controls: 0, rel: 0 },
                            }
                        ));
                },
                activate: function () {
                    var t = this,
                        e = t.getElementSettings("background_video_link"),
                        n = ceFrontend.utils.youtube.getYoutubeIDFromURL(e);
                    (t.isYTVideo = !!n),
                        n
                            ? ceFrontend.utils.youtube.onYoutubeApiReady(
                                  function (e) {
                                      setTimeout(function () {
                                          t.prepareYTVideo(e, n);
                                      });
                                  }
                              )
                            : t.elements.$backgroundVideoHosted
                                  .attr("src", e)
                                  .one("canplay", t.changeVideoSize),
                        ceFrontend.elements.$window.on(
                            "resize",
                            t.changeVideoSize
                        );
                },
                deactivate: function () {
                    this.isYTVideo && this.player.getIframe()
                        ? this.player.destroy()
                        : this.elements.$backgroundVideoHosted.removeAttr(
                              "src"
                          ),
                        ceFrontend.elements.$window.off(
                            "resize",
                            this.changeVideoSize
                        );
                },
                run: function () {
                    var e = this.getElementSettings();
                    "video" === e.background_background &&
                    e.background_video_link
                        ? this.activate()
                        : this.deactivate();
                },
                onInit: function () {
                    elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                        this,
                        arguments
                    ),
                        this.run();
                },
                onElementChange: function (e) {
                    "background_background" === e && this.run();
                },
            }),
            o = elementorModules.frontend.handlers.Base.extend({
                stretchElement: null,
                bindEvents: function () {
                    var e = this.getUniqueHandlerID();
                    ceFrontend.addListenerOnce(e, "resize", this.stretch),
                        ceFrontend.addListenerOnce(
                            e,
                            "sticky:stick",
                            this.stretch,
                            this.$element
                        ),
                        ceFrontend.addListenerOnce(
                            e,
                            "sticky:unstick",
                            this.stretch,
                            this.$element
                        );
                },
                unbindEvents: function () {
                    ceFrontend.removeListeners(
                        this.getUniqueHandlerID(),
                        "resize",
                        this.stretch
                    );
                },
                initStretch: function () {
                    this.stretchElement =
                        new elementorModules.frontend.tools.StretchElement({
                            element: this.$element,
                            selectors: {
                                container: this.getStretchContainer(),
                            },
                        });
                },
                getStretchContainer: function () {
                    return (
                        ceFrontend.getGeneralSettings(
                            "elementor_stretched_section_container"
                        ) || document.documentElement
                    );
                },
                stretch: function () {
                    this.getElementSettings("stretch_section") &&
                        this.stretchElement.stretch();
                },
                onInit: function () {
                    elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                        this,
                        arguments
                    ),
                        this.initStretch(),
                        this.stretch();
                },
                onElementChange: function (e) {
                    "stretch_section" === e &&
                        (this.getElementSettings("stretch_section")
                            ? this.stretch()
                            : this.stretchElement.reset());
                },
                onGeneralSettingsChange: function (e) {
                    "elementor_stretched_section_container" in e &&
                        (this.stretchElement.setSettings(
                            "selectors.container",
                            this.getStretchContainer()
                        ),
                        this.stretch());
                },
            }),
            s = elementorModules.frontend.handlers.Base.extend({
                getDefaultSettings: function () {
                    return {
                        selectors: { container: "> .elementor-shape-%s" },
                        svgURL: ceFrontend.config.urls.assets + "img/shapes/",
                    };
                },
                getDefaultElements: function () {
                    var e = {},
                        t = this.getSettings("selectors");
                    return (
                        (e.$topContainer = this.$element.find(
                            t.container.replace("%s", "top")
                        )),
                        (e.$bottomContainer = this.$element.find(
                            t.container.replace("%s", "bottom")
                        )),
                        e
                    );
                },
                getSvgURL: function (e, t) {
                    t = this.getSettings("svgURL") + t + ".svg";
                    return (t =
                        elementor.config.additional_shapes &&
                        e in elementor.config.additional_shapes
                            ? elementor.config.additional_shapes[e]
                            : t);
                },
                buildSVG: function (e) {
                    var t,
                        n = "shape_divider_" + e,
                        i = this.getElementSettings(n),
                        o = this.elements["$" + e + "Container"];
                    o.attr("data-shape", i),
                        i
                            ? ((t = i),
                              this.getElementSettings(n + "_negative") &&
                                  (t += "-negative"),
                              (n = this.getSvgURL(i, t)),
                              jQuery.get(n, function (e) {
                                  o.empty().append(e.childNodes[0]);
                              }),
                              this.setNegative(e))
                            : o.empty();
                },
                setNegative: function (e) {
                    this.elements["$" + e + "Container"].attr(
                        "data-negative",
                        !!this.getElementSettings(
                            "shape_divider_" + e + "_negative"
                        )
                    );
                },
                onInit: function () {
                    var t = this;
                    elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                        t,
                        arguments
                    ),
                        ["top", "bottom"].forEach(function (e) {
                            t.getElementSettings("shape_divider_" + e) &&
                                t.buildSVG(e);
                        });
                },
                onElementChange: function (e) {
                    var t = e.match(/^shape_divider_(top|bottom)$/);
                    t
                        ? this.buildSVG(t[1])
                        : (t = e.match(
                              /^shape_divider_(top|bottom)_negative$/
                          )) && (this.buildSVG(t[1]), this.setNegative(t[1]));
                },
            }),
            r = elementorModules.frontend.handlers.Base.extend({
                isFirstSection: function () {
                    return this.$element.is(
                        ".elementor-edit-mode .elementor-top-section:first"
                    );
                },
                isOverflowHidden: function () {
                    return "hidden" === this.$element.css("overflow");
                },
                getOffset: function () {
                    var e;
                    return "body" === elementor.config.document.container
                        ? this.$element.offset().top
                        : ((e = jQuery(elementor.config.document.container)),
                          this.$element.offset().top - e.offset().top);
                },
                setHandlesPosition: function () {
                    var e,
                        t,
                        n = this.isOverflowHidden();
                    (n || this.isFirstSection()) &&
                        ((n = n ? 0 : this.getOffset()),
                        (e = this.$element.find(
                            "> .elementor-element-overlay > .elementor-editor-section-settings"
                        )),
                        (t = "elementor-section--handles-inside"),
                        n < 25 ||
                        this.$element.closest(
                            '[data-elementor-type="product-quick-view"]'
                        ).length
                            ? (this.$element.addClass(t),
                              n < -5 ? e.css("top", -n) : e.css("top", ""))
                            : this.$element.removeClass(t));
                },
                onInit: function () {
                    this.setHandlesPosition(),
                        this.$element.on("mouseenter", this.setHandlesPosition);
                },
            });
        e.exports = function (e) {
            (ceFrontend.isEditMode() ||
                e.hasClass("elementor-section-stretched")) &&
                ceFrontend.elementsHandler.addHandler(o, { $element: e }),
                ceFrontend.isEditMode() &&
                    (ceFrontend.elementsHandler.addHandler(s, { $element: e }),
                    ceFrontend.elementsHandler.addHandler(r, { $element: e })),
                ceFrontend.elementsHandler.addHandler(i, { $element: e });
        };
    },
    186: function (e, t, n) {
        var i = n(18);
        e.exports = function (e) {
            ceFrontend.elementsHandler.addHandler(i, {
                $element: e,
                showTabFn: "slideDown",
                hideTabFn: "slideUp",
            });
        };
    },
    187: function (e, t, n) {
        e.exports = function (e, t) {
            e.find(".elementor-alert-dismiss").on("click", function () {
                t(this).parent().fadeOut();
            });
        };
    },
    188: function (e, t, n) {
        e.exports = function (e, i) {
            ceFrontend.waypoint(
                e.find(".elementor-counter-number"),
                function () {
                    var e = i(this),
                        t = e.data(),
                        n = t.toValue.toString().match(/\.(.*)/);
                    n && (t.rounding = n[1].length), e.numerator(t);
                }
            );
        };
    },
    189: function (e, t, n) {
        e.exports = function (e, t) {
            ceFrontend.waypoint(e.find(".elementor-progress-bar"), function () {
                var e = t(this);
                e.css("width", e.data("max") + "%");
            });
        };
    },
    190: function (e, t, n) {
        var i = n(18);
        e.exports = function (e) {
            ceFrontend.elementsHandler.addHandler(i, {
                $element: e,
                toggleSelf: !1,
            });
        };
    },
    191: function (e, t, n) {
        var i = n(18);
        e.exports = function (e) {
            ceFrontend.elementsHandler.addHandler(i, {
                $element: e,
                showTabFn: "slideDown",
                hideTabFn: "slideUp",
                hidePrevious: !1,
                autoExpand: "editor",
            });
        };
    },
    192: function (e, t, n) {
        var i = elementorModules.frontend.handlers.Base.extend({
            getDefaultSettings: function () {
                return {
                    selectors: {
                        imageOverlay: ".elementor-custom-embed-image-overlay",
                        video: ".elementor-video",
                        videoIframe: ".elementor-video-iframe",
                    },
                };
            },
            getDefaultElements: function () {
                var e = this.getSettings("selectors");
                return {
                    $imageOverlay: this.$element.find(e.imageOverlay),
                    $video: this.$element.find(e.video),
                    $videoIframe: this.$element.find(e.videoIframe),
                };
            },
            getLightBox: function () {
                return ceFrontend.utils.lightbox;
            },
            handleVideo: function () {
                this.getElementSettings("lightbox") ||
                    (this.elements.$imageOverlay.remove(), this.playVideo());
            },
            playVideo: function () {
                var e, t;
                this.elements.$video.length
                    ? this.elements.$video[0].play()
                    : ((t = (e = this.elements.$videoIframe).data(
                          "lazy-load"
                      )) && e.attr("src", t),
                      (t = e[0].src.replace("&autoplay=0", "")),
                      (e[0].src = t + "&autoplay=1"));
            },
            animateVideo: function () {
                this.getLightBox().setEntranceAnimation(
                    this.getCurrentDeviceSetting("lightbox_content_animation")
                );
            },
            handleAspectRatio: function () {
                this.getLightBox().setVideoAspectRatio(
                    this.getElementSettings("aspect_ratio")
                );
            },
            bindEvents: function () {
                this.elements.$imageOverlay.on("click", this.handleVideo);
            },
            onElementChange: function (e) {
                var t;
                0 === e.indexOf("lightbox_content_animation")
                    ? this.animateVideo()
                    : ((t = this.getElementSettings("lightbox")),
                      "lightbox" !== e || t
                          ? "aspect_ratio" === e &&
                            t &&
                            this.handleAspectRatio()
                          : this.getLightBox().getModal().hide());
            },
        });
        e.exports = function (e) {
            ceFrontend.elementsHandler.addHandler(i, { $element: e });
        };
    },
    193: function (e, t, n) {
        var i = elementorModules.frontend.handlers.Base.extend({
            getDefaultSettings: function () {
                return { selectors: { carousel: ".elementor-image-carousel" } };
            },
            getDefaultElements: function () {
                var e = this.getSettings("selectors");
                return { $carousel: this.$element.find(e.carousel) };
            },
            onInit: function () {
                elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                    this,
                    arguments
                );
                var e = this.getElementSettings(),
                    t = +e.slides_to_show || e.default_slides_count,
                    n = 1 === t,
                    i = e.center_padding && e.center_padding.size + "",
                    o =
                        e.center_padding_tablet &&
                        e.center_padding_tablet.size + "",
                    s =
                        e.center_padding_mobile &&
                        e.center_padding_mobile.size + "",
                    r = (!n && e.default_slides_count - 1) || 1,
                    a = ceFrontend.config.breakpoints,
                    t = {
                        touchThreshold: 100,
                        slidesToShow: t,
                        slidesToScroll: +e.slides_to_scroll || 1,
                        swipeToSlide: !e.slides_to_scroll,
                        variableWidth: "yes" === e.variable_width,
                        centerMode: "yes" === e.center_mode,
                        centerPadding: i ? i + e.center_padding.unit : void 0,
                        autoplay: "yes" === e.autoplay,
                        autoplaySpeed: e.autoplay_speed,
                        infinite: "yes" === e.infinite,
                        pauseOnHover: "yes" === e.pause_on_hover,
                        speed: e.speed,
                        arrows: -1 !== ["arrows", "both"].indexOf(e.navigation),
                        dots: -1 !== ["dots", "both"].indexOf(e.navigation),
                        rtl: "rtl" === e.direction,
                        responsive: [
                            {
                                breakpoint: a.lg,
                                settings: {
                                    centerPadding: o
                                        ? o + e.center_padding_tablet.unit
                                        : void 0,
                                    slidesToShow: +e.slides_to_show_tablet || r,
                                    slidesToScroll:
                                        +e.slides_to_scroll_tablet || 1,
                                    swipeToSlide: !e.slides_to_scroll_tablet,
                                    autoplay: "yes" === e.autoplay_tablet,
                                    infinite: e.infinite_tablet
                                        ? "yes" === e.infinite_tablet
                                        : void 0,
                                },
                            },
                            {
                                breakpoint: a.md,
                                settings: {
                                    centerPadding: s
                                        ? s + e.center_padding_mobile.unit
                                        : o
                                        ? o + e.center_padding_tablet.unit
                                        : void 0,
                                    slidesToShow: +e.slides_to_show_mobile || 1,
                                    slidesToScroll:
                                        +e.slides_to_scroll_mobile || 1,
                                    swipeToSlide: !e.slides_to_scroll_mobile,
                                    autoplay: "yes" === e.autoplay_mobile,
                                    infinite: e.infinite_mobile
                                        ? "yes" === e.infinite_mobile
                                        : void 0,
                                },
                            },
                        ],
                    };
                n && (t.fade = "fade" === e.effect),
                    this.elements.$carousel.slick(t);
            },
        });
        e.exports = function (e) {
            ceFrontend.elementsHandler.addHandler(i, { $element: e });
        };
    },
    194: function (e, t, n) {
        var i = elementorModules.frontend.handlers.Base.extend({
            dropCapLetter: "",
            getDefaultSettings: function () {
                return {
                    selectors: { paragraph: "p:first" },
                    classes: {
                        dropCap: "elementor-drop-cap",
                        dropCapLetter: "elementor-drop-cap-letter",
                    },
                };
            },
            getDefaultElements: function () {
                var e = this.getSettings("selectors"),
                    t = this.getSettings("classes"),
                    n = jQuery("<span>", { class: t.dropCap }),
                    t = jQuery("<span>", { class: t.dropCapLetter });
                return (
                    n.append(t),
                    {
                        $paragraph: this.$element.find(e.paragraph),
                        $dropCap: n,
                        $dropCapLetter: t,
                    }
                );
            },
            wrapDropCap: function () {
                var e, t, n, i;
                this.getElementSettings("drop_cap")
                    ? (e = this.elements.$paragraph).length &&
                      (n = (t = e.html().replace(/&nbsp;/g, " ")).match(
                          /^ *([^ ] ?)/
                      )) &&
                      "<" !== (i = (n = n[1]).trim()) &&
                      ((this.dropCapLetter = n),
                      this.elements.$dropCapLetter.text(i),
                      (i = t.slice(n.length).replace(/^ */, function (e) {
                          return new Array(e.length + 1).join("&nbsp;");
                      })),
                      e.html(i).prepend(this.elements.$dropCap))
                    : this.dropCapLetter &&
                      (this.elements.$dropCap.remove(),
                      this.elements.$paragraph.prepend(this.dropCapLetter),
                      (this.dropCapLetter = ""));
            },
            onInit: function () {
                elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                    this,
                    arguments
                ),
                    this.wrapDropCap();
            },
            onElementChange: function (e) {
                "drop_cap" === e && this.wrapDropCap();
            },
        });
        e.exports = function (e) {
            ceFrontend.elementsHandler.addHandler(i, { $element: e });
        };
    },
    195: function (e, t, n) {
        var i = elementorModules.frontend.handlers.Base.extend({
            getWidgetType: function () {
                return "global";
            },
            animate: function () {
                var e,
                    t = this.$element,
                    n = this.getAnimation();
                "none" === n
                    ? t.removeClass("elementor-invisible")
                    : ((e =
                          (e = this.getElementSettings())._animation_delay ||
                          e.animation_delay ||
                          0),
                      t.removeClass(n),
                      this.currentAnimation &&
                          t.removeClass(this.currentAnimation),
                      (this.currentAnimation = n),
                      setTimeout(function () {
                          t.removeClass("elementor-invisible").addClass(
                              "animated " + n
                          );
                      }, e));
            },
            getAnimation: function () {
                return (
                    this.getCurrentDeviceSetting("animation") ||
                    this.getCurrentDeviceSetting("_animation")
                );
            },
            onInit: function () {
                elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                    this,
                    arguments
                ),
                    this.getAnimation() &&
                        ceFrontend.waypoint(
                            this.$element,
                            this.animate.bind(this)
                        );
            },
            onElementChange: function (e) {
                /^_?animation/.test(e) && this.animate();
            },
        });
        e.exports = function (e) {
            ceFrontend.elementsHandler.addHandler(i, { $element: e });
        };
    },
    196: function (e, t, n) {
        e.exports = elementorModules.ViewModule.extend({
            getDefaultSettings: function () {
                return {
                    isInserted: !1,
                    APISrc: "https://www.youtube.com/iframe_api",
                    selectors: { firstScript: "script:first" },
                };
            },
            getDefaultElements: function () {
                return {
                    $firstScript: jQuery(
                        this.getSettings("selectors.firstScript")
                    ),
                };
            },
            insertYTAPI: function () {
                this.setSettings("isInserted", !0),
                    this.elements.$firstScript.before(
                        jQuery("<script>", { src: this.getSettings("APISrc") })
                    );
            },
            onYoutubeApiReady: function (e) {
                var t = this;
                t.getSettings("IsInserted") || t.insertYTAPI(),
                    window.YT && YT.loaded
                        ? e(YT)
                        : setTimeout(function () {
                              t.onYoutubeApiReady(e);
                          }, 350);
            },
            getYoutubeIDFromURL: function (e) {
                e = e.match(
                    /^(?:https?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?vi?=|(?:embed|v|vi|user)\/))([^?&"'>]+)/
                );
                return e && e[1];
            },
        });
    },
    197: function (e, t, n) {
        e.exports = elementorModules.ViewModule.extend({
            getDefaultSettings: function () {
                return {
                    scrollDuration: 500,
                    selectors: {
                        links: 'a[href*="#"]',
                        targets: ".elementor-element, .elementor-menu-anchor",
                        scrollable: "html, body",
                    },
                };
            },
            getDefaultElements: function () {
                return {
                    $scrollable: jQuery(
                        this.getSettings("selectors").scrollable
                    ),
                };
            },
            bindEvents: function () {
                ceFrontend.elements.$document.on(
                    "click",
                    this.getSettings("selectors.links"),
                    this.handleAnchorLinks
                );
            },
            handleAnchorLinks: function (e) {
                var t,
                    n = e.currentTarget,
                    i = location.pathname === n.pathname,
                    o = location.hostname === n.hostname;
                if (o && i && !(n.hash.length < 2)) {
                    try {
                        t = jQuery(n.hash).filter(
                            this.getSettings("selectors.targets")
                        );
                    } catch (e) {
                        return;
                    }
                    t.length &&
                        ((o = t.offset().top),
                        0 <
                            (i = jQuery(
                                ".elementor-section.elementor-sticky--active"
                            )).length &&
                            (o -= Math.max.apply(
                                null,
                                i
                                    .map(function () {
                                        return jQuery(this).outerHeight();
                                    })
                                    .get()
                            )),
                        e.preventDefault(),
                        (o = ceFrontend.hooks.applyFilters(
                            "frontend/handlers/menu_anchor/scroll_top_distance",
                            o
                        )),
                        this.elements.$scrollable.animate(
                            { scrollTop: o },
                            this.getSettings("scrollDuration")
                        ));
                }
            },
            onInit: function () {
                elementorModules.ViewModule.prototype.onInit.apply(
                    this,
                    arguments
                ),
                    this.bindEvents();
            },
        });
    },
    198: function (t, e, n) {
        t.exports = elementorModules.ViewModule.extend({
            oldAspectRatio: null,
            oldAnimation: null,
            swiper: null,
            getDefaultSettings: function () {
                return {
                    classes: {
                        aspectRatio: "elementor-aspect-ratio-%s",
                        item: "elementor-lightbox-item",
                        image: "elementor-lightbox-image",
                        videoContainer: "elementor-video-container",
                        videoWrapper: "elementor-fit-aspect-ratio",
                        playButton: "elementor-custom-embed-play",
                        playButtonIcon: "fa",
                        playing: "elementor-playing",
                        hidden: "elementor-hidden",
                        invisible: "elementor-invisible",
                        preventClose: "elementor-lightbox-prevent-close",
                        slideshow: {
                            container: "swiper-container",
                            slidesWrapper: "swiper-wrapper",
                            prevButton:
                                "elementor-swiper-button elementor-swiper-button-prev",
                            nextButton:
                                "elementor-swiper-button elementor-swiper-button-next",
                            prevButtonIcon: "fa fa-angle-left",
                            nextButtonIcon: "fa fa-angle-right",
                            slide: "swiper-slide",
                        },
                    },
                    selectors: {
                        links: "a, [data-elementor-lightbox]",
                        slideshow: {
                            activeSlide: ".swiper-slide-active",
                            prevSlide: ".swiper-slide-prev",
                            nextSlide: ".swiper-slide-next",
                        },
                    },
                    modalOptions: {
                        id: "elementor-lightbox",
                        entranceAnimation: "zoomIn",
                        videoAspectRatio: 169,
                        position: { enable: !1 },
                    },
                };
            },
            getModal: function () {
                return t.exports.modal || this.initModal(), t.exports.modal;
            },
            initModal: function () {
                var e = (t.exports.modal = ceFrontend
                    .getDialogsManager()
                    .createWidget("lightbox", {
                        className: "elementor-lightbox",
                        closeButton: !0,
                        closeButtonClass: "ceicon-close",
                        selectors: {
                            preventClose:
                                "." + this.getSettings("classes.preventClose"),
                        },
                        hide: { onClick: !0 },
                    }));
                e.on("hide", function () {
                    e.setMessage("");
                });
            },
            showModal: function (e) {
                var t = this,
                    n = t.getDefaultSettings().modalOptions,
                    i =
                        (t.setSettings(
                            "modalOptions",
                            jQuery.extend(n, e.modalOptions)
                        ),
                        t.getModal());
                switch (
                    (i.setID(t.getSettings("modalOptions.id")),
                    (i.onShow = function () {
                        DialogsManager.getWidgetType(
                            "lightbox"
                        ).prototype.onShow.apply(i, arguments),
                            t.setEntranceAnimation();
                    }),
                    (i.onHide = function () {
                        DialogsManager.getWidgetType(
                            "lightbox"
                        ).prototype.onHide.apply(i, arguments),
                            i.getElements("message").removeClass("animated");
                    }),
                    e.type)
                ) {
                    case "image":
                        t.setImageContent(e.url);
                        break;
                    case "video":
                        t.setVideoContent(e);
                        break;
                    case "slideshow":
                        t.setSlideshowContent(e.slideshow);
                        break;
                    default:
                        t.setHTMLContent(e.html);
                }
                i.show();
            },
            setHTMLContent: function (e) {
                this.getModal().setMessage(e);
            },
            setImageContent: function (e) {
                var t = this.getSettings("classes"),
                    n = jQuery("<div>", { class: t.item }),
                    e = jQuery("<img>", {
                        src: e,
                        class: t.image + " " + t.preventClose,
                    });
                n.append(e), this.getModal().setMessage(n);
            },
            setVideoContent: function (e) {
                var t,
                    n = this.getSettings("classes"),
                    i = jQuery("<div>", { class: n.videoContainer }),
                    n = jQuery("<div>", { class: n.videoWrapper }),
                    o = this.getModal(),
                    s =
                        ((e =
                            "hosted" === e.videoType
                                ? ((t = jQuery.extend(
                                      { src: e.url, autoplay: "" },
                                      e.videoParams
                                  )),
                                  jQuery("<video>", t))
                                : ((t =
                                      e.url.replace("&autoplay=0", "") +
                                      "&autoplay=1"),
                                  jQuery("<iframe>", {
                                      src: t,
                                      allowfullscreen: 1,
                                  }))),
                        i.append(n),
                        n.append(e),
                        o.setMessage(i),
                        this.setVideoAspectRatio(),
                        o.onHide);
                o.onHide = function () {
                    s(),
                        o
                            .getElements("message")
                            .removeClass("elementor-fit-aspect-ratio");
                };
            },
            setSlideshowContent: function (t) {
                var i = jQuery,
                    n = this,
                    o = n.getSettings("classes"),
                    s = o.slideshow,
                    r = i("<div>", { class: s.container }),
                    a = i("<div>", { class: s.slidesWrapper }),
                    l = i("<div>", {
                        class: s.prevButton + " " + o.preventClose,
                    }).html(i("<i>", { class: s.prevButtonIcon })),
                    d = i("<div>", {
                        class: s.nextButton + " " + o.preventClose,
                    }).html(i("<i>", { class: s.nextButtonIcon })),
                    e =
                        (t.slides.forEach(function (e) {
                            var t,
                                n = s.slide + " " + o.item,
                                n =
                                    (e.video && (n += " " + o.video),
                                    i("<div>", { class: n }));
                            e.video
                                ? (n.attr(
                                      "data-elementor-slideshow-video",
                                      e.video
                                  ),
                                  (t = i("<div>", { class: o.playButton }).html(
                                      i("<i>", { class: o.playButtonIcon })
                                  )),
                                  n.append(t))
                                : ((t = i("<div>", {
                                      class: "swiper-zoom-container",
                                  })),
                                  (e = i("<img>", {
                                      class: o.image + " " + o.preventClose,
                                      src: e.image,
                                  })),
                                  t.append(e),
                                  n.append(t)),
                                a.append(n);
                        }),
                        r.append(a, l, d),
                        n.getModal()),
                    c = (e.setMessage(r), e.onShow);
                e.onShow = function () {
                    c();
                    var e = {
                        navigation: { prevEl: l, nextEl: d },
                        pagination: { clickable: !0 },
                        on: { slideChangeTransitionEnd: n.onSlideChange },
                        grabCursor: !0,
                        runCallbacksOnInit: !1,
                        loop: !0,
                        keyboard: !0,
                    };
                    t.swiper && i.extend(e, t.swiper),
                        (n.swiper = new Swiper(r, e)),
                        n.setVideoAspectRatio(),
                        n.playSlideVideo();
                };
            },
            setVideoAspectRatio: function (e) {
                e = e || this.getSettings("modalOptions.videoAspectRatio");
                var t = this.getModal().getElements("widgetContent"),
                    n = this.oldAspectRatio,
                    i = this.getSettings("classes.aspectRatio");
                (this.oldAspectRatio = e),
                    n && t.removeClass(i.replace("%s", n)),
                    e && t.addClass(i.replace("%s", e));
            },
            getSlide: function (e) {
                return jQuery(this.swiper.slides).filter(
                    this.getSettings("selectors.slideshow." + e + "Slide")
                );
            },
            playSlideVideo: function () {
                var e,
                    t,
                    n,
                    i,
                    o = this.getSlide("active"),
                    s = o.data("elementor-slideshow-video");
                s &&
                    ((e = this.getSettings("classes")),
                    (t = jQuery("<div>", {
                        class: e.videoContainer + " " + e.invisible,
                    })),
                    (n = jQuery("<div>", { class: e.videoWrapper })),
                    (s = jQuery("<iframe>", { src: s })),
                    (i = o.children("." + e.playButton)),
                    t.append(n),
                    n.append(s),
                    o.append(t),
                    i.addClass(e.playing).removeClass(e.hidden),
                    s.on("load", function () {
                        i.addClass(e.hidden), t.removeClass(e.invisible);
                    }));
            },
            setEntranceAnimation: function (e) {
                e =
                    e ||
                    ceFrontend.getCurrentDeviceSetting(
                        this.getSettings("modalOptions"),
                        "entranceAnimation"
                    );
                var t = this.getModal().getElements("message");
                this.oldAnimation && t.removeClass(this.oldAnimation),
                    (this.oldAnimation = e) && t.addClass("animated " + e);
            },
            isLightboxLink: function (e) {
                var t;
                return (
                    !(
                        "A" === e.tagName &&
                        (e.hasAttribute("download") ||
                            !/\.(png|jpe?g|gif|svg)(\?.*)?$/i.test(e.href))
                    ) &&
                    ((t = +ceFrontend.getGeneralSettings(
                        "elementor_global_image_lightbox"
                    )),
                    "yes" === (e = e.dataset.elementorOpenLightbox) ||
                        (t && "no" !== e))
                );
            },
            openLink: function (e) {
                var t,
                    n,
                    i,
                    o,
                    s,
                    r = e.currentTarget,
                    a = jQuery(e.target),
                    l = ceFrontend.isEditMode(),
                    a = !!a.closest("#elementor").length;
                this.isLightboxLink(r)
                    ? (e.preventDefault(),
                      (l &&
                          !ceFrontend.getGeneralSettings(
                              "elementor_enable_lightbox_in_editor"
                          )) ||
                          ((s = {}),
                          (s = r.dataset.elementorLightbox
                              ? JSON.parse(r.dataset.elementorLightbox)
                              : s).type && "slideshow" !== s.type
                              ? this.showModal(s)
                              : r.dataset.elementorLightboxSlideshow
                              ? ((t = r.dataset.elementorLightboxSlideshow),
                                (n = jQuery(
                                    this.getSettings("selectors.links")
                                ).filter(function () {
                                    return (
                                        t ===
                                        this.dataset.elementorLightboxSlideshow
                                    );
                                })),
                                (i = []),
                                (o = {}),
                                n.each(function () {
                                    var e = this.dataset.elementorLightboxVideo,
                                        t = e || this.href;
                                    o[t] ||
                                        ((o[t] = !0),
                                        void 0 ===
                                            (t =
                                                this.dataset
                                                    .elementorLightboxIndex) &&
                                            (t = n.index(this)),
                                        (t = { image: this.href, index: t }),
                                        e && (t.video = e),
                                        i.push(t));
                                }),
                                i.sort(function (e, t) {
                                    return e.index - t.index;
                                }),
                                void 0 ===
                                    (s = r.dataset.elementorLightboxIndex) &&
                                    (s = n.index(r)),
                                this.showModal({
                                    type: "slideshow",
                                    modalOptions: {
                                        id: "elementor-lightbox-slideshow-" + t,
                                    },
                                    slideshow: {
                                        slides: i,
                                        swiper: { initialSlide: +s },
                                    },
                                }))
                              : this.showModal({ type: "image", url: r.href })))
                    : l && a && e.preventDefault();
            },
            bindEvents: function () {
                ceFrontend.elements.$document.on(
                    "click",
                    this.getSettings("selectors.links"),
                    this.openLink
                );
            },
            onSlideChange: function () {
                this.getSlide("prev")
                    .add(this.getSlide("next"))
                    .add(this.getSlide("active"))
                    .find("." + this.getSettings("classes.videoWrapper"))
                    .remove(),
                    this.playSlideVideo();
            },
        });
    },
    200: function (e, t, n) {
        var i,
            o = ((i = {
                constructor: function (e) {
                    (this.$element = e),
                        (this.settings = {
                            selectors: {
                                form: "form",
                                submitButton: '[type="submit"]',
                            },
                        }),
                        (this.elements = {}),
                        (this.elements.$form = this.$element.find(
                            this.settings.selectors.form
                        )),
                        (this.elements.$submitButton = this.elements.$form.find(
                            this.settings.selectors.submitButton
                        )),
                        this.bindEvents();
                },
                bindEvents: function () {
                    this.elements.$form.on(
                        "submit",
                        $.proxy(this, "handleSubmit")
                    );
                },
                beforeSend: function () {
                    var e = this.elements.$form;
                    e
                        .animate({ opacity: "0.45" }, 500)
                        .addClass("elementor-form-waiting"),
                        e.find(".elementor-message").remove(),
                        e
                            .find(".elementor-error")
                            .removeClass("elementor-error"),
                        e
                            .find("div.elementor-field-group")
                            .removeClass("error")
                            .find("span.elementor-form-help-inline")
                            .remove()
                            .end()
                            .find(":input")
                            .attr("aria-invalid", "false"),
                        this.elements.$submitButton
                            .attr("disabled", "disabled")
                            .find("> span")
                            .prepend(
                                '<span class="elementor-button-text elementor-form-spinner"><i class="fa fa-spinner fa-spin"></i>&nbsp;</span>'
                            );
                },
                getFormData: function () {
                    var e = new FormData(this.elements.$form[0]);
                    return (
                        e.append(
                            this.elements.$submitButton[0].name,
                            this.elements.$submitButton[0].value
                        ),
                        e
                    );
                },
                onSuccess: function (e, t) {
                    var n,
                        i = this.elements.$form,
                        o = "before" === i.data("msg") ? "prepend" : "append";
                    this.elements.$submitButton
                        .removeAttr("disabled")
                        .find(".elementor-form-spinner")
                        .remove(),
                        i
                            .animate({ opacity: "1" }, 100)
                            .removeClass("elementor-form-waiting"),
                        e.success
                            ? ((n = i.data("success") || e.success),
                              i.trigger("submit_success", e),
                              i.trigger("form_destruct", e),
                              i.trigger("reset"),
                              i[o](
                                  '<div class="elementor-message elementor-message-success" role="alert">' +
                                      n +
                                      "</div>"
                              ))
                            : ((n =
                                  i.data("error") ||
                                  (e.errors && e.errors.join("<br>")) ||
                                  "Unknown error"),
                              i[o](
                                  '<div class="elementor-message elementor-message-danger" role="alert">' +
                                      n +
                                      "</div>"
                              ));
                },
                onError: function (e, t) {
                    var n = this.elements.$form;
                    n.append(
                        '<div class="elementor-message elementor-message-danger" role="alert">' +
                            t +
                            "</div>"
                    ),
                        this.elements.$submitButton
                            .html(this.elements.$submitButton.text())
                            .removeAttr("disabled"),
                        n
                            .animate({ opacity: "1" }, 100)
                            .removeClass("elementor-form-waiting"),
                        n.trigger("error");
                },
                handleSubmit: function (e) {
                    var t = this.elements.$form;
                    if (
                        (e.preventDefault(),
                        t.hasClass("elementor-form-waiting"))
                    )
                        return !1;
                    this.beforeSend(),
                        $.ajax({
                            url: t.attr("action"),
                            type: "POST",
                            dataType: "json",
                            data: this.getFormData(),
                            processData: !1,
                            contentType: !1,
                            success: $.proxy(this, "onSuccess"),
                            error: $.proxy(this, "onError"),
                        });
                },
            }).constructor.prototype = i).constructor;
        e.exports = function (e, t) {
            new o(e);
        };
    },
    201: function (e, t, n) {
        e.exports = elementorModules.frontend.handlers.Base.extend({
            getDefaultSettings: function () {
                return {
                    selectors: {
                        mainSwiper: ".elementor-main-swiper",
                        swiperSlide: ".swiper-slide",
                    },
                    slidesPerView: { desktop: 3, tablet: 2, mobile: 1 },
                };
            },
            getDefaultElements: function () {
                var e = this.getSettings("selectors"),
                    t = { $mainSwiper: this.$element.find(e.mainSwiper) };
                return (
                    (t.$mainSwiperSlides = t.$mainSwiper.find(e.swiperSlide)), t
                );
            },
            getSlidesCount: function () {
                return this.elements.$mainSwiperSlides.length;
            },
            getInitialSlide: function () {
                var e = this.getEditSettings();
                return e.activeItemIndex ? e.activeItemIndex - 1 : 0;
            },
            getEffect: function () {
                return this.getElementSettings("effect");
            },
            getDeviceSlidesPerView: function (e) {
                var t = "slides_per_view" + ("desktop" === e ? "" : "_" + e);
                return Math.min(
                    this.getSlidesCount(),
                    +this.getElementSettings(t) ||
                        this.getSettings("slidesPerView")[e]
                );
            },
            getSlidesPerView: function (e) {
                return "slide" === this.getEffect()
                    ? this.getDeviceSlidesPerView(e)
                    : 1;
            },
            getDesktopSlidesPerView: function () {
                return this.getSlidesPerView("desktop");
            },
            getTabletSlidesPerView: function () {
                return this.getSlidesPerView("tablet");
            },
            getMobileSlidesPerView: function () {
                return this.getSlidesPerView("mobile");
            },
            getDeviceSlidesToScroll: function (e) {
                e = "slides_to_scroll" + ("desktop" === e ? "" : "_" + e);
                return Math.min(
                    this.getSlidesCount(),
                    +this.getElementSettings(e) || 1
                );
            },
            getSlidesToScroll: function (e) {
                return "slide" === this.getEffect()
                    ? this.getDeviceSlidesToScroll(e)
                    : 1;
            },
            getDesktopSlidesToScroll: function () {
                return this.getSlidesToScroll("desktop");
            },
            getTabletSlidesToScroll: function () {
                return this.getSlidesToScroll("tablet");
            },
            getMobileSlidesToScroll: function () {
                return this.getSlidesToScroll("mobile");
            },
            getSpaceBetween: function (e) {
                var t = "space_between",
                    e =
                        (e && "desktop" !== e && (t += "_" + e),
                        this.getElementSettings(t));
                return (e && e.size) || 0;
            },
            getSwiperOptions: function () {
                var e,
                    t,
                    n = this.getElementSettings(),
                    i =
                        ("progress" === n.pagination &&
                            (n.pagination = "progressbar"),
                        {
                            grabCursor: !0,
                            initialSlide: this.getInitialSlide(),
                            centeredSlides: n.centered_slides,
                            slidesPerView: this.getDesktopSlidesPerView(),
                            slidesPerGroup: this.getDesktopSlidesToScroll(),
                            spaceBetween: this.getSpaceBetween(),
                            loop: "yes" === n.loop,
                            speed: n.speed,
                            effect: this.getEffect(),
                        });
                return (
                    n.show_arrows &&
                        (i.navigation = {
                            prevEl: ".elementor-swiper-button-prev",
                            nextEl: ".elementor-swiper-button-next",
                        }),
                    n.pagination &&
                        (i.pagination = {
                            el: ".swiper-pagination",
                            type: n.pagination,
                            clickable: !0,
                        }),
                    "cube" !== this.getEffect() &&
                        (((e = {})[(t = ceFrontend.config.breakpoints).lg - 1] =
                            {
                                slidesPerView: this.getTabletSlidesPerView(),
                                slidesPerGroup: this.getTabletSlidesToScroll(),
                                spaceBetween: this.getSpaceBetween("tablet"),
                            }),
                        (e[t.md - 1] = {
                            slidesPerView: this.getMobileSlidesPerView(),
                            slidesPerGroup: this.getMobileSlidesToScroll(),
                            spaceBetween: this.getSpaceBetween("mobile"),
                        }),
                        (i.breakpoints = e)),
                    !this.isEdit &&
                        n.autoplay &&
                        (i.autoplay = {
                            delay: n.autoplay_speed,
                            disableOnInteraction: !!n.pause_on_interaction,
                        }),
                    i
                );
            },
            updateSpaceBetween: function (e, t) {
                var t = t.match("space_between_(.*)"),
                    t = t ? t[1] : "desktop",
                    n = this.getSpaceBetween(t),
                    i = ceFrontend.config.breakpoints;
                "desktop" !== t
                    ? ((i = { tablet: i.lg - 1, mobile: i.md - 1 }),
                      (e.params.breakpoints[i[t]].spaceBetween = n))
                    : (e.originalParams.spaceBetween = n),
                    (e.params.spaceBetween = n),
                    e.update();
            },
            onInit: function () {
                elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                    this,
                    arguments
                ),
                    (this.swipers = {}),
                    this.getSlidesCount() <= 1 ||
                        (this.swipers.main = new Swiper(
                            this.elements.$mainSwiper,
                            this.getSwiperOptions()
                        ));
            },
            onElementChange: function (e) {
                this.getSlidesCount() <= 1 ||
                    (0 === e.indexOf("width") && this.swipers.main.update(),
                    0 === e.indexOf("space_between") &&
                        this.updateSpaceBetween(this.swipers.main, e));
            },
            onEditSettingsChange: function (e) {
                this.getSlidesCount() <= 1 ||
                    ("activeItemIndex" === e &&
                        this.swipers.main.slideToLoop(
                            this.getEditSettings("activeItemIndex") - 1
                        ));
            },
        });
    },
    202: function (e, t, n) {
        var i = n(201),
            o = i.extend({
                slideshowSpecialElementSettings: [
                    "slides_per_view",
                    "slides_per_view_tablet",
                    "slides_per_view_mobile",
                ],
                isSlideshow: function () {
                    return "slideshow" === this.getElementSettings("skin");
                },
                getDefaultSettings: function () {
                    var e = i.prototype.getDefaultSettings.apply(
                        this,
                        arguments
                    );
                    return (
                        this.isSlideshow() &&
                            ((e.selectors.thumbsSwiper =
                                ".elementor-thumbnails-swiper"),
                            (e.slidesPerView = {
                                desktop: 5,
                                tablet: 4,
                                mobile: 3,
                            })),
                        e
                    );
                },
                getElementSettings: function (e) {
                    return (
                        -1 !==
                            this.slideshowSpecialElementSettings.indexOf(e) &&
                            this.isSlideshow() &&
                            (e = "slideshow_" + e),
                        i.prototype.getElementSettings.call(this, e)
                    );
                },
                getDefaultElements: function () {
                    var e = this.getSettings("selectors"),
                        t = i.prototype.getDefaultElements.apply(
                            this,
                            arguments
                        );
                    return (
                        this.isSlideshow() &&
                            (t.$thumbsSwiper = this.$element.find(
                                e.thumbsSwiper
                            )),
                        t
                    );
                },
                getSlidesPerView: function (e) {
                    return this.isSlideshow()
                        ? 1
                        : "coverflow" === this.getEffect()
                        ? this.getDeviceSlidesPerView(e)
                        : i.prototype.getSlidesPerView.apply(this, arguments);
                },
                getThumbSpaceBetween: function (e) {
                    var t = "thumb_space_between";
                    return (
                        e && "desktop" !== e && (t += "_" + e),
                        this.getElementSettings(t).size || 0
                    );
                },
                getSwiperOptions: function () {
                    var e = i.prototype.getSwiperOptions.apply(this, arguments);
                    return (
                        this.isSlideshow() &&
                            ((e.loopedSlides = this.getSlidesCount()),
                            delete e.pagination,
                            delete e.breakpoints),
                        e
                    );
                },
                onInit: function () {
                    var e, t, n, i, o, s;
                    elementorModules.frontend.handlers.Base.prototype.onInit.apply(
                        this,
                        arguments
                    ),
                        (this.swipers = {}),
                        this.getSlidesCount() &&
                            ((e = this.getSwiperOptions()),
                            this.isSlideshow() &&
                                ((t = this.getElementSettings()),
                                (n = {}),
                                (o = ceFrontend.config.breakpoints),
                                (i = this.getSettings("slidesPerView")),
                                (n[o.lg - 1] = {
                                    slidesPerView:
                                        +t.slides_per_view_tablet || i.tablet,
                                    spaceBetween:
                                        this.getThumbSpaceBetween("tablet"),
                                }),
                                (n[o.md - 1] = {
                                    slidesPerView:
                                        +t.slides_per_view_mobile || i.mobile,
                                    spaceBetween:
                                        this.getThumbSpaceBetween("mobile"),
                                }),
                                (o = {
                                    slidesPerView:
                                        +t.slides_per_view || i.desktop,
                                    initialSlide: this.getInitialSlide(),
                                    slideToClickedSlide: !0,
                                    spaceBetween: this.getThumbSpaceBetween(),
                                    watchSlidesVisibility: !0,
                                    watchSlidesProgress: !0,
                                    breakpoints: n,
                                    direction:
                                        "bottom" === t.position
                                            ? "horizontal"
                                            : "vertical",
                                }),
                                (s = this.swipers.thumbs =
                                    new Swiper(this.elements.$thumbsSwiper, o)),
                                (e.thumbs = {
                                    swiper: this.swipers.thumbs,
                                    slideThumbActiveClass:
                                        "swiper-slide-active",
                                }),
                                (e.on = {
                                    slideChange: function () {
                                        setTimeout(function () {
                                            var e = $(s.slides).filter(
                                                ".swiper-slide-active"
                                            );
                                            s.slides.removeClass(
                                                "swiper-slide-prev swiper-slide-next"
                                            ),
                                                e
                                                    .prevAll()
                                                    .addClass(
                                                        "swiper-slide-prev"
                                                    ),
                                                e
                                                    .nextAll()
                                                    .addClass(
                                                        "swiper-slide-next"
                                                    );
                                        });
                                    },
                                })),
                            (this.swipers.main = new Swiper(
                                this.elements.$mainSwiper,
                                e
                            )),
                            this.swipers.thumbs) &&
                            (this.swipers.thumbs.main = this.swipers.main);
                },
                onElementChange: function (e) {
                    this.getSlidesCount() <= 1 ||
                        (this.isSlideshow()
                            ? (0 === e.indexOf("width") &&
                                  (this.swipers.main.update(),
                                  this.swipers.thumbs.update()),
                              0 === e.indexOf("space_between") &&
                                  this.updateSpaceBetween(
                                      this.swipers.thumbs,
                                      e
                                  ))
                            : i.prototype.onElementChange.apply(
                                  this,
                                  arguments
                              ));
                },
            });
        e.exports = function (e) {
            new o({ $element: e });
        };
    },
}),
    $("html").on("click.ce", ".elementor-quick-view", function (e) {
        e.preventDefault(),
            window.prestashop && prestashop.emit
                ? prestashop.emit("clickQuickView", {
                      dataset: $(this)
                          .closest(".elementor-product-miniature")
                          .data(),
                  })
                : (this.rel = $(this)
                      .addClass("quick-view")
                      .closest("a")
                      .prop("href"));
    }),
    $(function () {
        $("#js-product-list-header").attr("id", "product-list-header");
    });
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */
jQuery.fn.rating = function (generalOptions) {
    const $ratings = $(this);
    $ratings.each(function initRating() {
        const $ratingComponent = $(this);
        var options = generalOptions ? generalOptions : {};
        if (!options.grade && $ratingComponent.data("grade")) {
            options.grade = $ratingComponent.data("grade");
        }
        if (!options.min && $ratingComponent.data("min")) {
            options.min = $ratingComponent.data("min");
        }
        if (!options.max && $ratingComponent.data("max")) {
            options.max = $ratingComponent.data("max");
        }
        if (!options.input && $ratingComponent.data("input")) {
            options.input = $ratingComponent.data("input");
        }
        var componentOptions = jQuery.extend(
            { grade: null, input: null, min: 1, max: 5, starWidth: 16 },
            options
        );
        const minValue = Math.min(componentOptions.min, componentOptions.max);
        const maxValue = Math.max(componentOptions.min, componentOptions.max);
        const ratingValue = Math.min(
            Math.max(minValue, componentOptions.grade),
            maxValue
        );
        $ratingComponent.html("");
        $ratingComponent.append('<div class="star-content star-empty"></div>');
        $ratingComponent.append(
            '<div class="star-content star-full oh"></div>'
        );
        $ratingComponent.removeClass("pk-loader");
        const emptyStars = $(".star-empty", this);
        const fullStars = $(".star-full", this);
        const emptyStar = $(
            '<div class="star"><svg class="svgic svgic-pk-star"><use href="' +
                prestashop.urls.img_url +
                'lib.svg#pk-star"></use></svg></div>'
        );
        const fullStar = $(
            '<div class="star-on"><svg class="svgic svgic-pk-star"><use href="' +
                prestashop.urls.img_url +
                'lib.svg#star"></use></svg></div>'
        );
        var ratingInput;
        if (componentOptions.input) {
            ratingInput = $(
                '<input type="number" name="' +
                    componentOptions.input +
                    '" id="' +
                    componentOptions.input +
                    '" />'
            );
            ratingInput.val(ratingValue);
            ratingInput.css("display", "none");
            ratingInput.on("change", displayInteractiveGrade);
            $ratingComponent.append(ratingInput);
            initInteractiveGrade();
        } else {
            displayGrade(ratingValue);
        }
        function initInteractiveGrade() {
            emptyStars.html("");
            fullStars.html("");
            var newStar;
            for (var i = minValue; i <= maxValue; ++i) {
                newStar = emptyStar.clone();
                newStar.data("grade", i);
                newStar.on("mouseenter mouseleave", function overStar() {
                    var overIndex = $(".star", fullStars).index($(this));
                    $(".star", fullStars).each(function overStars() {
                        $(this).removeClass("star-on");
                        var starIndex = $(".star", fullStars).index($(this));
                        if (starIndex <= overIndex) {
                            $(this).addClass("star-hover");
                        } else {
                            $(this).removeClass("star-hover");
                        }
                    });
                });
                newStar.on("click", function selectGrade() {
                    var selectedGrade = $(this).data("grade");
                    ratingInput.val(selectedGrade);
                    ratingChosen = !0;
                });
                fullStars.append(newStar);
            }
            fullStars
                .on("mouseenter", function () {})
                .on("mouseleave", displayInteractiveGrade);
            displayInteractiveGrade();
        }
        function displayInteractiveGrade() {
            $(".star", fullStars).each(function displayStar() {
                var starValue = $(this).data("grade");
                $(this).removeClass("star-hover");
                if (starValue <= ratingInput.val()) {
                    $(this).addClass("star-on");
                } else {
                    $(this).removeClass("star-on");
                }
            });
        }
        function displayGrade(grade) {
            emptyStars.html("");
            fullStars.html("");
            var newStar;
            for (var i = minValue; i <= maxValue; ++i) {
                if (i <= Math.floor(grade)) {
                    newStar = emptyStar.clone();
                    newStar.css("visibility", "hidden");
                    emptyStars.append(newStar);
                    fullStars.append(fullStar.clone());
                } else if (i > Math.ceil(grade)) {
                    newStar = emptyStar.clone();
                    emptyStars.append(newStar.clone());
                } else {
                    var fullWidth =
                        (grade - i + 1) * componentOptions.starWidth;
                    newStar = emptyStar.clone();
                    emptyStars.append(newStar);
                    fullStar.css("width", fullWidth);
                    fullStars.append(fullStar.clone());
                }
            }
        }
    });
};
/**
 * 2007-2019 PrestaShop SA and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2019 PrestaShop SA and Contributors
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */
$(document).ready(function () {
    productListingComments.init();
    productListingComments.load();
});
var productListingComments = (function () {
    var data = {
        productIDs: [],
        commentsLoadingInProgress: !1,
        ajaxIDsLimit: 50,
        ajaxUrl: "",
    };
    var DOMStrings = {
        productListReviewsContainer: ".product-list-reviews",
        productListReviewsNumberOfComments: ".comments-nb",
        productListReviewsStarsContainer: ".grade-stars",
        productContainer: ".thumbnail-container",
    };
    var DOMClasses = {
        inProgress: "reviews-loading",
        reviewsLoaded: "reviews-loaded",
        hasReviews: "has-reviews",
    };
    function setEvents() {
        prestashop.on("updateProductList", function () {
            addProductsIDs();
        });
    }
    function setAjaxUrl() {
        if (data.ajaxUrl !== "") return;
        var url = $(DOMStrings.productListReviewsContainer).first().data("url");
        data.ajaxUrl = url;
    }
    function getNewProductsReviewsElements() {
        var $productListReviews = $(DOMStrings.productContainer)
            .not("." + DOMClasses.reviewsLoaded + ", ." + DOMClasses.inProgress)
            .addClass(DOMClasses.inProgress)
            .find(DOMStrings.productListReviewsContainer);
        return $productListReviews;
    }
    function addProductsIDs() {
        var $productsList = getNewProductsReviewsElements(),
            seenIds = {};
        $productsList.each(function () {
            var id = $(this).data("id");
            seenIds[id] = !0;
        });
        var IDsArray = Object.keys(seenIds).filter((e) => e !== "undefined");
        var prevDataIDs = data.productIDs.splice(0);
        data.productIDs = prevDataIDs.concat(IDsArray);
        if (!data.commentsLoadingInProgress) {
            loadProductsData();
        }
    }
    function loadProductsData() {
        if (data.productIDs.length === 0) return;
        data.commentsLoadingInProgress = !0;
        var dataIDsCopy = data.productIDs.slice(0);
        selectedProductIDs = dataIDsCopy.splice(0, data.ajaxIDsLimit);
        $.get(
            data.ajaxUrl,
            { id_products: selectedProductIDs },
            function (jsonData) {
                if (jsonData) {
                    $.each(jsonData.products, function (i, elem) {
                        var productData = elem;
                        var $productsReviewsContainer = $(
                            '.product-list-reviews[data-id="' +
                                productData.id_product +
                                '"]'
                        );
                        $productsReviewsContainer.each(function () {
                            var $self = $(this);
                            if (productData.comments_nb > 0) {
                                $self
                                    .find(
                                        DOMStrings.productListReviewsStarsContainer
                                    )
                                    .rating({
                                        grade: productData.average_grade,
                                        starWidth: 16,
                                    });
                                $self
                                    .find(
                                        DOMStrings.productListReviewsNumberOfComments
                                    )
                                    .text("(" + productData.comments_nb + ")");
                                $self
                                    .closest(DOMStrings.productContainer)
                                    .addClass(DOMClasses.hasReviews);
                                $self.css("visibility", "visible");
                            }
                            $self
                                .closest(DOMStrings.productContainer)
                                .addClass(DOMClasses.reviewsLoaded);
                            $self
                                .closest(DOMStrings.productContainer)
                                .removeClass(DOMClasses.inProgress);
                        });
                        data.productIDs.shift();
                    });
                    data.commentsLoadingInProgress = !1;
                    if (data.productIDs.length > 0) {
                        loadProductsData();
                    }
                }
            }
        );
    }
    return {
        load: function () {
            addProductsIDs();
        },
        init: function () {
            setAjaxUrl();
            setEvents();
        },
    };
})();
(function ($) {
    $.jGrowl = function (m, o) {
        if ($("#jGrowl").length == 0)
            $('<div id="jGrowl"></div>')
                .addClass($.jGrowl.defaults.position)
                .appendTo("body");
        $("#jGrowl").jGrowl(m, o);
    };
    $.fn.jGrowl = function (m, o) {
        if ($.isFunction(this.each)) {
            var args = arguments;
            return this.each(function () {
                var self = this;
                if ($(this).data("jGrowl.instance") == undefined) {
                    $(this).data(
                        "jGrowl.instance",
                        $.extend(new $.fn.jGrowl(), {
                            notifications: [],
                            element: null,
                            interval: null,
                        })
                    );
                    $(this).data("jGrowl.instance").startup(this);
                }
                if ($.isFunction($(this).data("jGrowl.instance")[m])) {
                    $(this)
                        .data("jGrowl.instance")
                        [m].apply(
                            $(this).data("jGrowl.instance"),
                            $.makeArray(args).slice(1)
                        );
                } else {
                    $(this).data("jGrowl.instance").create(m, o);
                }
            });
        }
    };
    $.extend($.fn.jGrowl.prototype, {
        defaults: {
            pool: 0,
            header: "",
            group: "",
            sticky: !1,
            position: "top-right",
            glue: "after",
            theme: "default",
            corners: "10px",
            check: 250,
            life: 3000,
            speed: "normal",
            easing: "swing",
            closer: !0,
            closeTemplate: "&times;",
            closerTemplate: "<div>[ close all ]</div>",
            log: function (e, m, o) {},
            beforeOpen: function (e, m, o) {},
            open: function (e, m, o) {},
            beforeClose: function (e, m, o) {},
            close: function (e, m, o) {},
            animateOpen: { opacity: "show" },
            animateClose: { opacity: "hide" },
        },
        notifications: [],
        element: null,
        interval: null,
        create: function (message, o) {
            var o = $.extend({}, this.defaults, o);
            this.notifications[this.notifications.length] = {
                message: message,
                options: o,
            };
            o.log.apply(this.element, [this.element, message, o]);
        },
        render: function (notification) {
            var self = this;
            var message = notification.message;
            var o = notification.options;
            var notification = $(
                '<div class="jGrowl-notification' +
                    (o.group != undefined && o.group != ""
                        ? " " + o.group
                        : "") +
                    '"><div class="close">' +
                    o.closeTemplate +
                    '</div><div class="header">' +
                    o.header +
                    '</div><div class="message">' +
                    message +
                    "</div></div>"
            )
                .data("jGrowl", o)
                .addClass(o.theme)
                .children("div.close")
                .bind("click.jGrowl", function () {
                    $(this).parent().trigger("jGrowl.close");
                })
                .parent();
            o.glue == "after"
                ? $("div.jGrowl-notification:last", this.element).after(
                      notification
                  )
                : $("div.jGrowl-notification:first", this.element).before(
                      notification
                  );
            $(notification)
                .bind("mouseover.jGrowl", function () {
                    $(this).data("jGrowl").pause = !0;
                })
                .bind("mouseout.jGrowl", function () {
                    $(this).data("jGrowl").pause = !1;
                })
                .bind("jGrowl.beforeOpen", function () {
                    o.beforeOpen.apply(self.element, [
                        self.element,
                        message,
                        o,
                    ]);
                })
                .bind("jGrowl.open", function () {
                    o.open.apply(self.element, [self.element, message, o]);
                })
                .bind("jGrowl.beforeClose", function () {
                    o.beforeClose.apply(self.element, [
                        self.element,
                        message,
                        o,
                    ]);
                })
                .bind("jGrowl.close", function () {
                    $(this).data("jGrowl").pause = !0;
                    $(this)
                        .trigger("jGrowl.beforeClose")
                        .animate(
                            o.animateClose,
                            o.speed,
                            o.easing,
                            function () {
                                $(this).remove();
                                o.close.apply(self.element, [
                                    self.element,
                                    message,
                                    o,
                                ]);
                            }
                        );
                })
                .trigger("jGrowl.beforeOpen")
                .animate(o.animateOpen, o.speed, o.easing, function () {
                    $(this).data("jGrowl").created = new Date();
                })
                .trigger("jGrowl.open");
            if ($.fn.corner != undefined) $(notification).corner(o.corners);
            if (
                $("div.jGrowl-notification:parent", this.element).length > 1 &&
                $("div.jGrowl-closer", this.element).length == 0 &&
                this.defaults.closer != !1
            ) {
                $(this.defaults.closerTemplate)
                    .addClass("jGrowl-closer")
                    .addClass(this.defaults.theme)
                    .appendTo(this.element)
                    .animate(
                        this.defaults.animateOpen,
                        this.defaults.speed,
                        this.defaults.easing
                    )
                    .bind("click.jGrowl", function () {
                        $(this)
                            .siblings()
                            .children("div.close")
                            .trigger("click.jGrowl");
                        if ($.isFunction(self.defaults.closer))
                            self.defaults.closer.apply($(this).parent()[0], [
                                $(this).parent()[0],
                            ]);
                    });
            }
        },
        update: function () {
            $(this.element)
                .find("div.jGrowl-notification:parent")
                .each(function () {
                    if (
                        $(this).data("jGrowl") != undefined &&
                        $(this).data("jGrowl").created != undefined &&
                        $(this).data("jGrowl").created.getTime() +
                            $(this).data("jGrowl").life <
                            new Date().getTime() &&
                        $(this).data("jGrowl").sticky != !0 &&
                        ($(this).data("jGrowl").pause == undefined ||
                            $(this).data("jGrowl").pause != !0)
                    ) {
                        $(this).trigger("jGrowl.close");
                    }
                });
            if (
                this.notifications.length > 0 &&
                (this.defaults.pool == 0 ||
                    $(this.element).find("div.jGrowl-notification:parent")
                        .length < this.defaults.pool)
            ) {
                this.render(this.notifications.shift());
            }
            if (
                $(this.element).find("div.jGrowl-notification:parent").length <
                2
            ) {
                $(this.element)
                    .find("div.jGrowl-closer")
                    .animate(
                        this.defaults.animateClose,
                        this.defaults.speed,
                        this.defaults.easing,
                        function () {
                            $(this).remove();
                        }
                    );
            }
        },
        startup: function (e) {
            this.element = $(e)
                .addClass("jGrowl")
                .append('<div class="jGrowl-notification"></div>');
            this.interval = setInterval(function () {
                $(e).data("jGrowl.instance").update();
            }, this.defaults.check);
        },
        shutdown: function () {
            $(this.element)
                .removeClass("jGrowl")
                .find("div.jGrowl-notification")
                .remove();
            clearInterval(this.interval);
        },
    });
    $.jGrowl.defaults = $.fn.jGrowl.prototype.defaults;
})(jQuery);
$(document).ready(function () {
    $("body").one("click", ".remove-from-cart", function () {
        $(this).closest("mini-product").remove();
    });
    const updateCounterState = () => {
        const {
            cart: { products_count: num },
        } = prestashop;
        const counterEl = ".cart-products-count";
        $(counterEl).text(num).attr("data-productsnum", num);
    };
    updateCounterState();
    prestashop.on("updateCart", function (event) {
        const blockcartEl = ".blockcart";
        const { blockcart } = prestashop;
        const refreshURL = $(blockcartEl).data("refresh-url");
        let requestData = {};
        if (
            event?.reason &&
            typeof event.resp !== "undefined" &&
            !event.resp.hasError
        ) {
            requestData = {
                id_customization: event.reason.idCustomization,
                id_product_attribute: event.reason.idProductAttribute,
                id_product: event.reason.idProduct,
                action: event.reason.linkAction,
            };
        }
        if (event?.resp?.hasError) {
            prestashop.emit("showErrorNextToAddtoCartButton", {
                errorMessage: event.resp.errors.join("<br>"),
            });
        }
        $.post(refreshURL, requestData)
            .then(function (resp) {
                $(blockcartEl).replaceWith($(resp.preview).find(blockcartEl));
                resp.modal && blockcart?.showModal(resp.modal);
                updateCounterState();
            })
            .fail(function (resp) {
                prestashop.emit("handleError", {
                    eventType: "updateShoppingCart",
                    resp,
                });
            });
    });
});
