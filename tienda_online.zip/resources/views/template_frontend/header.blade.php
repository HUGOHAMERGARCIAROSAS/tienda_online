<style>
    .categories-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 10px;
        padding: 40px;
    }

    .category-item a {
        display: block;
        padding: 10px 12px;
        color: #333;
        text-decoration: none;
        border-radius: 6px;
        background-color: #fff;
        transition: all 0.3s ease;
    }

    .category-item a:hover {
        background-color: #323232;
        color: #fff;
        transform: translateY(-3px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }


</style>
<header id="header">
    <template id="mobile-header-template">
        <div data-elementor-type="page" data-elementor-id="143010000"
            class="elementor elementor-143010000 elementor-bc-flex-widget" data-elementor-settings="[]">
            <div class="elementor-inner">
                <div class="elementor-section-wrap">
                    <div class="elementor-element elementor-element-e62d365 elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section"
                        data-id="e62d365" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-row">
                                <div class="elementor-element elementor-element-9550c78 elementor-hidden-desktop elementor-column elementor-col-33 elementor-top-column"
                                    data-id="9550c78" data-element_type="column">
                                    <div class="elementor-column-wrap elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div class="elementor-element elementor-element-eef113b elementor-widget elementor-widget-pklogo"
                                                data-id="eef113b" data-element_type="widget"
                                                data-widget_type="pklogo.default">
                                                <div class="elementor-widget-container">
                                                    <div class="header_logo h-100 w-100">
                                                        <h1 class="m-0 logo-link-wrap">
                                                            <a class="header_logo_img dib" href="{{ url('/') }}"
                                                                title="Tienda Online">
                                                                <img class="logo"
                                                                    src="{{ asset('mj_glam_width.png') }}"
                                                                    alt="Tienda Online" width="160" height="40"
                                                                    style="min-width:160px;width:160px;height:40px;"
                                                                    fetchpriority="high">
                                                            </a>
                                                        </h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-1f9a110 elementor-column elementor-col-66 elementor-top-column"
                                    data-id="1f9a110" data-element_type="column">
                                    <div class="elementor-column-wrap elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div class="elementor-element elementor-element-4b9cc2a elementor-widget__width-auto elementor%s-align-flex-start elementor%s-align-flex-start elementor-widget elementor-widget-pksearch"
                                                data-id="4b9cc2a" data-element_type="widget"
                                                data-widget_type="pksearch.default">
                                                <div class="elementor-widget-container">
                                                    <div class="pk-ce-widget-wrapper">
                                                        <div class="pk-ce-widget view_grid">
                                                            <div class="pk-search-widget flex-container categories-outside"
                                                                data-show_input=0 data-button_action=open_sidebar
                                                                data-voice_search=false data-voice_search_tips=yes
                                                                data-items_limit=5 data-order_by=position
                                                                data-order_way=desc data-minlength=3 data-page="1">
                                                                <form method="get"
                                                                    action="https://alysum.promokit.eu/en/module/pkelements/search"
                                                                    data-original-action="https://alysum.promokit.eu/en/search"
                                                                    class="relative">
                                                                    <fieldset class="flex-container align-items-center">
                                                                        <legend>BUSCAR</legend>
                                                                        <div class="relative inner-search-button flex-container">
                                                                            <input type="search" name="s"
                                                                                value=""
                                                                                class="search-popup hidden"
                                                                                placeholder="Buscar..."
                                                                                aria-label="Search">
                                                                            <button type="submit"
                                                                                class="flex-container justify-content-center align-items-center"
                                                                                aria-label="BUSCAR"
                                                                                data-pktabname="el-search"
                                                                                data-pktabgroup="el-search"
                                                                                data-pktype="sidebar">
                                                                                <svg
                                                                                    class="svgic svg-loader in_progress">
                                                                                    <use
                                                                                        href="{{ asset('template/images/lib.svg#loading') }}">
                                                                                    </use>
                                                                                </svg> <svg class="svgic svg-search">
                                                                                    <use
                                                                                        href="{{ asset('template/images/lib.svg#search') }}">
                                                                                    </use>
                                                                                </svg> </button>
                                                                        </div>
                                                                    </fieldset>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-b32a150 elementor-widget__width-auto elementor-widget elementor-widget-pkmyaccount"
                                                data-id="b32a150" data-element_type="widget"
                                                data-widget_type="pkmyaccount.default">
                                                <div class="elementor-widget-container">
                                                    <div class="pk-ce-widget-wrapper">
                                                        <div class="pk-ce-widget view_grid">


                                                            <div
                                                                class="myaccount-select user-select relative dib pk-position-left">

                                                                <div class="pk-myaccount">

                                                                    <div class="current-item cp smooth02 flex-container icon-element pk-item-content align-items-center justify-content-center"
                                                                        data-pktabname="el-myaccount"
                                                                        data-pktabgroup="el-myaccount"
                                                                        data-pktype="sidebar">
                                                                        <svg class="svgic">
                                                                            <use
                                                                                href="{{ asset('template/images/lib.svg#account') }}">
                                                                            </use>
                                                                        </svg>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="elementor-element elementor-element-516968b elementor-widget__width-auto elementor-widget elementor-widget-pkcart"
                                                data-id="516968b" data-element_type="widget"
                                                data-widget_type="pkcart.default">
                                                <div class="elementor-widget-container">
                                                    <div class="pk-ce-widget-wrapper">
                                                        <div class="pk-ce-widget view_grid">
                                                            <div class="cart-select user-select relative dib">
                                                                <div class="pk-cart dd_el">

                                                                    <div class="current-item cp smooth02 flex-container icon-element pk-item-content align-items-center justify-content-center"
                                                                        data-pktabname="el-cart"
                                                                        data-pktabgroup="el-cart" data-pktype="sidebar">
                                                                        <svg class="svgic">
                                                                            <use
                                                                                href="{{ asset('template/images/lib.svg#cart') }}">
                                                                            </use>
                                                                        </svg> <span
                                                                            class="header-item-counter cart-products-count"
                                                                            data-productsnum="0">0</span>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-element elementor-element-cfbdb1e elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section"
                        data-id="cfbdb1e" data-element_type="section"
                        data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-row">
                                <div class="elementor-element elementor-element-c817ce7 elementor-column elementor-col-100 elementor-top-column"
                                    data-id="c817ce7" data-element_type="column">
                                    <div class="elementor-column-wrap">
                                        <div class="elementor-widget-wrap">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </template>

    <div class="mobile-header-wrapper">
    </div>

    <div class="desktop-header-wrapper">
        <div data-elementor-type="page" data-elementor-id="151010000"
            class="elementor elementor-151010000 elementor-bc-flex-widget" data-elementor-settings="[]">
            <div class="elementor-inner">
                <div class="elementor-section-wrap">

                    <div class="elementor-element elementor-element-3dbbb321 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section"
                        data-id="3dbbb321" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-row">
                                <div class="elementor-element elementor-element-3991fb9b elementor-column elementor-col-33 elementor-top-column"
                                    data-id="3991fb9b" data-element_type="column">
                                </div>
                                <div class="elementor-element elementor-element-14fa0fe elementor-column elementor-col-66 elementor-top-column"
                                    data-id="14fa0fe" data-element_type="column">
                                    <div class="elementor-column-wrap elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div class="elementor-element elementor-element-6d04611 elementor-widget__width-auto elementor-widget elementor-widget-pksignin"
                                                data-id="6d04611" data-element_type="widget"
                                                data-widget_type="pksignin.default">
                                                <div class="elementor-widget-container">
                                                    <div class="pk-ce-widget-wrapper">
                                                        <div class="pk-ce-widget view_grid">
                                                            <div class="signin-select user-select relative dib">
                                                                <div class="pk-signin dd_el">
                                                                    @if(Auth::user())
                                                                        <div class="current-item cp smooth02 flex-container icon-element pk-item-content align-items-center justify-content-center">
                                                                            <a href="{{ url('/client/dashboard') }}">Mi cuenta</a>
                                                                        </div>
                                                                    @else
                                                                        <div class="current-item cp smooth02 flex-container icon-element pk-item-content align-items-center justify-content-center"
                                                                            data-pktabname="el-signin"
                                                                            data-pktabgroup="el-signin"
                                                                            data-pktabsection="signin"
                                                                            data-pktype="sidebar">
                                                                            <span>Iniciar sesión</span>
                                                                        </div>
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="elementor-element elementor-element-1a5038d6 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section"
                        data-id="1a5038d6" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-row">
                                <div class="elementor-element elementor-element-73412f78 elementor-column elementor-col-33 elementor-top-column"
                                    data-id="73412f78" data-element_type="column">
                                    <div class="elementor-column-wrap elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div class="elementor-element elementor-element-e6edadc elementor-widget elementor-widget-pknav"
                                                data-id="e6edadc" data-element_type="widget"
                                                data-widget_type="pknav.default">
                                                <div class="elementor-widget-container">
                                                    <div class="pk-ce-widget-wrapper">
                                                        <div class="pk-ce-widget view_grid">
                                                            <nav class="pk-nav">
                                                                <div class="pk-menu-icon cp flex-container align-items-center hidden"
                                                                    role="button" data-pktabname="el-pknav"
                                                                    data-pktabgroup="el-pknav" data-pktype="sidebar">
                                                                    <span>Menu</span>
                                                                    <svg class="svgic">
                                                                        <use
                                                                            href="{{ asset('template/images/lib.svg#menu') }}">
                                                                        </use>
                                                                    </svg>
                                                                </div>
                                                                <ul class="pk-nav-ul flex-container list-style-none pk-show"
                                                                    role="menubar" data-openon="hover">
                                                                    <li class="pk-nav-li pk-align-auto"
                                                                        role="none">
                                                                        <div class="flex-container align-items-center">
                                                                            <a href="{{ url('/') }}"
                                                                                class="pk-nav-link flex-grow1"
                                                                                role="menuitem" title="">
                                                                                INICIO
                                                                            </a>
                                                                            <div class="pk-dropdown-toggler"
                                                                                role="button">
                                                                                <svg class="svgic pk-smooth">
                                                                                    <use
                                                                                        href="{{ asset('template/images/lib.svg#arrowdown') }}">
                                                                                    </use>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                    <li class="pk-nav-li pk-align-left"
                                                                        role="none">
                                                                        <div class="flex-container align-items-center">
                                                                            <a href="{{ route('frontend.categories') }}"
                                                                                class="pk-nav-link flex-grow1"
                                                                                role="menuitem" title="">
                                                                                CATEGORIAS
                                                                            </a>
                                                                            <div class="pk-dropdown-toggler"
                                                                                role="button">
                                                                                <svg class="svgic pk-smooth">
                                                                                    <use
                                                                                        href="{{ asset('template/images/lib.svg#arrowdown') }}">
                                                                                    </use>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div class="pk-dropdown absolute pk-smooth"
                                                                            tabindex="-1" style="width:100%">
                                                                            <div class="categories-grid">
                                                                                @foreach ($categories as $category)
                                                                                    <div class="category-item">
                                                                                        <a href="{{ route('frontend.categories.show', $category->slug) }}">
                                                                                            {{ $category->name }}
                                                                                        </a>
                                                                                    </div>
                                                                                @endforeach
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </nav>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-4f6b5f14 elementor-column elementor-col-33 elementor-top-column"
                                    data-id="4f6b5f14" data-element_type="column">
                                    <div class="elementor-column-wrap elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div class="elementor-element elementor-element-2821ffd9 elementor-widget elementor-widget-pklogo"
                                                data-id="2821ffd9" data-element_type="widget"
                                                data-widget_type="pklogo.default">
                                                <div class="elementor-widget-container">
                                                    <div class="header_logo h-100 w-100">
                                                        <h1 class="m-0 logo-link-wrap">
                                                            <a class="header_logo_img dib" href="{{ url('/') }}"
                                                                title="MJGlam">
                                                                <img class="logo"
                                                                    src="{{ asset('mj_glam_width.png') }}"
                                                                    alt="MJGlam" width="160" height="60"
                                                                    style="min-width:160px;width:160px;height:60px;"
                                                                    fetchpriority="high">
                                                            </a>
                                                        </h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-1a65b2c8 elementor-column elementor-col-33 elementor-top-column"
                                    data-id="1a65b2c8" data-element_type="column">
                                    <div class="elementor-column-wrap elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div class="elementor-element elementor-element-1b8684ab elementor-widget__width-auto elementor-widget elementor-widget-pkcart"
                                                data-id="1b8684ab" data-element_type="widget"
                                                data-widget_type="pkcart.default">
                                                <div class="elementor-widget-container">
                                                    <div class="pk-ce-widget-wrapper">
                                                        <div class="pk-ce-widget view_grid">
                                                            <div class="cart-select user-select relative dib show-brackets">
                                                                <div class="pk-cart dd_el">
                                                                    <div class="current-item cp smooth02 flex-container icon-element pk-item-content align-items-center justify-content-center"
                                                                        data-pktabname="el-cart"
                                                                        data-pktabgroup="el-cart"
                                                                        data-pktype="sidebar">
                                                                        <span>CARRITO</span>
                                                                        <span class="header-item-counter cart-products-count" data-productsnum="0">0</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
