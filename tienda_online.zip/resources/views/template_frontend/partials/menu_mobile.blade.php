<ul class="pk-mobile-bottom-panel fixed w-100 flex-container justify-content-center list-style-none hidden mb-0">
    <li class="el-cart">
        <button class="flex-container flex-column align-items-center relative" data-pktabname="el-cart"
            data-pktabgroup="el-cart" data-pktype="sidebar" aria-label="Cart">
            <svg class="svgic">
                <use href="{{ asset('template/images/lib.svg#cart') }}"></use>
            </svg> <span>Carrito</span>
            <span class="cart-products-count cart-counter absolute" data-productsnum="0">10</span>
        </button>
    </li>
    <li class="el-myaccount">
        <button class="flex-container flex-column align-items-center relative" data-pktabname="el-myaccount"
            data-pktabgroup="el-myaccount" data-pktype="sidebar" aria-label="Account">
            <svg class="svgic">
                <use href="{{ asset('template/images/lib.svg#myaccount') }}"></use>
            </svg> <span>Cuenta</span>
        </button>
    </li>
    <li class="el-pknav">
        <button class="flex-container flex-column align-items-center relative" data-pktabname="el-pknav"
            data-pktabgroup="el-pknav" data-pktype="sidebar" aria-label="Menu">
            <svg class="svgic">
                <use href="{{ asset('template/images/lib.svg#pknav') }}"></use>
            </svg> <span>Menu</span>
        </button>
    </li>
</ul>
