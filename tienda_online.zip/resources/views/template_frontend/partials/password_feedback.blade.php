<template id="password-feedback">
        <div class="password-strength-feedback mt-1" style="display: none;">
            <div class="progress-container">
                <div class="progress mb-1">
                    <div class="progress-bar" role="progressbar" value="50" aria-valuemin="0"
                        aria-valuemax="100"></div>
                </div>
            </div>
            <script class="js-hint-password">
                {
                    "0": "Very weak",
                    "1": "Weak",
                    "2": "Average",
                    "3": "Strong",
                    "4": "Very strong",
                    "Straight rows of keys are easy to guess": "Straight rows of keys are easy to guess",
                    "Short keyboard patterns are easy to guess": "Short keyboard patterns are easy to guess",
                    "Use a longer keyboard pattern with more turns": "Use a longer keyboard pattern with more turns",
                    "Repeats like \"aaa\" are easy to guess": "Repeats like \"aaa\" are easy to guess",
                    "Repeats like \"abcabcabc\" are only slightly harder to guess than \"abc\"": "Repeats like \"abcabcabc\" are only slightly harder to guess than \"abc\"",
                    "Sequences like abc or 6543 are easy to guess": "Sequences like \"abc\" or \"6543\" are easy to guess.",
                    "Recent years are easy to guess": "Recent years are easy to guess",
                    "Dates are often easy to guess": "Dates are often easy to guess",
                    "This is a top-10 common password": "This is a top-10 common password",
                    "This is a top-100 common password": "This is a top-100 common password",
                    "This is a very common password": "This is a very common password",
                    "This is similar to a commonly used password": "This is similar to a commonly used password",
                    "A word by itself is easy to guess": "A word by itself is easy to guess",
                    "Names and surnames by themselves are easy to guess": "Names and surnames by themselves are easy to guess",
                    "Common names and surnames are easy to guess": "Common names and surnames are easy to guess",
                    "Use a few words, avoid common phrases": "Use a few words, avoid common phrases",
                    "No need for symbols, digits, or uppercase letters": "No need for symbols, digits, or uppercase letters",
                    "Avoid repeated words and characters": "Avoid repeated words and characters",
                    "Avoid sequences": "Avoid sequences",
                    "Avoid recent years": "Avoid recent years",
                    "Avoid years that are associated with you": "Avoid years that are associated with you",
                    "Avoid dates and years that are associated with you": "Avoid dates and years that are associated with you",
                    "Capitalization doesn't help very much": "Capitalization doesn't help very much",
                    "All-uppercase is almost as easy to guess as all-lowercase": "All-uppercase is almost as easy to guess as all-lowercase",
                    "Reversed words aren't much harder to guess": "Reversed words aren't much harder to guess",
                    "Predictable substitutions like '@' instead of 'a' don't help very much": "Predictable substitutions like \"@\" instead of \"a\" don't help very much.",
                    "Add another word or two. Uncommon words are better.": "Add another word or two. Uncommon words are better."
                }
            </script>

            <div class="password-strength-text"></div>
            <div class="password-requirements">
                <p class="password-requirements-length"
                    data-translation="Enter a password between %s and %s characters">
                    <svg class="svgic">
                        <use href="{{ asset('template/images/lib.svg#done') }}"></use>
                    </svg> <span></span>
                </p>
                <p class="password-requirements-score" data-translation="The minimum score must be: %s">
                    <svg class="svgic">
                        <use href="{{ asset('template/images/lib.svg#done') }}"></use>
                    </svg> <span></span>
                </p>
            </div>
        </div>
    </template>