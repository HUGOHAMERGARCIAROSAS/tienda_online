<aside class="app-sidebar sticky" id="sidebar">
    <div class="app-sidebar-header">
        <a href="{{ route('admin.dashboard')}}" class="desktop-logo">
            <img src="{{ asset('mj_glam_width.png') }}" height="50" alt="image">
        </a>
        <a href="{{ route('admin.dashboard')}}" class="desktop-dark">
            <img src="{{ asset('mj_glam_width.png') }}" height="50" alt="image">
        </a>
    </div>
    <div class="app-sidebar-wrapper" id="sidebar-scroll">
        <nav class="app-sidebar-menu-wrapper nav flex-column sub-open">
            <div class="sidebar-left" id="sidebar-left"></div>
            <ul class="app-sidebar-main-menu">

                <li class="sidebar-menu-category"><span class="category-name">Main</span></li>
                <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M14 21C13.4477 21 13 20.5523 13 20V12C13 11.4477 13.4477 11 14 11H20C20.5523 11 21 11.4477 21 12V20C21 20.5523 20.5523 21 20 21H14ZM4 13C3.44772 13 3 12.5523 3 12V4C3 3.44772 3.44772 3 4 3H10C10.5523 3 11 3.44772 11 4V12C11 12.5523 10.5523 13 10 13H4ZM9 11V5H5V11H9ZM4 21C3.44772 21 3 20.5523 3 20V16C3 15.4477 3.44772 15 4 15H10C10.5523 15 11 15.4477 11 16V20C11 20.5523 10.5523 21 10 21H4ZM5 19H9V17H5V19ZM15 19H19V13H15V19ZM13 4C13 3.44772 13.4477 3 14 3H20C20.5523 3 21 3.44772 21 4V8C21 8.55228 20.5523 9 20 9H14C13.4477 9 13 8.55228 13 8V4ZM15 5V7H19V5H15Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Dashboard</span>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide"><a class="sidebar-menu-item" href="#">Dashboard</a></li>
                    </ul>
                </li>

                {{-- <li class="sidebar-menu-category"><span class="category-name">Productos</span></li> --}}
                <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M3.16113 4.46875C5.58508 2.0448 9.44716 1.9355 12.0008 4.14085C14.5528 1.9355 18.4149 2.0448 20.8388
                                        4.46875C23.2584 6.88836 23.3716 10.741 21.1785 13.2947L13.4142 21.0858C12.6686 21.8313 11.4809 21.8652 10.6952
                                        21.1874L10.5858 21.0858L2.82141 13.2947C0.628282 10.741 0.741522 6.88836 3.16113 4.46875ZM4.57534 5.88296C2.86819
                                        7.59011 2.81942 10.3276 4.42902 12.0937L4.57534 12.2469L12 19.6715L17.3026 14.3675L13.7677 10.8327L12.7071 11.8934C11.5355
                                        13.0649 9.636 13.0649 8.46443 11.8934C7.29286 10.7218 7.29286 8.8223 8.46443 7.65073L10.5656 5.54823C8.85292 4.17713 6.37076
                                        4.23993 4.7286 5.73663L4.57534 5.88296ZM13.0606 8.71139C13.4511 8.32086 14.0843 8.32086 14.4748 8.71139L18.7168 12.9533L19.4246
                                        12.2469C21.1819 10.4896 21.1819 7.64032 19.4246 5.88296C17.7174 4.17581 14.9799 4.12704 13.2139 5.73663L13.0606 5.88296L9.87864
                                        9.06494C9.51601 9.42757 9.49011 9.99942 9.80094 10.3919L9.87864 10.4792C10.2413 10.8418 10.8131 10.8677 11.2056
                                        10.5569L11.2929 10.4792L13.0606 8.71139Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Productos</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a href="{{ route('admin.products.index') }}" class="sidebar-menu-item">Lista de Productos</a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('admin.categories.index') }}" class="sidebar-menu-item">Categorias</a>
                        </li>
                        {{-- <li class="slide">
                            <a href="crm-deals.html" class="sidebar-menu-item">Marcas / proveedores</a>
                        </li>
                        <li class="slide">
                            <a href="crm-deals-details.html" class="sidebar-menu-item">Variantes</a>
                        </li>
                        <li class="slide">
                            <a href="crm-leads.html" class="sidebar-menu-item">Inventario</a>
                        </li> --}}
                    </ul>
                </li>
                <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M12 11C14.7614 11 17 13.2386 17 16V22H15V16C15 14.4023 13.7511 13.0963 12.1763 13.0051L12 13C10.4023 13 9.09634 14.2489 9.00509 15.8237L9 16V22H7V16C7 13.2386 9.23858 11 12 11ZM5.5 14C5.77885 14 6.05009 14.0326 6.3101 14.0942C6.14202 14.594 6.03873 15.122 6.00896 15.6693L6 16L6.0007 16.0856C5.88757 16.0456 5.76821 16.0187 5.64446 16.0069L5.5 16C4.7203 16 4.07955 16.5949 4.00687 17.3555L4 17.5V22H2V17.5C2 15.567 3.567 14 5.5 14ZM18.5 14C20.433 14 22 15.567 22 17.5V22H20V17.5C20 16.7203 19.4051 16.0796 18.6445 16.0069L18.5 16C18.3248 16 18.1566 16.03 18.0003 16.0852L18 16C18 15.3343 17.8916 14.694 17.6915 14.0956C17.9499 14.0326 18.2211 14 18.5 14ZM5.5 8C6.88071 8 8 9.11929 8 10.5C8 11.8807 6.88071 13 5.5 13C4.11929 13 3 11.8807 3 10.5C3 9.11929 4.11929 8 5.5 8ZM18.5 8C19.8807 8 21 9.11929 21 10.5C21 11.8807 19.8807 13 18.5 13C17.1193 13 16 11.8807 16 10.5C16 9.11929 17.1193 8 18.5 8ZM5.5 10C5.22386 10 5 10.2239 5 10.5C5 10.7761 5.22386 11 5.5 11C5.77614 11 6 10.7761 6 10.5C6 10.2239 5.77614 10 5.5 10ZM18.5 10C18.2239 10 18 10.2239 18 10.5C18 10.7761 18.2239 11 18.5 11C18.7761 11 19 10.7761 19 10.5C19 10.2239 18.7761 10 18.5 10ZM12 2C14.2091 2 16 3.79086 16 6C16 8.20914 14.2091 10 12 10C9.79086 10 8 8.20914 8 6C8 3.79086 9.79086 2 12 2ZM12 4C10.8954 4 10 4.89543 10 6C10 7.10457 10.8954 8 12 8C13.1046 8 14 7.10457 14 6C14 4.89543 13.1046 4 12 4Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Pedidos</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide"> <a href="{{ route('admin.orders.index') }}" class="sidebar-menu-item">Listado de Pedidos</a></li>
                        {{-- <li class="slide"> <a href="#" class="sidebar-menu-item">Devoluciones y reembolsos</a>
                        </li>
                        <li class="slide"> <a href="#" class="sidebar-menu-item">Facturación y comprobantes</a> --}}
                        </li>
                    </ul>
                </li>
                <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M21 11.6458V21C21 21.5523 20.5523 22 20 22H4C3.44772 22 3 21.5523 3 21V11.6458C2.37764 10.9407 2 10.0144 2 9V3C2 2.44772 2.44772 2 3 2H21C21.5523 2 22 2.44772 22 3V9C22 10.0144 21.6224 10.9407 21 11.6458ZM19 12.874C18.6804 12.9562 18.3453 13 18 13C16.8053 13 15.7329 12.4762 15 11.6458C14.2671 12.4762 13.1947 13 12 13C10.8053 13 9.73294 12.4762 9 11.6458C8.26706 12.4762 7.19469 13 6 13C5.6547 13 5.31962 12.9562 5 12.874V20H19V12.874ZM14 9C14 8.44772 14.4477 8 15 8C15.5523 8 16 8.44772 16 9C16 10.1046 16.8954 11 18 11C19.1046 11 20 10.1046 20 9V4H4V9C4 10.1046 4.89543 11 6 11C7.10457 11 8 10.1046 8 9C8 8.44772 8.44772 8 9 8C9.55228 8 10 8.44772 10 9C10 10.1046 10.8954 11 12 11C13.1046 11 14 10.1046 14 9Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Clientes</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a class="sidebar-menu-item" href="{{ route('admin.clients.index') }}">Lista de clientes</a>
                        </li>
                        {{-- <li class="slide">
                            <a class="sidebar-menu-item" href="#">Segmentación de clientes</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Suscripciones a newsletter</a>
                        </li> --}}
                    </ul>
                </li>
                {{-- <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M7.00488 7.99966V5.99966C7.00488 3.23824 9.24346 0.999664 12.0049 0.999664C14.7663 0.999664 17.0049 3.23824 17.0049 5.99966V7.99966H20.0049C20.5572 7.99966 21.0049 8.44738 21.0049 8.99966V20.9997C21.0049 21.5519 20.5572 21.9997 20.0049 21.9997H4.00488C3.4526 21.9997 3.00488 21.5519 3.00488 20.9997V8.99966C3.00488 8.44738 3.4526 7.99966 4.00488 7.99966H7.00488ZM7.00488 9.99966H5.00488V19.9997H19.0049V9.99966H17.0049V11.9997H15.0049V9.99966H9.00488V11.9997H7.00488V9.99966ZM9.00488 7.99966H15.0049V5.99966C15.0049 4.34281 13.6617 2.99966 12.0049 2.99966C10.348 2.99966 9.00488 4.34281 9.00488 5.99966V7.99966Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Marketing / Promociones</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Cupones de descuento</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Promociones</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Email marketing</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Reseñas</a>
                        </li>
                    </ul>
                </li> --}}
                {{-- <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M7 5V2C7 1.44772 7.44772 1 8 1H16C16.5523 1 17 1.44772 17 2V5H21C21.5523 5 22 5.44772 22 6V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20V6C2 5.44772 2.44772 5 3 5H7ZM4 16V19H20V16H4ZM4 14H20V7H4V14ZM9 3V5H15V3H9ZM11 11H13V13H11V11Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Pagos</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">JMetodos de pago</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Reporte de pagos</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Gestión de reembolsos</a>
                        </li>
                    </ul>
                </li> --}}
                {{-- <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M21 19H23V21H1V19H3V4C3 3.44772 3.44772 3 4 3H14C14.5523 3 15 3.44772 15 4V19H19V11H17V9H20C20.5523 9 21 9.44772 21 10V19ZM5 5V19H13V5H5ZM7 11H11V13H7V11ZM7 7H11V9H7V7Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Envíos</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Métodos de envíos</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Tarifas por zona</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Seguimiento de envíos</a>
                        </li>
                    </ul>
                </li> --}}
                {{-- <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M3 3H21C21.5523 3 22 3.44772 22 4V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20V4C2 3.44772 2.44772 3 3 3ZM11.126 12H4V19H20V12H18.874C18.4299 13.7252 16.8638 15 15 15C13.1362 15 11.5701 13.7252 11.126 12ZM11.126 10C11.5701 8.27477 13.1362 7 15 7C16.8638 7 18.4299 8.27477 18.874 10H20V5H4V10H11.126ZM15 13C16.1046 13 17 12.1046 17 11C17 9.89543 16.1046 9 15 9C13.8954 9 13 9.89543 13 11C13 12.1046 13.8954 13 15 13ZM6 15H8V17H6V15Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Reportes</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Ventas por periodo</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Ventas por categoría/producto</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Clientes</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Inventario</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Rentabilidad</a>
                        </li>
                    </ul>
                </li> --}}
                {{-- <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                    <path
                                        d="M12.0049 22.0027C6.48204 22.0027 2.00488 17.5256 2.00488 12.0027C2.00488 6.4799 6.48204 2.00275 12.0049 2.00275C17.5277 2.00275 22.0049 6.4799 22.0049 12.0027C22.0049 17.5256 17.5277 22.0027 12.0049 22.0027ZM12.0049 20.0027C16.4232 20.0027 20.0049 16.421 20.0049 12.0027C20.0049 7.58447 16.4232 4.00275 12.0049 4.00275C7.5866 4.00275 4.00488 7.58447 4.00488 12.0027C4.00488 16.421 7.5866 20.0027 12.0049 20.0027ZM8.50488 14.0027H14.0049C14.281 14.0027 14.5049 13.7789 14.5049 13.5027C14.5049 13.2266 14.281 13.0027 14.0049 13.0027H10.0049C8.62417 13.0027 7.50488 11.8835 7.50488 10.5027C7.50488 9.12203 8.62417 8.00275 10.0049 8.00275H11.0049V6.00275H13.0049V8.00275H15.5049V10.0027H10.0049C9.72874 10.0027 9.50488 10.2266 9.50488 10.5027C9.50488 10.7789 9.72874 11.0027 10.0049 11.0027H14.0049C15.3856 11.0027 16.5049 12.122 16.5049 13.5027C16.5049 14.8835 15.3856 16.0027 14.0049 16.0027H13.0049V18.0027H11.0049V16.0027H8.50488V14.0027Z">
                                    </path>
                                </svg>
                            </i>
                        </div>
                        <span class="sidebar-menu-label">Configuración</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Datos de la tienda</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Impuestos</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Usuarios y roles</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Seguridad</a>
                        </li>
                    </ul>
                </li> --}}
                <li class="slide has-sub">
                    <a href="javascript:void(0);" class="sidebar-menu-item">
                        <div class="side-menu-icon">
                            <i class="ri-firefox-browser-fill"></i>
                        </div>
                        <span class="sidebar-menu-label">Frontend</span>
                        <i class="ri-arrow-down-s-fill side-menu-angle"></i>
                    </a>
                    <ul class="sidebar-menu child1">
                        <li class="slide">
                            <a class="sidebar-menu-item" href="{{route('admin.frontend.sliders')}}">Sliders</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="{{route('admin.settings.index')}}">Datos de la tienda</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="{{route('admin.brands.index')}}">Marcas</a>
                        </li>
                        {{-- <li class="slide">
                            <a class="sidebar-menu-item" href="#">Impuestos</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Usuarios y roles</a>
                        </li>
                        <li class="slide">
                            <a class="sidebar-menu-item" href="#">Seguridad</a>
                        </li> --}}
                    </ul>
                </li>
            </ul>
            <div class="sidebar-right" id="sidebar-right"></div>
        </nav>
    </div>
</aside>
<div class="app-offcanvas-overlay"></div>
