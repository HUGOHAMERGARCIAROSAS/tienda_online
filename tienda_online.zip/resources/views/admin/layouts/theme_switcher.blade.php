{{-- <div class="theme-switcher-settings d-none">
    <div class="theme-switcher">
        <i class="ri-sun-line change-theme" id="theme-button"></i>
    </div>
</div>
<div class="bd-theme-settings-area transition-3">
    <div class="bd-theme-wrapper">
        <div class="bd-theme-header text-center">
            <h4 class="bd-theme-header-title"> Configuración de Tema</h4>
        </div>
        <div class="theme-switcher-radio d-flex align-items-center gap-25 mb-25">
            <div class="form-check switch-select">
                <input class="form-check-input" type="radio" name="theme-style" id="switcher-light-theme" checked>
                <label class="form-check-label" for="switcher-light-theme">
                    Claro
                </label>
            </div>
            <div class="form-check switch-select">
                <input class="form-check-input" type="radio" name="theme-style" id="switcher-dark-theme">
                <label class="form-check-label" for="switcher-dark-theme">
                    Oscuro
                </label>
            </div>
        </div>
        <div class="bd-theme-settings">
            <div class="bd-theme-settings-wrapper">
                <div class="bd-theme-settings-open">
                    <button class="bd-theme-settings-open-btn">
                        <span class="bd-theme-settings-gear">
                            <i class="ri-settings-3-line"></i>
                        </span>
                        <span class="bd-theme-settings-close">
                            <i class="ri-close-line"></i>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div> --}}
