<div id="loading">
    <div id="loading-center">
        <div id="loading-center-absolute">
            <div class="bd-preloader-content">
                <div class="bd-preloader-logo">
                    <div class="bd-preloader-circle">
                        <svg width="190" height="190" viewBox="0 0 380 380" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <circle stroke="#F5F5F5" cx="190" cy="190" r="250" stroke-width="6"
                                stroke-linecap="round">
                            </circle>
                            <circle stroke="red" cx="190" cy="190" r="250" stroke-width="6"
                                stroke-linecap="round">
                            </circle>
                        </svg>
                    </div>
                    <img src="{{ asset('mj_glam_width.png') }}" alt="image not found">
                </div>
                <p class="bd-preloader-subtitle">MJ GLAM</p>
            </div>
        </div>
    </div>
</div>
